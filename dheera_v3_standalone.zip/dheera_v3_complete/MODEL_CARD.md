# Dheera Model Card

## Model Overview

| Property | Value |
|----------|-------|
| **Model ID** | `dheera-v0.3.0` |
| **Full Name** | Dheera RLHF+DQN+SLM |
| **Version** | 0.3.0 |
| **Type** | Composite AI Agent (RL + LLM) |
| **License** | Apache 2.0 |

## Description

Dheera (धीर - Sanskrit for "Courageous, Wise, Patient") is an adaptive AI agent that combines:

1. **Deep Q-Network (DQN)** for intelligent action selection
2. **RLHF Reward Model** for response quality optimization
3. **Curiosity Module (RND)** for exploration-driven learning
4. **Small Language Model** for natural language generation

This is not a traditional single-model LLM, but a **composite system** that uses reinforcement learning to decide *how* to respond, then uses an LLM to generate the actual response.

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                     DHEERA v0.3.0 ARCHITECTURE                  │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   User Input                                                    │
│       │                                                         │
│       ▼                                                         │
│   ┌─────────────────┐                                           │
│   │  State Builder  │ ──► 64-dim state vector                   │
│   └────────┬────────┘                                           │
│            │                                                    │
│            ▼                                                    │
│   ┌─────────────────┐    ┌──────────────────┐                   │
│   │   DQN Agent     │◄───│ Curiosity (RND)  │                   │
│   │  (Action Select)│    │  (Exploration)   │                   │
│   └────────┬────────┘    └──────────────────┘                   │
│            │                                                    │
│            ▼                                                    │
│   ┌─────────────────┐    ┌──────────────────┐                   │
│   │ Action Router   │───►│  RLHF Reward     │                   │
│   │ (7 strategies)  │    │  Model (Score)   │                   │
│   └────────┬────────┘    └──────────────────┘                   │
│            │                                                    │
│            ▼                                                    │
│   ┌─────────────────┐                                           │
│   │  SLM Interface  │ ──► phi3:mini (3.8B)                      │
│   │  (Generation)   │                                           │
│   └────────┬────────┘                                           │
│            │                                                    │
│            ▼                                                    │
│   Response + Metadata                                           │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## Model Specifications

### Component Breakdown

| Component | Architecture | Parameters | Purpose |
|-----------|-------------|------------|---------|
| **Base SLM** | phi3:mini (Transformer) | 3.8B | Text generation |
| **DQN Agent** | Double DQN + Dueling | ~50K | Action selection |
| **Reward Model** | 3-layer MLP | ~100K | Response quality scoring |
| **Curiosity (RND)** | Dual MLP (target+predictor) | ~100K | Novelty detection |
| **State Builder** | Feature extraction | - | Context encoding |
| **Total Additional** | - | ~250K | RL components |

### DQN Agent Details

```python
{
    "architecture": "Double DQN with Dueling Networks",
    "state_dim": 64,
    "action_dim": 7,
    "hidden_dim": 128,
    "layers": [
        "Linear(64, 128) + ReLU",
        "Linear(128, 128) + ReLU",
        "Value Stream: Linear(128, 1)",
        "Advantage Stream: Linear(128, 7)"
    ],
    "optimizer": "Adam",
    "learning_rate": 0.001,
    "gamma": 0.99,
    "epsilon_start": 1.0,
    "epsilon_end": 0.05,
    "epsilon_decay_steps": 5000,
    "target_update_freq": 100,
    "replay_buffer": "Prioritized Experience Replay",
    "buffer_capacity": 100000
}
```

### Action Space

| ID | Action | Description | When Used |
|----|--------|-------------|-----------|
| 0 | `DIRECT_RESPONSE` | Answer directly | Simple questions, greetings |
| 1 | `CLARIFY_QUESTION` | Ask for clarification | Ambiguous requests |
| 2 | `USE_TOOL` | Use a tool | Code, calculations |
| 3 | `SEARCH_WEB` | Search for info | Current events, facts |
| 4 | `BREAK_DOWN_TASK` | Decompose task | Complex requests |
| 5 | `REFLECT_AND_REASON` | Think step-by-step | Reasoning problems |
| 6 | `DEFER_OR_DECLINE` | Decline politely | Inappropriate requests |

### State Vector (64 dimensions)

```python
state_features = {
    # Query features (16 dims)
    "query_length": 1,
    "query_complexity": 1,
    "question_type": 4,  # one-hot
    "has_code": 1,
    "sentiment": 3,
    "named_entities": 2,
    "intent_embedding": 4,
    
    # Context features (16 dims)
    "turn_count": 1,
    "context_length": 1,
    "topic_consistency": 1,
    "user_engagement": 1,
    "recent_actions": 7,  # last action one-hot
    "avg_reward": 1,
    "time_since_last": 1,
    "session_duration": 1,
    
    # DQN internal (32 dims)
    "curiosity_signal": 8,
    "action_history_embedding": 8,
    "reward_prediction": 8,
    "uncertainty_estimate": 8
}
```

---

## Tokenization & Context

| Property | Value |
|----------|-------|
| **Tokenizer** | phi3 tokenizer (tiktoken-based) |
| **Context Length** | 4096 tokens |
| **Max Output** | 2048 tokens |
| **Vocab Size** | 32,000 |

---

## Training

### Pre-training (Base SLM)
- **Model**: phi3:mini from Microsoft
- **Data**: Web text, books, code
- **Tokens**: ~1.4T tokens

### RL Training (DQN + RLHF)
- **Method**: 
  - DQN with prioritized experience replay
  - RLHF with Bradley-Terry preference learning
  - RND curiosity for exploration
- **Reward Sources**:
  - Human feedback (++, +, -, --)
  - Learned reward model
  - Intrinsic curiosity bonus
  - Task completion signals

### Training Data Format

```python
# DQN Transition
{
    "state": [64-dim float vector],
    "action": int,  # 0-6
    "reward": float,  # combined reward
    "next_state": [64-dim float vector],
    "done": bool
}

# RLHF Feedback
{
    "state": [64-dim float vector],
    "action": int,
    "feedback": float,  # -1 to +1
    "response": str,
    "timestamp": str
}
```

---

## API Usage

### OpenAI-Compatible Endpoint

```bash
# Start server
python api_server.py --port 8000

# Chat completion
curl -X POST http://localhost:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "dheera-v0.3.0",
    "messages": [{"role": "user", "content": "Hello!"}],
    "temperature": 0.7
  }'
```

### Python SDK

```python
from openai import OpenAI

client = OpenAI(
    base_url="http://localhost:8000/v1",
    api_key="not-needed"
)

response = client.chat.completions.create(
    model="dheera-v0.3.0",
    messages=[
        {"role": "user", "content": "Explain quantum computing"}
    ]
)

print(response.choices[0].message.content)
```

### Dheera-Specific Options

```python
# Get action info in response
response = requests.post(
    "http://localhost:8000/v1/chat/completions",
    json={
        "model": "dheera-v0.3.0",
        "messages": [{"role": "user", "content": "Write a sorting algorithm"}],
        "use_dqn": True,         # Enable DQN action selection
        "use_rlhf": True,        # Enable RLHF scoring
        "use_curiosity": True,   # Enable curiosity bonus
        "return_action_info": True  # Include action details
    }
)

# Response includes:
# - action_taken: "USE_TOOL"
# - action_confidence: 0.85
# - reward_score: 0.72
# - curiosity_bonus: 0.03
```

### Providing Feedback

```python
# Rate a response for RLHF
requests.post(
    "http://localhost:8000/v1/feedback",
    json={
        "response_id": "dheera-abc123",
        "feedback_type": "++"  # or rating: 0.8
    }
)
```

---

## Performance

### Latency (CPU, M1 MacBook)

| Operation | Time |
|-----------|------|
| State building | ~2ms |
| DQN action selection | ~1ms |
| RLHF scoring | ~1ms |
| SLM generation (100 tokens) | ~2-5s |
| **Total** | ~2-5s |

### Memory Usage

| Component | RAM |
|-----------|-----|
| DQN + Curiosity + RLHF | ~50MB |
| phi3:mini (Ollama) | ~2.5GB |
| Replay Buffer (100K) | ~500MB |
| **Total** | ~3GB |

---

## Limitations

1. **SLM Dependency**: Requires Ollama with phi3:mini
2. **Cold Start**: First request loads models (~5-10s)
3. **Context Limit**: 4096 tokens (inherited from phi3)
4. **No Streaming**: Streaming not fully implemented
5. **Single User**: Session management is basic

---

## Intended Use

### ✅ Recommended Uses
- Interactive AI assistant
- Educational tool for RL research
- Prototype for adaptive AI systems
- Learning how to combine RL with LLMs

### ❌ Not Recommended For
- Production deployment without hardening
- Safety-critical applications
- High-throughput services
- Applications requiring deterministic behavior

---

## Citation

```bibtex
@software{dheera2024,
  title = {Dheera: Adaptive AI Agent with RLHF, DQN, and SLM Integration},
  author = {Nandha Vignesh},
  year = {2024},
  version = {0.3.0},
  url = {https://github.com/your-repo/dheera}
}
```

---

## Files

```
dheera_v3_complete/
├── api_server.py        # FastAPI server (OpenAI-compatible)
├── api_client.py        # Client examples
├── train_and_save.py    # Training script
├── run_chat.py          # Terminal chat interface
├── run_demo.py          # Quick demo
├── dheera.py            # Main orchestrator
├── core/
│   ├── dqn_agent.py     # DQN implementation
│   ├── rainbow_dqn.py   # Full Rainbow DQN
│   ├── curiosity_rnd.py # RND curiosity
│   ├── state_builder.py # State encoding
│   └── action_space.py  # Action definitions
├── rlhf/
│   ├── reward_model.py  # Learned reward
│   ├── preference_learner.py
│   └── feedback_collector.py
├── brain/
│   ├── slm_interface.py # Ollama integration
│   ├── executor.py      # Action execution
│   └── policy.py        # Safety policies
└── trained_models/      # Saved weights
```

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 0.3.0 | 2024-12 | API server, RLHF training, full Rainbow DQN |
| 0.2.0 | 2024-11 | Web search, 7-action space, curiosity |
| 0.1.0 | 2024-10 | Initial DQN + Ollama integration |
