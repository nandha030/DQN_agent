# core/curiosity_rnd.py
"""
Dheera v0.3.0 - Curiosity Module (RND)
Random Network Distillation for intrinsic motivation.
"""

import numpy as np
from typing import Optional, Tuple, Dict, Any
from collections import deque

try:
    import torch
    import torch.nn as nn
    import torch.optim as optim
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False


if TORCH_AVAILABLE:
    class RNDNetwork(nn.Module):
        """
        Random Network Distillation network.
        Fixed target + trainable predictor.
        """
        
        def __init__(
            self,
            state_dim: int = 64,
            hidden_dim: int = 128,
            output_dim: int = 64,
        ):
            super().__init__()
            
            # Fixed random target network (not trained)
            self.target = nn.Sequential(
                nn.Linear(state_dim, hidden_dim),
                nn.ReLU(),
                nn.Linear(hidden_dim, hidden_dim),
                nn.ReLU(),
                nn.Linear(hidden_dim, output_dim),
            )
            
            # Trainable predictor network
            self.predictor = nn.Sequential(
                nn.Linear(state_dim, hidden_dim),
                nn.ReLU(),
                nn.Linear(hidden_dim, hidden_dim),
                nn.ReLU(),
                nn.Linear(hidden_dim, output_dim),
            )
            
            # Freeze target network
            for param in self.target.parameters():
                param.requires_grad = False
        
        def forward(self, state: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
            """Forward pass returning target and predictor outputs."""
            with torch.no_grad():
                target_out = self.target(state)
            predictor_out = self.predictor(state)
            return target_out, predictor_out
        
        def get_intrinsic_reward(self, state: torch.Tensor) -> torch.Tensor:
            """Compute intrinsic reward as prediction error."""
            target_out, predictor_out = self.forward(state)
            intrinsic_reward = torch.mean((target_out - predictor_out) ** 2, dim=-1)
            return intrinsic_reward


class CuriosityModule:
    """
    Curiosity-driven exploration using Random Network Distillation (RND).
    
    Provides intrinsic rewards for novel states to encourage exploration.
    """
    
    def __init__(
        self,
        state_dim: int = 64,
        hidden_dim: int = 128,
        output_dim: int = 64,
        learning_rate: float = 1e-4,
        intrinsic_reward_coef: float = 0.1,
        reward_norm_steps: int = 1000,
        device: str = "cpu",
    ):
        self.state_dim = state_dim
        self.hidden_dim = hidden_dim
        self.output_dim = output_dim
        self.intrinsic_reward_coef = intrinsic_reward_coef
        self.device = device
        
        # Running statistics for reward normalization
        self.reward_mean = 0.0
        self.reward_var = 1.0
        self.reward_count = 0
        self.reward_norm_steps = reward_norm_steps
        self.recent_rewards = deque(maxlen=1000)
        
        # Initialize networks if PyTorch available
        if TORCH_AVAILABLE:
            self.rnd = RNDNetwork(state_dim, hidden_dim, output_dim).to(device)
            self.optimizer = optim.Adam(
                self.rnd.predictor.parameters(),
                lr=learning_rate
            )
        else:
            self.rnd = None
            self.optimizer = None
            # Fallback: hash-based novelty
            self.state_hashes = set()
        
        # Statistics
        self.total_updates = 0
        self.avg_intrinsic_reward = 0.0
    
    def compute_intrinsic_reward(
        self,
        state: np.ndarray,
        normalize: bool = True,
    ) -> float:
        """
        Compute intrinsic reward for a state.
        
        Args:
            state: State vector
            normalize: Whether to normalize reward
            
        Returns:
            Intrinsic reward value
        """
        if TORCH_AVAILABLE and self.rnd is not None:
            with torch.no_grad():
                state_tensor = torch.FloatTensor(state).unsqueeze(0).to(self.device)
                intrinsic_reward = self.rnd.get_intrinsic_reward(state_tensor).item()
        else:
            # Fallback: hash-based novelty
            state_hash = hash(state.tobytes())
            if state_hash in self.state_hashes:
                intrinsic_reward = 0.01  # Small reward for seen states
            else:
                self.state_hashes.add(state_hash)
                intrinsic_reward = 1.0  # Large reward for novel states
        
        # Update running statistics
        self.recent_rewards.append(intrinsic_reward)
        self._update_reward_stats(intrinsic_reward)
        
        # Normalize
        if normalize and self.reward_count > self.reward_norm_steps:
            intrinsic_reward = (intrinsic_reward - self.reward_mean) / (np.sqrt(self.reward_var) + 1e-8)
            intrinsic_reward = np.clip(intrinsic_reward, -5, 5)
        
        # Scale by coefficient
        intrinsic_reward *= self.intrinsic_reward_coef
        
        return intrinsic_reward
    
    def _update_reward_stats(self, reward: float):
        """Update running mean and variance."""
        self.reward_count += 1
        delta = reward - self.reward_mean
        self.reward_mean += delta / self.reward_count
        delta2 = reward - self.reward_mean
        self.reward_var += (delta * delta2 - self.reward_var) / self.reward_count
    
    def update(self, state: np.ndarray) -> Dict[str, float]:
        """
        Update predictor network to reduce prediction error.
        
        Args:
            state: State to learn
            
        Returns:
            Training statistics
        """
        if not TORCH_AVAILABLE or self.rnd is None:
            return {"loss": 0.0}
        
        state_tensor = torch.FloatTensor(state).unsqueeze(0).to(self.device)
        
        # Forward pass
        target_out, predictor_out = self.rnd(state_tensor)
        
        # Compute loss
        loss = torch.mean((target_out - predictor_out) ** 2)
        
        # Backward pass
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        
        self.total_updates += 1
        
        return {"loss": loss.item()}
    
    def update_batch(self, states: np.ndarray) -> Dict[str, float]:
        """
        Update predictor network on a batch of states.
        
        Args:
            states: Batch of states (N x state_dim)
            
        Returns:
            Training statistics
        """
        if not TORCH_AVAILABLE or self.rnd is None:
            return {"loss": 0.0, "batch_size": len(states)}
        
        states_tensor = torch.FloatTensor(states).to(self.device)
        
        # Forward pass
        target_out, predictor_out = self.rnd(states_tensor)
        
        # Compute loss
        loss = torch.mean((target_out - predictor_out) ** 2)
        
        # Backward pass
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        
        self.total_updates += 1
        
        return {
            "loss": loss.item(),
            "batch_size": len(states),
        }
    
    def get_novelty_score(self, state: np.ndarray) -> float:
        """
        Get novelty score for a state (non-normalized).
        Higher = more novel.
        """
        if TORCH_AVAILABLE and self.rnd is not None:
            with torch.no_grad():
                state_tensor = torch.FloatTensor(state).unsqueeze(0).to(self.device)
                novelty = self.rnd.get_intrinsic_reward(state_tensor).item()
        else:
            state_hash = hash(state.tobytes())
            novelty = 1.0 if state_hash not in self.state_hashes else 0.1
        
        return novelty
    
    def get_batch_novelty(self, states: np.ndarray) -> np.ndarray:
        """Get novelty scores for a batch of states."""
        if TORCH_AVAILABLE and self.rnd is not None:
            with torch.no_grad():
                states_tensor = torch.FloatTensor(states).to(self.device)
                novelties = self.rnd.get_intrinsic_reward(states_tensor).cpu().numpy()
        else:
            novelties = np.array([self.get_novelty_score(s) for s in states])
        
        return novelties
    
    def get_stats(self) -> Dict[str, Any]:
        """Get curiosity module statistics."""
        avg_recent = np.mean(self.recent_rewards) if self.recent_rewards else 0.0
        
        return {
            "total_updates": self.total_updates,
            "reward_mean": self.reward_mean,
            "reward_std": np.sqrt(self.reward_var),
            "reward_count": self.reward_count,
            "avg_recent_intrinsic": avg_recent,
            "intrinsic_coef": self.intrinsic_reward_coef,
            "unique_states": len(self.state_hashes) if not TORCH_AVAILABLE else "N/A",
        }
    
    def save(self, path: str):
        """Save curiosity module."""
        if TORCH_AVAILABLE and self.rnd is not None:
            torch.save({
                "rnd_state_dict": self.rnd.state_dict(),
                "optimizer_state_dict": self.optimizer.state_dict(),
                "reward_mean": self.reward_mean,
                "reward_var": self.reward_var,
                "reward_count": self.reward_count,
                "total_updates": self.total_updates,
            }, path)
    
    def load(self, path: str):
        """Load curiosity module."""
        if TORCH_AVAILABLE and self.rnd is not None:
            checkpoint = torch.load(path, map_location=self.device)
            self.rnd.load_state_dict(checkpoint["rnd_state_dict"])
            self.optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
            self.reward_mean = checkpoint.get("reward_mean", 0.0)
            self.reward_var = checkpoint.get("reward_var", 1.0)
            self.reward_count = checkpoint.get("reward_count", 0)
            self.total_updates = checkpoint.get("total_updates", 0)


# ==================== Testing ====================
if __name__ == "__main__":
    print("Testing CuriosityModule...")
    
    curiosity = CuriosityModule(
        state_dim=64,
        hidden_dim=128,
        intrinsic_reward_coef=0.1,
    )
    
    # Test intrinsic reward
    state = np.random.randn(64).astype(np.float32)
    reward1 = curiosity.compute_intrinsic_reward(state)
    print(f"✓ First visit intrinsic reward: {reward1:.4f}")
    
    # Same state should have lower reward after learning
    curiosity.update(state)
    reward2 = curiosity.compute_intrinsic_reward(state)
    print(f"✓ After update intrinsic reward: {reward2:.4f}")
    
    # Batch update
    states = np.random.randn(32, 64).astype(np.float32)
    stats = curiosity.update_batch(states)
    print(f"✓ Batch update loss: {stats['loss']:.4f}")
    
    # Novelty scores
    novelty = curiosity.get_novelty_score(state)
    print(f"✓ Novelty score: {novelty:.4f}")
    
    # Stats
    module_stats = curiosity.get_stats()
    print(f"✓ Total updates: {module_stats['total_updates']}")
    
    print("\n✅ CuriosityModule tests passed!")
