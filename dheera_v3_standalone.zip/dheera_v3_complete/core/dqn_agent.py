# core/dqn_agent.py
"""
Alias module for backwards compatibility.
Imports from rainbow_dqn.py
"""

from core.rainbow_dqn import (
    DQNAgent,
    TinyDQN,
    RNDModule,
    ReplayBuffer,
    PrioritizedReplayBuffer,
    Transition,
)

__all__ = [
    "DQNAgent",
    "TinyDQN",
    "RNDModule",
    "ReplayBuffer",
    "PrioritizedReplayBuffer",
    "Transition",
]
