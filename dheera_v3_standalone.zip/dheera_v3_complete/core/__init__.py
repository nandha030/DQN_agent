# core/__init__.py
"""
Dheera v0.3.0 - Core Package
DQN Agent, Curiosity, State Builder, Action Space.
"""

from core.rainbow_dqn import DQNAgent, TinyDQN, RNDModule, ReplayBuffer, PrioritizedReplayBuffer
from core.curiosity_rnd import CuriosityModule
from core.state_builder import StateBuilder, ConversationContext
from core.action_space import ActionSpace, Action, ActionType

# Try to import RNDNetwork (only available with PyTorch)
try:
    from core.curiosity_rnd import RNDNetwork
except ImportError:
    RNDNetwork = None

# Alias for backwards compatibility
RainbowDQNAgent = DQNAgent

__all__ = [
    "DQNAgent",
    "RainbowDQNAgent",  # Alias
    "TinyDQN",
    "RNDModule",
    "ReplayBuffer",
    "PrioritizedReplayBuffer",
    "CuriosityModule",
    "RNDNetwork",
    "StateBuilder",
    "ConversationContext",
    "ActionSpace",
    "Action",
    "ActionType",
]
