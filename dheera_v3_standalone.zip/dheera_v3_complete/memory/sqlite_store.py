# memory/sqlite_store.py
"""
Dheera v0.3.0 - SQLite Store
Persistent storage backend for episodic memory and replay buffer.
"""

import sqlite3
import json
import time
import threading
from pathlib import Path
from typing import List, Dict, Optional, Any, Tuple
from dataclasses import asdict
import numpy as np


class SQLiteStore:
    """
    SQLite-based persistent storage for Dheera memory systems.
    Thread-safe with connection pooling.
    """
    
    def __init__(
        self,
        db_path: str = "dheera_memory.db",
        check_same_thread: bool = False,
    ):
        self.db_path = db_path
        self.check_same_thread = check_same_thread
        self._local = threading.local()
        
        # Initialize schema
        self._init_schema()
    
    def _get_connection(self) -> sqlite3.Connection:
        """Get thread-local connection."""
        if not hasattr(self._local, 'connection') or self._local.connection is None:
            self._local.connection = sqlite3.connect(
                self.db_path,
                check_same_thread=self.check_same_thread,
            )
            self._local.connection.row_factory = sqlite3.Row
        return self._local.connection
    
    def _init_schema(self):
        """Initialize database schema."""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        # Episodes table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS episodes (
                episode_id TEXT PRIMARY KEY,
                start_time REAL,
                end_time REAL,
                total_reward REAL DEFAULT 0,
                summary TEXT,
                tags TEXT,
                metadata TEXT,
                action_distribution TEXT,
                search_count INTEGER DEFAULT 0,
                tool_count INTEGER DEFAULT 0
            )
        """)
        
        # Memory entries table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS memory_entries (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                episode_id TEXT,
                turn_id INTEGER,
                user_message TEXT,
                assistant_response TEXT,
                action_taken INTEGER,
                action_name TEXT,
                reward REAL,
                state_vector BLOB,
                timestamp REAL,
                metadata TEXT,
                search_performed INTEGER DEFAULT 0,
                search_query TEXT,
                search_result_count INTEGER DEFAULT 0,
                tool_used TEXT,
                response_latency_ms REAL DEFAULT 0,
                FOREIGN KEY (episode_id) REFERENCES episodes(episode_id)
            )
        """)
        
        # Replay buffer table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS replay_buffer (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                state BLOB,
                action INTEGER,
                reward REAL,
                next_state BLOB,
                done REAL,
                priority REAL DEFAULT 1.0,
                timestamp REAL,
                search_performed INTEGER DEFAULT 0,
                tool_used TEXT
            )
        """)
        
        # Indexes
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_entries_episode 
            ON memory_entries(episode_id)
        """)
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_entries_timestamp 
            ON memory_entries(timestamp)
        """)
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_replay_priority 
            ON replay_buffer(priority DESC)
        """)
        
        conn.commit()
    
    # ==================== Episode Operations ====================
    
    def save_episode(
        self,
        episode_id: str,
        start_time: float,
        end_time: Optional[float] = None,
        total_reward: float = 0.0,
        summary: str = "",
        tags: List[str] = None,
        metadata: Dict = None,
        action_distribution: Dict[int, int] = None,
        search_count: int = 0,
        tool_count: int = 0,
    ):
        """Save or update an episode."""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT OR REPLACE INTO episodes 
            (episode_id, start_time, end_time, total_reward, summary, 
             tags, metadata, action_distribution, search_count, tool_count)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            episode_id,
            start_time,
            end_time,
            total_reward,
            summary,
            json.dumps(tags or []),
            json.dumps(metadata or {}),
            json.dumps(action_distribution or {}),
            search_count,
            tool_count,
        ))
        
        conn.commit()
    
    def get_episode(self, episode_id: str) -> Optional[Dict]:
        """Get episode by ID."""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute(
            "SELECT * FROM episodes WHERE episode_id = ?",
            (episode_id,)
        )
        row = cursor.fetchone()
        
        if row:
            return self._row_to_episode(row)
        return None
    
    def get_recent_episodes(self, limit: int = 10) -> List[Dict]:
        """Get most recent episodes."""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute(
            "SELECT * FROM episodes ORDER BY start_time DESC LIMIT ?",
            (limit,)
        )
        
        return [self._row_to_episode(row) for row in cursor.fetchall()]
    
    def _row_to_episode(self, row: sqlite3.Row) -> Dict:
        """Convert row to episode dict."""
        return {
            "episode_id": row["episode_id"],
            "start_time": row["start_time"],
            "end_time": row["end_time"],
            "total_reward": row["total_reward"],
            "summary": row["summary"],
            "tags": json.loads(row["tags"]) if row["tags"] else [],
            "metadata": json.loads(row["metadata"]) if row["metadata"] else {},
            "action_distribution": json.loads(row["action_distribution"]) if row["action_distribution"] else {},
            "search_count": row["search_count"],
            "tool_count": row["tool_count"],
        }
    
    # ==================== Memory Entry Operations ====================
    
    def save_memory_entry(
        self,
        episode_id: str,
        turn_id: int,
        user_message: str,
        assistant_response: str,
        action_taken: int,
        action_name: str,
        reward: float,
        state_vector: np.ndarray,
        timestamp: float = None,
        metadata: Dict = None,
        search_performed: bool = False,
        search_query: str = None,
        search_result_count: int = 0,
        tool_used: str = None,
        response_latency_ms: float = 0.0,
    ) -> int:
        """Save a memory entry."""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO memory_entries 
            (episode_id, turn_id, user_message, assistant_response,
             action_taken, action_name, reward, state_vector, timestamp,
             metadata, search_performed, search_query, search_result_count,
             tool_used, response_latency_ms)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            episode_id,
            turn_id,
            user_message,
            assistant_response,
            action_taken,
            action_name,
            reward,
            state_vector.tobytes() if isinstance(state_vector, np.ndarray) else state_vector,
            timestamp or time.time(),
            json.dumps(metadata or {}),
            1 if search_performed else 0,
            search_query,
            search_result_count,
            tool_used,
            response_latency_ms,
        ))
        
        conn.commit()
        return cursor.lastrowid
    
    def get_episode_entries(
        self,
        episode_id: str,
        state_dim: int = 64,
    ) -> List[Dict]:
        """Get all entries for an episode."""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute(
            "SELECT * FROM memory_entries WHERE episode_id = ? ORDER BY turn_id",
            (episode_id,)
        )
        
        return [self._row_to_entry(row, state_dim) for row in cursor.fetchall()]
    
    def search_entries(
        self,
        query: str,
        limit: int = 10,
        state_dim: int = 64,
    ) -> List[Dict]:
        """Search entries by text."""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT * FROM memory_entries 
            WHERE user_message LIKE ? OR assistant_response LIKE ?
            ORDER BY timestamp DESC
            LIMIT ?
        """, (f"%{query}%", f"%{query}%", limit))
        
        return [self._row_to_entry(row, state_dim) for row in cursor.fetchall()]
    
    def _row_to_entry(self, row: sqlite3.Row, state_dim: int = 64) -> Dict:
        """Convert row to entry dict."""
        state_vector = np.frombuffer(row["state_vector"], dtype=np.float32)
        if len(state_vector) != state_dim:
            state_vector = np.zeros(state_dim, dtype=np.float32)
        
        return {
            "id": row["id"],
            "episode_id": row["episode_id"],
            "turn_id": row["turn_id"],
            "user_message": row["user_message"],
            "assistant_response": row["assistant_response"],
            "action_taken": row["action_taken"],
            "action_name": row["action_name"],
            "reward": row["reward"],
            "state_vector": state_vector,
            "timestamp": row["timestamp"],
            "metadata": json.loads(row["metadata"]) if row["metadata"] else {},
            "search_performed": bool(row["search_performed"]),
            "search_query": row["search_query"],
            "search_result_count": row["search_result_count"],
            "tool_used": row["tool_used"],
            "response_latency_ms": row["response_latency_ms"],
        }
    
    # ==================== Replay Buffer Operations ====================
    
    def save_transition(
        self,
        state: np.ndarray,
        action: int,
        reward: float,
        next_state: np.ndarray,
        done: float,
        priority: float = 1.0,
        search_performed: bool = False,
        tool_used: str = None,
    ) -> int:
        """Save a transition to replay buffer."""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO replay_buffer 
            (state, action, reward, next_state, done, priority, timestamp,
             search_performed, tool_used)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            state.tobytes(),
            action,
            reward,
            next_state.tobytes(),
            done,
            priority,
            time.time(),
            1 if search_performed else 0,
            tool_used,
        ))
        
        conn.commit()
        return cursor.lastrowid
    
    def sample_transitions(
        self,
        batch_size: int,
        state_dim: int = 64,
        prioritized: bool = False,
    ) -> List[Dict]:
        """Sample transitions from replay buffer."""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        if prioritized:
            cursor.execute("""
                SELECT * FROM replay_buffer 
                ORDER BY priority DESC
                LIMIT ?
            """, (batch_size * 2,))
        else:
            cursor.execute("""
                SELECT * FROM replay_buffer 
                ORDER BY RANDOM()
                LIMIT ?
            """, (batch_size,))
        
        rows = cursor.fetchall()
        
        if prioritized and len(rows) > batch_size:
            # Weighted sampling by priority
            import random
            rows = random.sample(rows, batch_size)
        
        return [self._row_to_transition(row, state_dim) for row in rows]
    
    def update_priorities(self, ids: List[int], priorities: List[float]):
        """Update priorities for transitions."""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        for id_, priority in zip(ids, priorities):
            cursor.execute(
                "UPDATE replay_buffer SET priority = ? WHERE id = ?",
                (priority, id_)
            )
        
        conn.commit()
    
    def get_buffer_size(self) -> int:
        """Get replay buffer size."""
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM replay_buffer")
        return cursor.fetchone()[0]
    
    def trim_buffer(self, max_size: int):
        """Remove oldest transitions to maintain max size."""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        current_size = self.get_buffer_size()
        if current_size > max_size:
            delete_count = current_size - max_size
            cursor.execute("""
                DELETE FROM replay_buffer 
                WHERE id IN (
                    SELECT id FROM replay_buffer 
                    ORDER BY timestamp ASC 
                    LIMIT ?
                )
            """, (delete_count,))
            conn.commit()
    
    def _row_to_transition(self, row: sqlite3.Row, state_dim: int = 64) -> Dict:
        """Convert row to transition dict."""
        state = np.frombuffer(row["state"], dtype=np.float32)
        next_state = np.frombuffer(row["next_state"], dtype=np.float32)
        
        if len(state) != state_dim:
            state = np.zeros(state_dim, dtype=np.float32)
        if len(next_state) != state_dim:
            next_state = np.zeros(state_dim, dtype=np.float32)
        
        return {
            "id": row["id"],
            "state": state,
            "action": row["action"],
            "reward": row["reward"],
            "next_state": next_state,
            "done": row["done"],
            "priority": row["priority"],
            "timestamp": row["timestamp"],
            "search_performed": bool(row["search_performed"]),
            "tool_used": row["tool_used"],
        }
    
    # ==================== Statistics ====================
    
    def get_stats(self) -> Dict[str, Any]:
        """Get storage statistics."""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM episodes")
        episode_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM memory_entries")
        entry_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM replay_buffer")
        buffer_size = cursor.fetchone()[0]
        
        cursor.execute("SELECT SUM(total_reward) FROM episodes")
        total_reward = cursor.fetchone()[0] or 0.0
        
        return {
            "episode_count": episode_count,
            "entry_count": entry_count,
            "buffer_size": buffer_size,
            "total_reward": total_reward,
            "db_path": self.db_path,
        }
    
    def close(self):
        """Close all connections."""
        if hasattr(self._local, 'connection') and self._local.connection:
            self._local.connection.close()
            self._local.connection = None


# ==================== Testing ====================
if __name__ == "__main__":
    import tempfile
    import os
    
    print("Testing SQLiteStore...")
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        store = SQLiteStore(db_path)
        
        # Test episode
        store.save_episode(
            episode_id="test_ep_1",
            start_time=time.time(),
            total_reward=1.5,
            summary="Test episode",
        )
        
        episode = store.get_episode("test_ep_1")
        print(f"✓ Episode saved: {episode['episode_id']}")
        
        # Test memory entry
        state = np.random.randn(64).astype(np.float32)
        entry_id = store.save_memory_entry(
            episode_id="test_ep_1",
            turn_id=1,
            user_message="Hello",
            assistant_response="Hi there!",
            action_taken=0,
            action_name="DIRECT_RESPONSE",
            reward=0.5,
            state_vector=state,
        )
        print(f"✓ Entry saved: {entry_id}")
        
        # Test transition
        next_state = np.random.randn(64).astype(np.float32)
        trans_id = store.save_transition(
            state=state,
            action=0,
            reward=0.5,
            next_state=next_state,
            done=0.0,
        )
        print(f"✓ Transition saved: {trans_id}")
        
        # Test sampling
        samples = store.sample_transitions(batch_size=1)
        print(f"✓ Sampled {len(samples)} transitions")
        
        # Stats
        stats = store.get_stats()
        print(f"✓ Stats: {stats}")
        
        store.close()
    
    print("\n✅ SQLiteStore tests passed!")
