#!/usr/bin/env python3
"""
Dheera API Client Examples
==========================
Shows how to interact with the Dheera RLHF+DQN+SLM model via API.

Usage:
    # Start the server first:
    python api_server.py
    
    # Then run examples:
    python api_client.py
    python api_client.py --interactive
    python api_client.py --curl-examples
"""

import argparse
import json
from typing import Optional

# Try different HTTP clients
try:
    import httpx
    HTTP_CLIENT = "httpx"
except ImportError:
    try:
        import requests
        HTTP_CLIENT = "requests"
    except ImportError:
        HTTP_CLIENT = None


class DheeraClient:
    """
    Client for the Dheera API.
    
    Example usage with OpenAI SDK:
    ```python
    from openai import OpenAI
    
    client = OpenAI(
        base_url="http://localhost:8000/v1",
        api_key="not-needed"
    )
    
    response = client.chat.completions.create(
        model="dheera-v0.3.0",
        messages=[{"role": "user", "content": "Hello!"}]
    )
    print(response.choices[0].message.content)
    ```
    """
    
    def __init__(self, base_url: str = "http://localhost:8000"):
        self.base_url = base_url.rstrip("/")
        
        if HTTP_CLIENT == "httpx":
            self.client = httpx.Client(timeout=60.0)
        elif HTTP_CLIENT == "requests":
            import requests
            self.session = requests.Session()
        else:
            raise ImportError("Please install httpx or requests: pip install httpx")
    
    def _post(self, endpoint: str, data: dict) -> dict:
        """Make POST request."""
        url = f"{self.base_url}{endpoint}"
        
        if HTTP_CLIENT == "httpx":
            response = self.client.post(url, json=data)
            response.raise_for_status()
            return response.json()
        else:
            response = self.session.post(url, json=data)
            response.raise_for_status()
            return response.json()
    
    def _get(self, endpoint: str) -> dict:
        """Make GET request."""
        url = f"{self.base_url}{endpoint}"
        
        if HTTP_CLIENT == "httpx":
            response = self.client.get(url)
            response.raise_for_status()
            return response.json()
        else:
            response = self.session.get(url)
            response.raise_for_status()
            return response.json()
    
    def health(self) -> dict:
        """Check server health."""
        return self._get("/health")
    
    def stats(self) -> dict:
        """Get server statistics."""
        return self._get("/stats")
    
    def models(self) -> dict:
        """List available models."""
        return self._get("/v1/models")
    
    def model_info(self, model_id: str = "dheera-v0.3.0") -> dict:
        """Get model information."""
        return self._get(f"/v1/models/{model_id}")
    
    def chat(
        self,
        messages: list,
        model: str = "dheera-v0.3.0",
        temperature: float = 0.7,
        max_tokens: int = 1024,
        use_dqn: bool = True,
        use_rlhf: bool = True,
        use_curiosity: bool = True,
        return_action_info: bool = False,
        user: Optional[str] = None
    ) -> dict:
        """
        Send chat completion request.
        
        Args:
            messages: List of {"role": "user/assistant/system", "content": "..."}
            model: Model ID
            temperature: Sampling temperature
            max_tokens: Maximum tokens to generate
            use_dqn: Use DQN for action selection
            use_rlhf: Apply RLHF reward scoring
            use_curiosity: Include curiosity bonus
            return_action_info: Include action details in response
            user: Session/user ID for conversation tracking
        """
        return self._post("/v1/chat/completions", {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "use_dqn": use_dqn,
            "use_rlhf": use_rlhf,
            "use_curiosity": use_curiosity,
            "return_action_info": return_action_info,
            "user": user
        })
    
    def complete(
        self,
        prompt: str,
        model: str = "dheera-v0.3.0",
        temperature: float = 0.7,
        max_tokens: int = 1024
    ) -> dict:
        """Send text completion request."""
        return self._post("/v1/completions", {
            "model": model,
            "prompt": prompt,
            "temperature": temperature,
            "max_tokens": max_tokens
        })
    
    def feedback(
        self,
        response_id: str,
        rating: float = None,
        feedback_type: str = None
    ) -> dict:
        """
        Provide feedback for RLHF training.
        
        Args:
            response_id: ID from previous response
            rating: Numeric rating from -1 to 1
            feedback_type: "++", "+", "-", or "--"
        """
        data = {"response_id": response_id}
        if rating is not None:
            data["rating"] = rating
        if feedback_type is not None:
            data["feedback_type"] = feedback_type
            
        return self._post("/v1/feedback", data)


def print_curl_examples():
    """Print curl command examples."""
    print("""
╔═══════════════════════════════════════════════════════════════╗
║              CURL EXAMPLES FOR DHEERA API                     ║
╚═══════════════════════════════════════════════════════════════╝

# 1. Health Check
curl http://localhost:8000/health

# 2. Get Model Info
curl http://localhost:8000/v1/models/dheera-v0.3.0

# 3. Chat Completion (Basic)
curl -X POST http://localhost:8000/v1/chat/completions \\
  -H "Content-Type: application/json" \\
  -d '{
    "model": "dheera-v0.3.0",
    "messages": [{"role": "user", "content": "What is machine learning?"}]
  }'

# 4. Chat with Action Info
curl -X POST http://localhost:8000/v1/chat/completions \\
  -H "Content-Type: application/json" \\
  -d '{
    "model": "dheera-v0.3.0",
    "messages": [{"role": "user", "content": "Help me write Python code"}],
    "return_action_info": true,
    "use_dqn": true,
    "use_rlhf": true
  }'

# 5. Text Completion
curl -X POST http://localhost:8000/v1/completions \\
  -H "Content-Type: application/json" \\
  -d '{
    "model": "dheera-v0.3.0",
    "prompt": "Explain quantum computing in simple terms:"
  }'

# 6. Provide Feedback (RLHF)
curl -X POST http://localhost:8000/v1/feedback \\
  -H "Content-Type: application/json" \\
  -d '{
    "response_id": "dheera-abc123",
    "rating": 0.8
  }'

# 7. Get Statistics
curl http://localhost:8000/stats

# ─────────────────────────────────────────────────────────────
# Using with OpenAI Python SDK
# ─────────────────────────────────────────────────────────────

from openai import OpenAI

client = OpenAI(
    base_url="http://localhost:8000/v1",
    api_key="not-needed"  # No API key required
)

response = client.chat.completions.create(
    model="dheera-v0.3.0",
    messages=[
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": "Hello! What can you do?"}
    ],
    temperature=0.7,
    max_tokens=1024
)

print(response.choices[0].message.content)

# ─────────────────────────────────────────────────────────────
# Using with LangChain
# ─────────────────────────────────────────────────────────────

from langchain_openai import ChatOpenAI

llm = ChatOpenAI(
    base_url="http://localhost:8000/v1",
    api_key="not-needed",
    model="dheera-v0.3.0"
)

response = llm.invoke("What is the capital of France?")
print(response.content)
    """)


def run_examples(client: DheeraClient):
    """Run example API calls."""
    print("\n" + "=" * 60)
    print("Running Dheera API Examples")
    print("=" * 60)
    
    # 1. Health check
    print("\n📍 1. Health Check")
    print("-" * 40)
    health = client.health()
    print(json.dumps(health, indent=2))
    
    # 2. Model info
    print("\n📍 2. Model Information")
    print("-" * 40)
    model_info = client.model_info()
    print(f"Model: {model_info.get('name', 'N/A')}")
    print(f"Version: {model_info.get('version', 'N/A')}")
    specs = model_info.get('specifications', {})
    print(f"Base Model: {specs.get('base_model', 'N/A')} ({specs.get('base_params', 'N/A')})")
    print(f"Context Length: {specs.get('context_length', 'N/A')} tokens")
    print(f"Action Space: {specs.get('action_space', 'N/A')} actions")
    print(f"Actions: {', '.join(specs.get('supported_actions', []))}")
    
    # 3. Basic chat
    print("\n📍 3. Basic Chat")
    print("-" * 40)
    response = client.chat(
        messages=[{"role": "user", "content": "What is machine learning?"}],
        return_action_info=True
    )
    print(f"Response ID: {response.get('id', 'N/A')}")
    if response.get('choices'):
        choice = response['choices'][0]
        print(f"Action: {choice.get('action_taken', 'N/A')}")
        print(f"Confidence: {choice.get('action_confidence', 0):.2f}")
        print(f"RLHF Score: {choice.get('reward_score', 0):.4f}")
        print(f"Response: {choice['message']['content'][:200]}...")
    
    # 4. Multi-turn conversation
    print("\n📍 4. Multi-turn Conversation")
    print("-" * 40)
    session_id = "example-session-123"
    
    messages = [{"role": "user", "content": "I want to learn Python."}]
    response1 = client.chat(messages=messages, user=session_id)
    assistant1 = response1['choices'][0]['message']['content']
    print(f"User: I want to learn Python.")
    print(f"Dheera: {assistant1[:150]}...")
    
    messages.append({"role": "assistant", "content": assistant1})
    messages.append({"role": "user", "content": "What should I learn first?"})
    response2 = client.chat(messages=messages, user=session_id)
    assistant2 = response2['choices'][0]['message']['content']
    print(f"\nUser: What should I learn first?")
    print(f"Dheera: {assistant2[:150]}...")
    
    # 5. Different queries showing action selection
    print("\n📍 5. Action Selection Examples")
    print("-" * 40)
    
    test_queries = [
        "What is 2+2?",
        "I'm confused about recursion",
        "Write a sorting algorithm",
        "What's the latest news?",
        "Help me design a database"
    ]
    
    for query in test_queries:
        response = client.chat(
            messages=[{"role": "user", "content": query}],
            return_action_info=True
        )
        if response.get('choices'):
            choice = response['choices'][0]
            print(f"  '{query[:30]}...' → {choice.get('action_taken', 'N/A')}")
    
    # 6. Feedback
    print("\n📍 6. Providing Feedback")
    print("-" * 40)
    last_response_id = response.get('id', '')
    if last_response_id:
        feedback_result = client.feedback(last_response_id, feedback_type="++")
        print(f"Feedback sent for {last_response_id}")
        print(f"Result: {feedback_result}")
    
    # 7. Statistics
    print("\n📍 7. Server Statistics")
    print("-" * 40)
    stats = client.stats()
    print(f"Total Requests: {stats.get('requests', 0)}")
    print(f"Tokens Generated: {stats.get('tokens_generated', 0)}")
    print(f"DQN Epsilon: {stats.get('dqn_epsilon', 0):.4f}")
    print("Action Distribution:")
    for action, count in stats.get('action_distribution', {}).items():
        if count > 0:
            print(f"  {action}: {count}")
    
    print("\n" + "=" * 60)
    print("✅ Examples completed!")
    print("=" * 60)


def interactive_chat(client: DheeraClient):
    """Run interactive chat session."""
    print("""
╔═══════════════════════════════════════════════════════════════╗
║           DHEERA INTERACTIVE CHAT                             ║
╠═══════════════════════════════════════════════════════════════╣
║  Commands:                                                    ║
║    /info     - Show model info                                ║
║    /stats    - Show statistics                                ║
║    /action   - Toggle action info display                     ║
║    /feedback <rating> - Rate last response (++/+/-/--)        ║
║    /quit     - Exit                                           ║
╚═══════════════════════════════════════════════════════════════╝
    """)
    
    messages = []
    session_id = f"interactive-{id(client)}"
    show_action_info = True
    last_response_id = None
    
    while True:
        try:
            user_input = input("\n🧑 You: ").strip()
            
            if not user_input:
                continue
                
            # Commands
            if user_input.startswith("/"):
                cmd = user_input.lower().split()[0]
                
                if cmd in ("/quit", "/exit", "/q"):
                    print("👋 Goodbye!")
                    break
                    
                elif cmd == "/info":
                    info = client.model_info()
                    print(f"\n📊 Model: {info.get('name')}")
                    print(f"   Version: {info.get('version')}")
                    specs = info.get('specifications', {})
                    print(f"   Base: {specs.get('base_model')} ({specs.get('base_params')})")
                    continue
                    
                elif cmd == "/stats":
                    stats = client.stats()
                    print(f"\n📈 Requests: {stats.get('requests')}")
                    print(f"   Tokens: {stats.get('tokens_generated')}")
                    continue
                    
                elif cmd == "/action":
                    show_action_info = not show_action_info
                    print(f"   Action info: {'ON' if show_action_info else 'OFF'}")
                    continue
                    
                elif cmd == "/feedback":
                    parts = user_input.split()
                    if len(parts) > 1 and last_response_id:
                        rating = parts[1]
                        result = client.feedback(last_response_id, feedback_type=rating)
                        print(f"   ✓ Feedback '{rating}' recorded")
                    else:
                        print("   Usage: /feedback ++|+|-|--")
                    continue
                    
                else:
                    print(f"   Unknown command: {cmd}")
                    continue
            
            # Chat
            messages.append({"role": "user", "content": user_input})
            
            response = client.chat(
                messages=messages,
                return_action_info=show_action_info,
                user=session_id
            )
            
            if response.get('choices'):
                choice = response['choices'][0]
                assistant_message = choice['message']['content']
                
                print(f"\n🤖 Dheera: {assistant_message}")
                
                if show_action_info:
                    print(f"\n   📍 Action: {choice.get('action_taken', 'N/A')}")
                    print(f"   📊 Confidence: {choice.get('action_confidence', 0):.2f}")
                    print(f"   🎯 RLHF Score: {choice.get('reward_score', 0):.4f}")
                
                messages.append({"role": "assistant", "content": assistant_message})
                last_response_id = response.get('id')
                
        except KeyboardInterrupt:
            print("\n👋 Goodbye!")
            break
        except Exception as e:
            print(f"\n❌ Error: {e}")


def main():
    parser = argparse.ArgumentParser(description="Dheera API Client")
    parser.add_argument("--url", default="http://localhost:8000", help="API URL")
    parser.add_argument("--interactive", "-i", action="store_true", help="Interactive chat mode")
    parser.add_argument("--curl-examples", action="store_true", help="Show curl examples")
    
    args = parser.parse_args()
    
    if args.curl_examples:
        print_curl_examples()
        return
    
    # Create client
    try:
        client = DheeraClient(args.url)
    except ImportError as e:
        print(f"Error: {e}")
        print("Install httpx: pip install httpx")
        return
    
    # Check server
    try:
        health = client.health()
        if health.get("status") != "healthy":
            print("⚠️ Server may not be healthy")
    except Exception as e:
        print(f"❌ Cannot connect to server at {args.url}")
        print(f"   Error: {e}")
        print("\n   Start the server first:")
        print("   python api_server.py")
        return
    
    if args.interactive:
        interactive_chat(client)
    else:
        run_examples(client)


if __name__ == "__main__":
    main()
