# Dheera v0.3.0
# धीर (Sanskrit): Courageous, Wise, Patient
"""
Dheera - A Hybrid AI Agent combining:
- Rainbow DQN (Fast Brain) for action selection
- Ollama Phi3:mini (Slow Brain) for language generation
- RND Curiosity for exploration
- RLHF for learning from human feedback
- RAG + Vector DB for memory
- SQLite for persistence
"""

__version__ = "0.3.0"
__author__ = "Nandha Vignesh"
__description__ = "Hybrid RL + LLM AI Agent"

from dheera import Dheera

__all__ = ["Dheera", "__version__"]
