# connectors/tools/calculator.py
"""
Dheera v0.3.0 - Calculator Tool
Safe mathematical expression evaluator.
"""

import re
import math
import operator
from typing import Any, Dict, Optional, Union, List
from dataclasses import dataclass


@dataclass
class CalculationResult:
    """Result of a calculation."""
    success: bool
    result: Optional[float] = None
    expression: str = ""
    error: str = ""
    steps: List[str] = None
    
    def __post_init__(self):
        if self.steps is None:
            self.steps = []


class CalculatorTool:
    """
    Safe calculator tool for mathematical expressions.
    Supports basic arithmetic, percentages, and common functions.
    """
    
    # Safe operations
    OPERATORS = {
        '+': operator.add,
        '-': operator.sub,
        '*': operator.mul,
        '/': operator.truediv,
        '//': operator.floordiv,
        '%': operator.mod,
        '**': operator.pow,
        '^': operator.pow,
    }
    
    # Safe functions
    FUNCTIONS = {
        'abs': abs,
        'round': round,
        'int': int,
        'float': float,
        'min': min,
        'max': max,
        'sum': sum,
        'sqrt': math.sqrt,
        'pow': pow,
        'log': math.log,
        'log10': math.log10,
        'log2': math.log2,
        'exp': math.exp,
        'sin': math.sin,
        'cos': math.cos,
        'tan': math.tan,
        'asin': math.asin,
        'acos': math.acos,
        'atan': math.atan,
        'sinh': math.sinh,
        'cosh': math.cosh,
        'tanh': math.tanh,
        'floor': math.floor,
        'ceil': math.ceil,
        'factorial': math.factorial,
        'gcd': math.gcd,
        'degrees': math.degrees,
        'radians': math.radians,
    }
    
    # Constants
    CONSTANTS = {
        'pi': math.pi,
        'e': math.e,
        'tau': math.tau,
        'inf': float('inf'),
    }
    
    def __init__(self, max_value: float = 1e15):
        self.max_value = max_value
        self.last_result: Optional[float] = None
    
    def calculate(self, expression: str) -> CalculationResult:
        """
        Safely evaluate a mathematical expression.
        
        Args:
            expression: Math expression string
            
        Returns:
            CalculationResult with success status and result
        """
        try:
            # Clean expression
            clean_expr = self._clean_expression(expression)
            
            if not clean_expr:
                return CalculationResult(
                    success=False,
                    expression=expression,
                    error="Empty expression"
                )
            
            # Handle percentage
            clean_expr = self._handle_percentage(clean_expr)
            
            # Validate expression
            if not self._is_safe(clean_expr):
                return CalculationResult(
                    success=False,
                    expression=expression,
                    error="Expression contains unsafe operations"
                )
            
            # Evaluate
            result = self._safe_eval(clean_expr)
            
            # Check bounds
            if abs(result) > self.max_value:
                return CalculationResult(
                    success=False,
                    expression=expression,
                    error=f"Result too large (>{self.max_value})"
                )
            
            self.last_result = result
            
            return CalculationResult(
                success=True,
                result=result,
                expression=clean_expr,
            )
            
        except ZeroDivisionError:
            return CalculationResult(
                success=False,
                expression=expression,
                error="Division by zero"
            )
        except ValueError as e:
            return CalculationResult(
                success=False,
                expression=expression,
                error=f"Math error: {str(e)}"
            )
        except Exception as e:
            return CalculationResult(
                success=False,
                expression=expression,
                error=f"Calculation error: {str(e)}"
            )
    
    def _clean_expression(self, expr: str) -> str:
        """Clean and normalize expression."""
        # Remove whitespace
        expr = expr.strip()
        
        # Replace common symbols
        expr = expr.replace('×', '*')
        expr = expr.replace('÷', '/')
        expr = expr.replace('^', '**')
        expr = expr.replace('√', 'sqrt')
        
        # Handle implicit multiplication (2x -> 2*x, 2(3) -> 2*(3))
        expr = re.sub(r'(\d)([a-zA-Z(])', r'\1*\2', expr)
        expr = re.sub(r'(\))(\d)', r'\1*\2', expr)
        expr = re.sub(r'(\))([a-zA-Z(])', r'\1*\2', expr)
        
        return expr
    
    def _handle_percentage(self, expr: str) -> str:
        """Handle percentage calculations."""
        # X% of Y -> (X/100)*Y
        expr = re.sub(
            r'(\d+(?:\.\d+)?)\s*%\s*of\s*(\d+(?:\.\d+)?)',
            r'(\1/100)*\2',
            expr,
            flags=re.IGNORECASE
        )
        
        # X% -> X/100
        expr = re.sub(r'(\d+(?:\.\d+)?)\s*%', r'(\1/100)', expr)
        
        return expr
    
    def _is_safe(self, expr: str) -> bool:
        """Check if expression is safe to evaluate."""
        # Remove allowed characters
        allowed = set('0123456789.+-*/()[], ')
        
        # Add function and constant names
        for name in list(self.FUNCTIONS.keys()) + list(self.CONSTANTS.keys()):
            expr = expr.replace(name, '')
        
        # Check remaining characters
        remaining = set(expr) - allowed
        
        # Allow ** for power
        expr_check = expr.replace('**', '')
        
        # Check for dangerous patterns
        dangerous = ['__', 'import', 'exec', 'eval', 'open', 'file', 'os', 'sys']
        for pattern in dangerous:
            if pattern in expr.lower():
                return False
        
        return len(remaining - {'*'}) == 0
    
    def _safe_eval(self, expr: str) -> float:
        """Safely evaluate expression."""
        # Build safe namespace
        namespace = {}
        namespace.update(self.FUNCTIONS)
        namespace.update(self.CONSTANTS)
        
        # Add last result as 'ans'
        if self.last_result is not None:
            namespace['ans'] = self.last_result
        
        # Compile and evaluate
        code = compile(expr, '<string>', 'eval')
        
        # Check for unsafe operations
        for name in code.co_names:
            if name not in namespace and name not in self.OPERATORS:
                raise ValueError(f"Unknown function or variable: {name}")
        
        result = eval(code, {"__builtins__": {}}, namespace)
        
        return float(result)
    
    def solve_equation(self, equation: str) -> CalculationResult:
        """
        Solve simple equations (e.g., 2x + 5 = 15).
        Limited to linear equations with one variable.
        """
        try:
            # Find the variable
            var_match = re.search(r'[a-zA-Z]', equation.replace('sqrt', '').replace('log', ''))
            if not var_match:
                return CalculationResult(
                    success=False,
                    expression=equation,
                    error="No variable found in equation"
                )
            
            var = var_match.group()
            
            # Split by equals
            if '=' not in equation:
                return CalculationResult(
                    success=False,
                    expression=equation,
                    error="No equals sign in equation"
                )
            
            left, right = equation.split('=')
            left = left.strip()
            right = right.strip()
            
            # Try to solve by substitution
            for x in range(-1000, 1001):
                try:
                    left_val = self._safe_eval(left.replace(var, str(x)))
                    right_val = self._safe_eval(right.replace(var, str(x)))
                    
                    if abs(left_val - right_val) < 0.0001:
                        return CalculationResult(
                            success=True,
                            result=float(x),
                            expression=equation,
                            steps=[f"{var} = {x}"]
                        )
                except:
                    continue
            
            # Try decimal solutions
            for x_int in range(-100, 101):
                for decimal in [0.0, 0.25, 0.5, 0.75]:
                    x = x_int + decimal
                    try:
                        left_val = self._safe_eval(left.replace(var, str(x)))
                        right_val = self._safe_eval(right.replace(var, str(x)))
                        
                        if abs(left_val - right_val) < 0.0001:
                            return CalculationResult(
                                success=True,
                                result=x,
                                expression=equation,
                                steps=[f"{var} = {x}"]
                            )
                    except:
                        continue
            
            return CalculationResult(
                success=False,
                expression=equation,
                error="Could not find solution in range"
            )
            
        except Exception as e:
            return CalculationResult(
                success=False,
                expression=equation,
                error=f"Equation solving error: {str(e)}"
            )
    
    def format_result(self, result: CalculationResult) -> str:
        """Format result for display."""
        if result.success:
            # Format number nicely
            if result.result == int(result.result):
                formatted = str(int(result.result))
            else:
                formatted = f"{result.result:.6g}"
            
            return f"= {formatted}"
        else:
            return f"Error: {result.error}"


# ==================== Testing ====================
if __name__ == "__main__":
    print("Testing CalculatorTool...")
    
    calc = CalculatorTool()
    
    # Basic tests
    tests = [
        ("2 + 2", 4),
        ("10 * 5", 50),
        ("100 / 4", 25),
        ("2 ** 8", 256),
        ("sqrt(144)", 12),
        ("15% of 200", 30),
        ("sin(pi/2)", 1),
        ("log10(100)", 2),
    ]
    
    for expr, expected in tests:
        result = calc.calculate(expr)
        status = "✓" if result.success and abs(result.result - expected) < 0.0001 else "✗"
        print(f"  {status} {expr} = {result.result} (expected {expected})")
    
    # Equation test
    eq_result = calc.solve_equation("2x + 5 = 15")
    print(f"\n  Equation 2x + 5 = 15: x = {eq_result.result}")
    
    print("\n✅ Calculator tests completed!")
