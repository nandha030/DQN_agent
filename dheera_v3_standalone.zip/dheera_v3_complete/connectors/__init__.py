# connectors/__init__.py
"""
Dheera v0.3.0 - Connectors Package
External interfaces: chat, tools, web search.
"""

from connectors.chat_interface import ChatInterface, ChatSession, ChatMessage, MessageRole
from connectors.tool_registry import ToolRegistry, Tool, ToolResult, ToolCategory, ToolParameter
from connectors.web_search import WebSearchTool, SearchCache, WebSearchAction

# Aliases for backwards compatibility
WebSearch = WebSearchTool

__all__ = [
    # Chat
    "ChatInterface",
    "ChatSession", 
    "ChatMessage",
    "MessageRole",
    # Tools
    "ToolRegistry",
    "Tool",
    "ToolResult",
    "ToolCategory",
    "ToolParameter",
    # Search
    "WebSearchTool",
    "WebSearch",  # Alias
    "SearchCache",
    "WebSearchAction",
]
