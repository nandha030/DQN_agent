#!/usr/bin/env python3
"""
Dheera Standalone Model
=======================
A fully self-contained model that works WITHOUT Ollama or external APIs.

Uses HuggingFace Transformers with a small local model that gets
downloaded once and cached locally.

Options for base model (choose based on your hardware):
1. microsoft/phi-2             (2.7B)  - Best quality, needs ~6GB RAM
2. TinyLlama/TinyLlama-1.1B   (1.1B)  - Good balance, needs ~3GB RAM  
3. facebook/opt-350m           (350M)  - Fast, needs ~1GB RAM
4. distilgpt2                  (82M)   - Fastest, needs ~500MB RAM

Usage:
    python dheera_standalone.py                      # Interactive chat
    python dheera_standalone.py --model opt-350m    # Use smaller model
    python dheera_standalone.py --api --port 8000   # Start API server
"""

import os
import sys
import json
import argparse
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict, Any, List
from dataclasses import dataclass, field
import warnings
warnings.filterwarnings("ignore")

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

# =============================================================================
# Configuration
# =============================================================================

@dataclass
class ModelConfig:
    """Configuration for the standalone Dheera model."""
    
    # Base model options (HuggingFace model IDs)
    MODEL_OPTIONS = {
        "phi-2": "microsoft/phi-2",
        "tinyllama": "TinyLlama/TinyLlama-1.1B-Chat-v1.0", 
        "opt-350m": "facebook/opt-350m",
        "opt-125m": "facebook/opt-125m",
        "distilgpt2": "distilgpt2",
        "gpt2": "gpt2",
        "gpt2-medium": "gpt2-medium",
    }
    
    # Model specs
    MODEL_SPECS = {
        "phi-2": {"params": "2.7B", "ram": "~6GB", "context": 2048},
        "tinyllama": {"params": "1.1B", "ram": "~3GB", "context": 2048},
        "opt-350m": {"params": "350M", "ram": "~1GB", "context": 2048},
        "opt-125m": {"params": "125M", "ram": "~500MB", "context": 2048},
        "distilgpt2": {"params": "82M", "ram": "~350MB", "context": 1024},
        "gpt2": {"params": "124M", "ram": "~500MB", "context": 1024},
        "gpt2-medium": {"params": "355M", "ram": "~1.5GB", "context": 1024},
    }
    
    # Default model
    base_model: str = "distilgpt2"  # Smallest for quick testing
    
    # DQN config
    state_dim: int = 64
    action_dim: int = 7
    hidden_dim: int = 128
    
    # Generation config
    max_new_tokens: int = 256
    temperature: float = 0.7
    top_p: float = 0.9
    do_sample: bool = True
    
    # Paths
    cache_dir: str = "./model_cache"
    checkpoint_dir: str = "./trained_models/standalone"


# =============================================================================
# Lightweight DQN (No external dependencies)
# =============================================================================

class TinyDQN(nn.Module):
    """Minimal DQN network - fully self-contained."""
    
    def __init__(self, state_dim: int = 64, action_dim: int = 7, hidden_dim: int = 128):
        super().__init__()
        
        # Shared layers
        self.fc1 = nn.Linear(state_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        
        # Dueling architecture
        self.value_stream = nn.Linear(hidden_dim, 1)
        self.advantage_stream = nn.Linear(hidden_dim, action_dim)
        
        # Initialize
        self._init_weights()
        
    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                nn.init.zeros_(m.bias)
                
    def forward(self, state):
        x = F.relu(self.fc1(state))
        x = F.relu(self.fc2(x))
        
        value = self.value_stream(x)
        advantage = self.advantage_stream(x)
        
        # Combine value and advantage
        q_values = value + (advantage - advantage.mean(dim=-1, keepdim=True))
        return q_values
    
    def select_action(self, state: np.ndarray, epsilon: float = 0.0) -> int:
        """Select action using epsilon-greedy."""
        if np.random.random() < epsilon:
            return np.random.randint(0, 7)
            
        with torch.no_grad():
            state_t = torch.FloatTensor(state).unsqueeze(0)
            q_values = self.forward(state_t)
            return q_values.argmax(dim=-1).item()


class CuriosityRND(nn.Module):
    """Random Network Distillation for curiosity."""
    
    def __init__(self, state_dim: int = 64, hidden_dim: int = 128):
        super().__init__()
        
        # Fixed random target network
        self.target = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim)
        )
        
        # Trainable predictor network
        self.predictor = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim)
        )
        
        # Freeze target
        for param in self.target.parameters():
            param.requires_grad = False
            
    def compute_intrinsic_reward(self, state: np.ndarray) -> float:
        """Compute curiosity reward based on prediction error."""
        with torch.no_grad():
            state_t = torch.FloatTensor(state).unsqueeze(0)
            target_features = self.target(state_t)
            predicted_features = self.predictor(state_t)
            
            # MSE as intrinsic reward
            intrinsic = F.mse_loss(predicted_features, target_features).item()
            return min(intrinsic, 1.0)  # Clip


class RewardPredictor(nn.Module):
    """Learned reward model for RLHF."""
    
    def __init__(self, state_dim: int = 64, action_dim: int = 7, hidden_dim: int = 128):
        super().__init__()
        
        self.state_encoder = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.ReLU()
        )
        
        self.action_embedding = nn.Embedding(action_dim, hidden_dim)
        
        self.reward_head = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1),
            nn.Tanh()
        )
        
    def forward(self, state, action):
        state_enc = self.state_encoder(state)
        action_enc = self.action_embedding(action)
        combined = torch.cat([state_enc, action_enc], dim=-1)
        return self.reward_head(combined)


# =============================================================================
# State Builder (Self-contained)
# =============================================================================

class SimpleStateBuilder:
    """Build state vectors from text - no external dependencies."""
    
    def __init__(self, state_dim: int = 64):
        self.state_dim = state_dim
        self.context_history = []
        
    def build(self, text: str, context: Optional[List[str]] = None) -> np.ndarray:
        """Build state vector from text."""
        state = np.zeros(self.state_dim, dtype=np.float32)
        
        # Text features (0-15)
        words = text.lower().split()
        state[0] = min(len(words) / 50, 1.0)  # Length
        state[1] = min(text.count('?') / 3, 1.0)  # Questions
        state[2] = min(text.count('!') / 3, 1.0)  # Exclamations
        state[3] = 1.0 if any(w in text.lower() for w in ['code', 'python', 'function', 'class']) else 0.0
        state[4] = 1.0 if any(w in text.lower() for w in ['help', 'how', 'what', 'why', 'explain']) else 0.0
        state[5] = 1.0 if any(w in text.lower() for w in ['create', 'build', 'make', 'design']) else 0.0
        state[6] = 1.0 if any(w in text.lower() for w in ['search', 'find', 'look', 'news']) else 0.0
        state[7] = 1.0 if any(w in text.lower() for w in ['confused', 'unclear', 'don\'t understand']) else 0.0
        
        # Character distribution (8-23)
        for i, char in enumerate('abcdefghijklmnop'):
            state[8 + i] = min(text.lower().count(char) / 20, 1.0)
            
        # Word hash features (24-47)
        for i, word in enumerate(words[:24]):
            state[24 + i] = (hash(word) % 1000) / 1000
            
        # Context features (48-63)
        if context:
            state[48] = min(len(context) / 10, 1.0)
            if context:
                last = context[-1]
                state[49] = min(len(last.split()) / 50, 1.0)
                
        # Random noise for exploration
        state[60:64] = np.random.randn(4) * 0.1
        
        return state


# =============================================================================
# Action Space
# =============================================================================

@dataclass
class Action:
    id: int
    name: str
    description: str
    prompt_template: str


class ActionSpace:
    """7-action space for the agent."""
    
    ACTIONS = [
        Action(0, "DIRECT_RESPONSE", "Answer directly", 
               "Provide a direct, helpful answer:\n\nQuestion: {query}\n\nAnswer:"),
        Action(1, "CLARIFY_QUESTION", "Ask clarification",
               "The question needs clarification. Ask a helpful follow-up:\n\nQuestion: {query}\n\nClarifying question:"),
        Action(2, "USE_TOOL", "Use a tool",
               "Help with this technical request:\n\nRequest: {query}\n\nSolution:"),
        Action(3, "SEARCH_WEB", "Search for info",
               "Provide information about:\n\nTopic: {query}\n\nInformation:"),
        Action(4, "BREAK_DOWN_TASK", "Break down task",
               "Break this into steps:\n\nTask: {query}\n\nSteps:\n1."),
        Action(5, "REFLECT_AND_REASON", "Think step-by-step",
               "Think through this carefully:\n\nProblem: {query}\n\nReasoning:"),
        Action(6, "DEFER_OR_DECLINE", "Decline politely",
               "Respond appropriately to:\n\nInput: {query}\n\nResponse:"),
    ]
    
    @classmethod
    def get_action(cls, action_id: int) -> Action:
        return cls.ACTIONS[action_id]
    
    @classmethod
    def get_prompt(cls, action_id: int, query: str) -> str:
        action = cls.ACTIONS[action_id]
        return action.prompt_template.format(query=query)


# =============================================================================
# Standalone Dheera Model
# =============================================================================

class DheeraStandalone:
    """
    Fully self-contained Dheera model.
    
    Includes:
    - DQN for action selection
    - Curiosity module (RND)
    - RLHF reward predictor
    - Local LLM for text generation (HuggingFace)
    
    No external API dependencies!
    """
    
    VERSION = "0.3.0-standalone"
    
    def __init__(
        self,
        base_model: str = "distilgpt2",
        checkpoint_dir: Optional[str] = None,
        device: Optional[str] = None,
        load_llm: bool = True
    ):
        self.config = ModelConfig()
        self.config.base_model = base_model
        
        # Device
        if device:
            self.device = torch.device(device)
        else:
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
        print(f"\n{'='*60}")
        print(f"  धीर  DHEERA STANDALONE MODEL v{self.VERSION}")
        print(f"{'='*60}")
        print(f"  Device: {self.device}")
        print(f"  Base Model: {base_model}")
        
        # Get model specs
        if base_model in ModelConfig.MODEL_SPECS:
            specs = ModelConfig.MODEL_SPECS[base_model]
            print(f"  Parameters: {specs['params']}")
            print(f"  RAM Required: {specs['ram']}")
            print(f"  Context: {specs['context']} tokens")
        
        print(f"{'='*60}\n")
        
        # Initialize components
        self._init_rl_components()
        
        if load_llm:
            self._init_llm()
        else:
            self.model = None
            self.tokenizer = None
            print("⚠️ LLM not loaded (load_llm=False)")
        
        # Load checkpoint if available
        if checkpoint_dir:
            self.load_checkpoint(checkpoint_dir)
            
        # Statistics
        self.total_queries = 0
        self.action_counts = {i: 0 for i in range(7)}
        self.feedback_buffer = []
        
        print("✅ Dheera Standalone ready!\n")
        
    def _init_rl_components(self):
        """Initialize RL components (DQN, Curiosity, Reward Model)."""
        print("📦 Initializing RL components...")
        
        # DQN
        self.dqn = TinyDQN(
            state_dim=self.config.state_dim,
            action_dim=self.config.action_dim,
            hidden_dim=self.config.hidden_dim
        ).to(self.device)
        self.epsilon = 0.05  # Low epsilon for inference
        print("  ✓ DQN Agent")
        
        # Curiosity
        self.curiosity = CuriosityRND(
            state_dim=self.config.state_dim,
            hidden_dim=self.config.hidden_dim
        ).to(self.device)
        print("  ✓ Curiosity Module (RND)")
        
        # Reward Model
        self.reward_model = RewardPredictor(
            state_dim=self.config.state_dim,
            action_dim=self.config.action_dim,
            hidden_dim=self.config.hidden_dim
        ).to(self.device)
        print("  ✓ Reward Model (RLHF)")
        
        # State Builder
        self.state_builder = SimpleStateBuilder(state_dim=self.config.state_dim)
        print("  ✓ State Builder")
        
    def _init_llm(self):
        """Initialize the local LLM."""
        print("\n📦 Loading language model (this may take a moment)...")
        
        try:
            from transformers import AutoModelForCausalLM, AutoTokenizer
        except ImportError:
            print("Installing transformers...")
            import subprocess
            subprocess.check_call([sys.executable, "-m", "pip", "install", "transformers", "accelerate"])
            from transformers import AutoModelForCausalLM, AutoTokenizer
        
        model_id = ModelConfig.MODEL_OPTIONS.get(
            self.config.base_model, 
            self.config.base_model
        )
        
        cache_dir = Path(self.config.cache_dir)
        cache_dir.mkdir(parents=True, exist_ok=True)
        
        print(f"  Loading {model_id}...")
        
        # Load tokenizer
        self.tokenizer = AutoTokenizer.from_pretrained(
            model_id,
            cache_dir=cache_dir,
            trust_remote_code=True
        )
        
        # Set padding token if not set
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        
        # Load model
        self.model = AutoModelForCausalLM.from_pretrained(
            model_id,
            cache_dir=cache_dir,
            torch_dtype=torch.float16 if self.device.type == "cuda" else torch.float32,
            device_map="auto" if self.device.type == "cuda" else None,
            trust_remote_code=True
        )
        
        if self.device.type != "cuda":
            self.model = self.model.to(self.device)
            
        self.model.eval()
        print(f"  ✓ LLM loaded: {model_id}")
        
    def select_action(self, state: np.ndarray) -> tuple:
        """Select action using DQN."""
        action_id = self.dqn.select_action(state, epsilon=self.epsilon)
        
        # Get Q-values for confidence
        with torch.no_grad():
            state_t = torch.FloatTensor(state).unsqueeze(0).to(self.device)
            q_values = self.dqn(state_t).cpu().numpy()[0]
            confidence = float(np.max(q_values))
            
        action = ActionSpace.get_action(action_id)
        return action, confidence, q_values
    
    def compute_scores(self, state: np.ndarray, action_id: int) -> Dict[str, float]:
        """Compute RLHF and curiosity scores."""
        with torch.no_grad():
            state_t = torch.FloatTensor(state).unsqueeze(0).to(self.device)
            action_t = torch.LongTensor([action_id]).to(self.device)
            
            # RLHF reward prediction
            reward_score = self.reward_model(state_t, action_t).item()
            
            # Curiosity bonus
            curiosity_bonus = self.curiosity.compute_intrinsic_reward(state)
            
        return {
            "reward_score": reward_score,
            "curiosity_bonus": curiosity_bonus,
            "combined_score": reward_score + 0.1 * curiosity_bonus
        }
    
    def generate_text(self, prompt: str, max_new_tokens: Optional[int] = None) -> str:
        """Generate text using local LLM."""
        if self.model is None:
            return "[LLM not loaded]"
            
        max_new_tokens = max_new_tokens or self.config.max_new_tokens
        
        inputs = self.tokenizer(
            prompt,
            return_tensors="pt",
            truncation=True,
            max_length=512
        ).to(self.device)
        
        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                max_new_tokens=max_new_tokens,
                temperature=self.config.temperature,
                top_p=self.config.top_p,
                do_sample=self.config.do_sample,
                pad_token_id=self.tokenizer.pad_token_id,
                eos_token_id=self.tokenizer.eos_token_id,
            )
        
        # Decode only the new tokens
        generated = self.tokenizer.decode(
            outputs[0][inputs['input_ids'].shape[1]:],
            skip_special_tokens=True
        )
        
        return generated.strip()
    
    def __call__(
        self,
        query: str,
        context: Optional[List[str]] = None,
        return_metadata: bool = False
    ) -> Dict[str, Any]:
        """
        Main inference method.
        
        Pipeline:
        1. Build state from query
        2. DQN selects action
        3. Build action-specific prompt
        4. Generate response with LLM
        5. Compute RLHF/curiosity scores
        6. Return response + metadata
        """
        self.total_queries += 1
        
        # 1. Build state
        state = self.state_builder.build(query, context)
        
        # 2. Select action
        action, confidence, q_values = self.select_action(state)
        self.action_counts[action.id] += 1
        
        # 3. Build prompt
        prompt = ActionSpace.get_prompt(action.id, query)
        
        # 4. Generate
        response = self.generate_text(prompt)
        
        # 5. Compute scores
        scores = self.compute_scores(state, action.id)
        
        # 6. Build result
        result = {
            "response": response,
            "action": action.name,
            "action_id": action.id,
        }
        
        if return_metadata:
            result["metadata"] = {
                "confidence": confidence,
                "q_values": q_values.tolist(),
                "scores": scores,
                "query_length": len(query.split()),
                "response_length": len(response.split())
            }
            
        return result
    
    def chat(self, query: str) -> str:
        """Simple chat interface - just returns response text."""
        result = self(query)
        return result["response"]
    
    def provide_feedback(self, query: str, response: str, rating: float):
        """Store feedback for RLHF training."""
        state = self.state_builder.build(query)
        
        self.feedback_buffer.append({
            "state": state.tolist(),
            "query": query,
            "response": response,
            "rating": rating,
            "timestamp": datetime.now().isoformat()
        })
        
    def get_stats(self) -> Dict[str, Any]:
        """Get model statistics."""
        return {
            "version": self.VERSION,
            "base_model": self.config.base_model,
            "device": str(self.device),
            "total_queries": self.total_queries,
            "action_distribution": {
                ActionSpace.ACTIONS[i].name: count 
                for i, count in self.action_counts.items()
            },
            "feedback_collected": len(self.feedback_buffer),
            "epsilon": self.epsilon
        }
    
    def save_checkpoint(self, path: str):
        """Save all model weights."""
        save_dir = Path(path)
        save_dir.mkdir(parents=True, exist_ok=True)
        
        # Save DQN
        torch.save(self.dqn.state_dict(), save_dir / "dqn.pt")
        
        # Save curiosity
        torch.save(self.curiosity.state_dict(), save_dir / "curiosity.pt")
        
        # Save reward model
        torch.save(self.reward_model.state_dict(), save_dir / "reward_model.pt")
        
        # Save config
        config_dict = {
            "version": self.VERSION,
            "base_model": self.config.base_model,
            "state_dim": self.config.state_dim,
            "action_dim": self.config.action_dim,
            "hidden_dim": self.config.hidden_dim,
            "epsilon": self.epsilon,
            "stats": self.get_stats()
        }
        with open(save_dir / "config.json", 'w') as f:
            json.dump(config_dict, f, indent=2)
            
        # Save feedback
        if self.feedback_buffer:
            with open(save_dir / "feedback.json", 'w') as f:
                json.dump(self.feedback_buffer, f, indent=2)
                
        print(f"✅ Checkpoint saved to {path}")
        
    def load_checkpoint(self, path: str):
        """Load model weights."""
        load_dir = Path(path)
        
        if not load_dir.exists():
            print(f"⚠️ Checkpoint not found: {path}")
            return
            
        print(f"📂 Loading checkpoint from {path}...")
        
        # Load DQN
        dqn_path = load_dir / "dqn.pt"
        if dqn_path.exists():
            self.dqn.load_state_dict(torch.load(dqn_path, map_location=self.device))
            print("  ✓ DQN loaded")
            
        # Load curiosity
        curiosity_path = load_dir / "curiosity.pt"
        if curiosity_path.exists():
            self.curiosity.load_state_dict(torch.load(curiosity_path, map_location=self.device))
            print("  ✓ Curiosity loaded")
            
        # Load reward model
        reward_path = load_dir / "reward_model.pt"
        if reward_path.exists():
            self.reward_model.load_state_dict(torch.load(reward_path, map_location=self.device))
            print("  ✓ Reward model loaded")
            
        # Load config
        config_path = load_dir / "config.json"
        if config_path.exists():
            with open(config_path) as f:
                config = json.load(f)
                self.epsilon = config.get("epsilon", 0.05)
                
        print("✅ Checkpoint loaded!")


# =============================================================================
# Interactive Chat
# =============================================================================

def interactive_chat(model: DheeraStandalone):
    """Run interactive chat session."""
    print("""
╔═══════════════════════════════════════════════════════════════╗
║           DHEERA STANDALONE CHAT                              ║
╠═══════════════════════════════════════════════════════════════╣
║  Commands:                                                    ║
║    /stats    - Show statistics                                ║
║    /action   - Toggle action info                             ║
║    /feedback <rating> - Rate last response (-1 to 1)          ║
║    /save     - Save checkpoint                                ║
║    /quit     - Exit                                           ║
╚═══════════════════════════════════════════════════════════════╝
    """)
    
    show_action = True
    last_query = ""
    last_response = ""
    context = []
    
    while True:
        try:
            user_input = input("\n🧑 You: ").strip()
            
            if not user_input:
                continue
                
            # Commands
            if user_input.startswith("/"):
                cmd = user_input.lower().split()[0]
                
                if cmd in ("/quit", "/exit", "/q"):
                    print("👋 Goodbye!")
                    break
                    
                elif cmd == "/stats":
                    stats = model.get_stats()
                    print(f"\n📊 Statistics:")
                    print(f"   Total queries: {stats['total_queries']}")
                    print(f"   Base model: {stats['base_model']}")
                    print(f"   Device: {stats['device']}")
                    print(f"   Action distribution:")
                    for action, count in stats['action_distribution'].items():
                        if count > 0:
                            print(f"     {action}: {count}")
                    continue
                    
                elif cmd == "/action":
                    show_action = not show_action
                    print(f"   Action info: {'ON' if show_action else 'OFF'}")
                    continue
                    
                elif cmd == "/feedback":
                    parts = user_input.split()
                    if len(parts) > 1 and last_query:
                        try:
                            rating = float(parts[1])
                            model.provide_feedback(last_query, last_response, rating)
                            print(f"   ✓ Feedback {rating} recorded")
                        except ValueError:
                            print("   Usage: /feedback <rating> (e.g., /feedback 0.8)")
                    else:
                        print("   No previous response to rate")
                    continue
                    
                elif cmd == "/save":
                    model.save_checkpoint("./checkpoints/interactive")
                    continue
                    
                else:
                    print(f"   Unknown command: {cmd}")
                    continue
            
            # Generate response
            result = model(user_input, context=context, return_metadata=True)
            
            last_query = user_input
            last_response = result["response"]
            context.append(user_input)
            context.append(last_response)
            
            # Keep context manageable
            if len(context) > 10:
                context = context[-10:]
            
            print(f"\n🤖 Dheera: {result['response']}")
            
            if show_action:
                meta = result.get("metadata", {})
                print(f"\n   📍 Action: {result['action']}")
                print(f"   📊 Confidence: {meta.get('confidence', 0):.2f}")
                scores = meta.get("scores", {})
                print(f"   🎯 RLHF Score: {scores.get('reward_score', 0):.4f}")
                print(f"   🔍 Curiosity: {scores.get('curiosity_bonus', 0):.4f}")
                
        except KeyboardInterrupt:
            print("\n👋 Goodbye!")
            break
        except Exception as e:
            print(f"\n❌ Error: {e}")


# =============================================================================
# API Server (Optional)
# =============================================================================

def run_api_server(model: DheeraStandalone, host: str = "127.0.0.1", port: int = 8000):
    """Run OpenAI-compatible API server."""
    try:
        from fastapi import FastAPI, HTTPException
        from pydantic import BaseModel
        import uvicorn
    except ImportError:
        print("Installing API dependencies...")
        import subprocess
        subprocess.check_call([sys.executable, "-m", "pip", "install", "fastapi", "uvicorn"])
        from fastapi import FastAPI, HTTPException
        from pydantic import BaseModel
        import uvicorn
    
    app = FastAPI(title="Dheera Standalone API", version=model.VERSION)
    
    class ChatMessage(BaseModel):
        role: str
        content: str
        
    class ChatRequest(BaseModel):
        model: str = "dheera-standalone"
        messages: list
        temperature: float = 0.7
        max_tokens: int = 256
        
    @app.get("/v1/models")
    def list_models():
        return {
            "data": [{
                "id": "dheera-standalone",
                "object": "model",
                "owned_by": "dheera"
            }]
        }
    
    @app.post("/v1/chat/completions")
    def chat_completions(request: ChatRequest):
        # Get user message
        user_msg = ""
        for msg in request.messages:
            if msg.get("role") == "user":
                user_msg = msg.get("content", "")
                
        if not user_msg:
            raise HTTPException(400, "No user message")
            
        result = model(user_msg, return_metadata=True)
        
        return {
            "id": f"dheera-{model.total_queries}",
            "object": "chat.completion",
            "model": "dheera-standalone",
            "choices": [{
                "index": 0,
                "message": {"role": "assistant", "content": result["response"]},
                "finish_reason": "stop"
            }],
            "usage": {
                "prompt_tokens": len(user_msg.split()),
                "completion_tokens": len(result["response"].split()),
                "total_tokens": len(user_msg.split()) + len(result["response"].split())
            }
        }
    
    @app.get("/health")
    def health():
        return {"status": "healthy", "model": "dheera-standalone"}
    
    print(f"\n🌐 Starting API server at http://{host}:{port}")
    print(f"   Docs: http://{host}:{port}/docs")
    uvicorn.run(app, host=host, port=port)


# =============================================================================
# Main
# =============================================================================

def main():
    parser = argparse.ArgumentParser(description="Dheera Standalone Model")
    parser.add_argument("--model", "-m", default="distilgpt2",
                       choices=list(ModelConfig.MODEL_OPTIONS.keys()),
                       help="Base model to use")
    parser.add_argument("--checkpoint", "-c", help="Load checkpoint")
    parser.add_argument("--api", action="store_true", help="Run API server")
    parser.add_argument("--port", type=int, default=8000, help="API port")
    parser.add_argument("--host", default="127.0.0.1", help="API host")
    parser.add_argument("--no-llm", action="store_true", help="Don't load LLM (RL only)")
    parser.add_argument("--list-models", action="store_true", help="List available models")
    
    args = parser.parse_args()
    
    if args.list_models:
        print("\nAvailable base models:")
        print("-" * 60)
        for name, specs in ModelConfig.MODEL_SPECS.items():
            print(f"  {name:12} | {specs['params']:6} params | {specs['ram']:8} RAM | {specs['context']} ctx")
        print("-" * 60)
        print("\nUse: python dheera_standalone.py --model <name>")
        return
    
    # Initialize model
    model = DheeraStandalone(
        base_model=args.model,
        checkpoint_dir=args.checkpoint,
        load_llm=not args.no_llm
    )
    
    if args.api:
        run_api_server(model, host=args.host, port=args.port)
    else:
        interactive_chat(model)


if __name__ == "__main__":
    main()
