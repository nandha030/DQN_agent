#!/usr/bin/env python3
"""
Dheera API Server
=================
Exposes the complete RLHF + DQN + SLM system as a unified model API.

This creates an OpenAI-compatible API gateway that:
1. Receives requests like any LLM API
2. Uses DQN to select the best action/strategy
3. Applies RLHF reward model for response quality
4. Uses curiosity module for exploration
5. Generates response via SLM (Ollama/phi3)

Endpoints:
- POST /v1/chat/completions  - OpenAI-compatible chat
- POST /v1/completions       - OpenAI-compatible completion
- GET  /v1/models            - List available models
- GET  /v1/models/{model}    - Get model info
- POST /v1/feedback          - Provide RLHF feedback
- GET  /health               - Health check
- GET  /stats                - Get agent statistics

Usage:
    python api_server.py                    # Start on port 8000
    python api_server.py --port 8080        # Custom port
    python api_server.py --host 0.0.0.0     # Allow external access
    python api_server.py --reload           # Auto-reload for development
"""

import os
import sys
import json
import time
import uuid
import asyncio
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict, Any, List, Union
from dataclasses import dataclass, asdict
from contextlib import asynccontextmanager

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent))

# FastAPI imports
try:
    from fastapi import FastAPI, HTTPException, Request, BackgroundTasks
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import StreamingResponse, JSONResponse
    from pydantic import BaseModel, Field
    import uvicorn
except ImportError:
    print("FastAPI not installed. Installing...")
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "fastapi", "uvicorn", "pydantic"])
    from fastapi import FastAPI, HTTPException, Request, BackgroundTasks
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import StreamingResponse, JSONResponse
    from pydantic import BaseModel, Field
    import uvicorn

import numpy as np
import torch

# Dheera components
from core.dqn_agent import DQNAgent
from core.action_space import ActionSpace, Action
from core.state_builder import StateBuilder, ConversationContext
from core.curiosity_rnd import CuriosityModule
from brain.slm_interface import SLMInterface
from cognitive.intent_classifier import IntentClassifier
from rlhf.reward_model import RewardModel


# =============================================================================
# Pydantic Models for API
# =============================================================================

class ChatMessage(BaseModel):
    role: str = Field(..., description="Role: system, user, or assistant")
    content: str = Field(..., description="Message content")
    name: Optional[str] = None


class ChatCompletionRequest(BaseModel):
    model: str = Field(default="dheera-v0.3.0", description="Model ID")
    messages: List[ChatMessage] = Field(..., description="Conversation messages")
    temperature: float = Field(default=0.7, ge=0, le=2)
    max_tokens: Optional[int] = Field(default=1024, ge=1, le=4096)
    stream: bool = Field(default=False)
    top_p: float = Field(default=1.0, ge=0, le=1)
    n: int = Field(default=1, ge=1, le=10)
    stop: Optional[Union[str, List[str]]] = None
    presence_penalty: float = Field(default=0, ge=-2, le=2)
    frequency_penalty: float = Field(default=0, ge=-2, le=2)
    user: Optional[str] = None
    
    # Dheera-specific options
    use_dqn: bool = Field(default=True, description="Use DQN for action selection")
    use_rlhf: bool = Field(default=True, description="Apply RLHF reward scoring")
    use_curiosity: bool = Field(default=True, description="Include curiosity bonus")
    return_action_info: bool = Field(default=False, description="Include action details in response")


class CompletionRequest(BaseModel):
    model: str = Field(default="dheera-v0.3.0")
    prompt: str = Field(..., description="Input prompt")
    max_tokens: Optional[int] = Field(default=1024)
    temperature: float = Field(default=0.7)
    stream: bool = Field(default=False)


class FeedbackRequest(BaseModel):
    response_id: str = Field(..., description="ID of the response to rate")
    rating: float = Field(..., ge=-1, le=1, description="Rating from -1 to 1")
    feedback_type: Optional[str] = Field(default=None, description="++, +, -, or --")


class Usage(BaseModel):
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int


class Choice(BaseModel):
    index: int
    message: ChatMessage
    finish_reason: str
    
    # Dheera extras
    action_taken: Optional[str] = None
    action_confidence: Optional[float] = None
    reward_score: Optional[float] = None
    curiosity_bonus: Optional[float] = None


class ChatCompletionResponse(BaseModel):
    id: str
    object: str = "chat.completion"
    created: int
    model: str
    choices: List[Choice]
    usage: Usage
    
    # Dheera extras
    dheera_metadata: Optional[Dict[str, Any]] = None


# =============================================================================
# Dheera Model Wrapper
# =============================================================================

class DheeraModel:
    """
    Unified Dheera Model
    
    Combines:
    - DQN Agent (action selection)
    - RLHF Reward Model (response quality)
    - Curiosity Module (exploration)
    - SLM Interface (text generation)
    - Cognitive Layer (intent/entity)
    
    Model Specifications:
    - Base Model: phi3:mini (3.8B parameters)
    - DQN Network: ~50K parameters
    - Reward Model: ~100K parameters
    - Curiosity RND: ~100K parameters
    - Total Additional: ~250K parameters
    - Context Length: 4096 tokens (inherited from phi3)
    - State Dimension: 64
    - Action Space: 7 actions
    """
    
    MODEL_ID = "dheera-v0.3.0"
    MODEL_NAME = "Dheera RLHF+DQN+SLM"
    VERSION = "0.3.0"
    
    # Model specifications
    SPECS = {
        "base_model": "phi3:mini",
        "base_params": "3.8B",
        "dqn_params": "~50K",
        "reward_model_params": "~100K", 
        "curiosity_params": "~100K",
        "total_additional_params": "~250K",
        "context_length": 4096,
        "max_tokens": 2048,
        "state_dim": 64,
        "action_space": 7,
        "hidden_dim": 128,
        "supported_actions": [
            "DIRECT_RESPONSE",
            "CLARIFY_QUESTION",
            "USE_TOOL",
            "SEARCH_WEB",
            "BREAK_DOWN_TASK",
            "REFLECT_AND_REASON",
            "DEFER_OR_DECLINE"
        ]
    }
    
    def __init__(self, checkpoint_dir: Optional[str] = None):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"🚀 Initializing Dheera Model on {self.device}...")
        
        # Initialize components
        self._init_components()
        
        # Load checkpoint if available
        if checkpoint_dir:
            self.load_checkpoint(checkpoint_dir)
        
        # Response cache for feedback
        self.response_cache: Dict[str, Dict] = {}
        
        # Statistics
        self.total_requests = 0
        self.total_tokens_generated = 0
        self.action_distribution = {i: 0 for i in range(7)}
        
        print("✅ Dheera Model ready!")
        
    def _init_components(self):
        """Initialize all model components."""
        state_dim = self.SPECS["state_dim"]
        action_dim = self.SPECS["action_space"]
        hidden_dim = self.SPECS["hidden_dim"]
        
        # Action space
        self.action_space = ActionSpace()
        
        # State builder
        self.state_builder = StateBuilder(state_dim=state_dim)
        
        # DQN Agent
        self.dqn = DQNAgent(
            state_dim=state_dim,
            action_dim=action_dim,
            hidden_dim=hidden_dim,
            device=self.device
        )
        
        # Curiosity Module
        self.curiosity = CuriosityModule(
            state_dim=state_dim,
            hidden_dim=hidden_dim,
            device=self.device
        )
        
        # RLHF Reward Model
        self.reward_model = RewardModel(
            state_dim=state_dim,
            action_dim=action_dim,
            hidden_dim=hidden_dim
        )
        
        # SLM Interface (Ollama)
        try:
            self.slm = SLMInterface(provider="ollama", model="phi3:mini")
            self.slm_available = self.slm.is_available()
        except Exception as e:
            print(f"⚠️ SLM not available: {e}")
            self.slm = None
            self.slm_available = False
            
        # Intent classifier
        self.intent_classifier = IntentClassifier()
        
        # Conversation contexts per session
        self.contexts: Dict[str, ConversationContext] = {}
        
    def load_checkpoint(self, checkpoint_dir: str):
        """Load trained weights."""
        checkpoint_path = Path(checkpoint_dir)
        
        if not checkpoint_path.exists():
            print(f"⚠️ Checkpoint not found: {checkpoint_dir}")
            return
            
        print(f"📂 Loading checkpoint from {checkpoint_dir}...")
        
        # Load DQN
        dqn_path = checkpoint_path / "dqn_agent.pt"
        if dqn_path.exists():
            self.dqn.load(str(dqn_path))
            print("  ✓ DQN loaded")
            
        # Load curiosity
        curiosity_path = checkpoint_path / "curiosity_rnd.pt"
        if curiosity_path.exists():
            self.curiosity.load(str(curiosity_path))
            print("  ✓ Curiosity loaded")
            
        # Load reward model
        reward_path = checkpoint_path / "reward_model.pt"
        if reward_path.exists():
            self.reward_model.load_state_dict(torch.load(reward_path, map_location=self.device))
            print("  ✓ Reward model loaded")
            
    def get_or_create_context(self, session_id: str) -> ConversationContext:
        """Get or create conversation context for session."""
        if session_id not in self.contexts:
            self.contexts[session_id] = ConversationContext()
        return self.contexts[session_id]
    
    def select_action(self, state: np.ndarray, use_dqn: bool = True) -> tuple:
        """Select action using DQN or default policy."""
        if use_dqn:
            action_id = self.dqn.select_action(state, training=False)
            q_values = self.dqn.get_q_values(state)
            confidence = float(np.max(q_values))
        else:
            action_id = 0  # Default to DIRECT_RESPONSE
            confidence = 1.0
            
        action = self.action_space.get_action(action_id)
        return action, confidence
    
    def compute_reward_score(self, state: np.ndarray, action_id: int) -> float:
        """Compute RLHF reward score for state-action pair."""
        state_tensor = torch.FloatTensor(state).unsqueeze(0).to(self.device)
        action_tensor = torch.LongTensor([action_id]).to(self.device)
        
        with torch.no_grad():
            reward = self.reward_model(state_tensor, action_tensor)
            
        return float(reward.item())
    
    def compute_curiosity_bonus(self, state: np.ndarray) -> float:
        """Compute curiosity/novelty bonus for state."""
        return float(self.curiosity.compute_intrinsic_reward(state))
    
    def build_action_prompt(self, action: Action, user_message: str, context: ConversationContext) -> str:
        """Build prompt based on selected action."""
        action_templates = {
            0: f"Provide a direct, helpful answer to the user's question:\n\nUser: {user_message}\n\nAssistant:",
            1: f"The user's request may need clarification. Ask a thoughtful clarifying question:\n\nUser: {user_message}\n\nAssistant: To help you better, ",
            2: f"Use available tools to help answer this request:\n\nUser: {user_message}\n\nAssistant: I'll use a tool to help with this. ",
            3: f"Search for current information to answer this question:\n\nUser: {user_message}\n\nAssistant: Let me search for the latest information. ",
            4: f"Break down this complex request into manageable steps:\n\nUser: {user_message}\n\nAssistant: Let me break this down step by step:\n",
            5: f"Think through this carefully before responding:\n\nUser: {user_message}\n\nAssistant: Let me think through this carefully.\n",
            6: f"This request may need to be redirected or declined politely:\n\nUser: {user_message}\n\nAssistant: "
        }
        
        # Add conversation history
        history = ""
        if context.turns:
            for turn in context.turns[-3:]:  # Last 3 turns
                history += f"User: {turn.get('user', '')}\nAssistant: {turn.get('assistant', '')}\n\n"
                
        base_prompt = action_templates.get(action.id, action_templates[0])
        
        if history:
            return f"Previous conversation:\n{history}\nCurrent request:\n{base_prompt}"
        return base_prompt
    
    async def generate(
        self,
        messages: List[ChatMessage],
        temperature: float = 0.7,
        max_tokens: int = 1024,
        use_dqn: bool = True,
        use_rlhf: bool = True,
        use_curiosity: bool = True,
        session_id: Optional[str] = None,
        stream: bool = False
    ) -> Dict[str, Any]:
        """
        Generate response using the complete Dheera pipeline.
        
        Pipeline:
        1. Build state from conversation
        2. Select action via DQN
        3. Build action-specific prompt
        4. Generate via SLM
        5. Compute RLHF score
        6. Add curiosity bonus
        7. Return response with metadata
        """
        session_id = session_id or str(uuid.uuid4())
        context = self.get_or_create_context(session_id)
        
        # Get user message
        user_message = ""
        system_prompt = ""
        for msg in messages:
            if msg.role == "user":
                user_message = msg.content
            elif msg.role == "system":
                system_prompt = msg.content
                
        if not user_message:
            raise ValueError("No user message found")
            
        # 1. Build state
        state = self.state_builder.build(user_message, context)
        
        # 2. Select action via DQN
        action, confidence = self.select_action(state, use_dqn=use_dqn)
        self.action_distribution[action.id] += 1
        
        # 3. Build action-specific prompt
        prompt = self.build_action_prompt(action, user_message, context)
        
        # 4. Generate via SLM
        if self.slm_available:
            try:
                response = self.slm.generate(
                    prompt,
                    system_prompt=system_prompt,
                    max_tokens=max_tokens,
                    temperature=temperature
                )
                response_text = response.text if hasattr(response, 'text') else str(response)
            except Exception as e:
                response_text = f"[{action.name}] I understand you're asking about: {user_message}"
        else:
            response_text = f"[{action.name}] I understand you're asking about: {user_message}"
            
        # 5. Compute RLHF reward score
        reward_score = 0.0
        if use_rlhf:
            reward_score = self.compute_reward_score(state, action.id)
            
        # 6. Compute curiosity bonus
        curiosity_bonus = 0.0
        if use_curiosity:
            curiosity_bonus = self.compute_curiosity_bonus(state)
            
        # Update context
        context.add_turn(user_message, response_text)
        
        # Estimate tokens (rough approximation)
        prompt_tokens = len(prompt.split()) * 1.3
        completion_tokens = len(response_text.split()) * 1.3
        
        self.total_requests += 1
        self.total_tokens_generated += int(completion_tokens)
        
        # Generate response ID
        response_id = f"dheera-{uuid.uuid4().hex[:12]}"
        
        # Cache for feedback
        self.response_cache[response_id] = {
            "state": state.tolist(),
            "action_id": action.id,
            "response": response_text,
            "timestamp": datetime.now().isoformat()
        }
        
        return {
            "response_id": response_id,
            "response_text": response_text,
            "action": {
                "id": action.id,
                "name": action.name,
                "confidence": confidence
            },
            "scores": {
                "reward": reward_score,
                "curiosity": curiosity_bonus,
                "combined": reward_score + 0.1 * curiosity_bonus
            },
            "tokens": {
                "prompt": int(prompt_tokens),
                "completion": int(completion_tokens),
                "total": int(prompt_tokens + completion_tokens)
            },
            "session_id": session_id
        }
    
    def provide_feedback(self, response_id: str, rating: float):
        """Process user feedback for RLHF."""
        if response_id not in self.response_cache:
            return False
            
        cached = self.response_cache[response_id]
        
        # Store feedback for future training
        feedback_entry = {
            "state": cached["state"],
            "action": cached["action_id"],
            "feedback": rating,
            "timestamp": datetime.now().isoformat()
        }
        
        # Could save to file/database for batch training
        feedback_file = Path("./feedback_log.jsonl")
        with open(feedback_file, "a") as f:
            f.write(json.dumps(feedback_entry) + "\n")
            
        return True
    
    def get_model_info(self) -> Dict[str, Any]:
        """Get complete model information."""
        return {
            "id": self.MODEL_ID,
            "object": "model",
            "created": int(datetime.now().timestamp()),
            "owned_by": "dheera",
            "name": self.MODEL_NAME,
            "version": self.VERSION,
            "description": "Dheera: Adaptive AI Agent combining RLHF + DQN + SLM",
            "specifications": self.SPECS,
            "capabilities": {
                "chat_completion": True,
                "text_completion": True,
                "streaming": True,
                "function_calling": False,
                "rlhf_feedback": True,
                "action_selection": True
            },
            "components": {
                "slm": {
                    "model": "phi3:mini",
                    "provider": "ollama",
                    "available": self.slm_available,
                    "parameters": "3.8B",
                    "context_length": 4096
                },
                "dqn": {
                    "architecture": "Double DQN with Dueling",
                    "state_dim": 64,
                    "action_dim": 7,
                    "hidden_dim": 128,
                    "parameters": "~50K",
                    "epsilon": self.dqn.epsilon
                },
                "reward_model": {
                    "architecture": "MLP",
                    "parameters": "~100K",
                    "trained": True
                },
                "curiosity": {
                    "architecture": "Random Network Distillation",
                    "parameters": "~100K"
                }
            },
            "statistics": {
                "total_requests": self.total_requests,
                "total_tokens": self.total_tokens_generated,
                "action_distribution": {
                    self.SPECS["supported_actions"][i]: count 
                    for i, count in self.action_distribution.items()
                }
            }
        }


# =============================================================================
# FastAPI Application
# =============================================================================

# Global model instance
dheera_model: Optional[DheeraModel] = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifecycle manager for the API."""
    global dheera_model
    
    # Startup
    print("\n" + "=" * 60)
    print("🚀 Starting Dheera API Server")
    print("=" * 60)
    
    # Check for trained checkpoint
    checkpoint_dir = None
    possible_paths = [
        "./trained_models/final_model",
        "./exports/latest/weights",
        "./checkpoints/latest"
    ]
    for path in possible_paths:
        if Path(path).exists():
            checkpoint_dir = path
            break
    
    dheera_model = DheeraModel(checkpoint_dir=checkpoint_dir)
    
    print("\n" + "=" * 60)
    print("✅ Dheera API Server Ready!")
    print(f"   Model: {dheera_model.MODEL_ID}")
    print(f"   SLM: {'Available' if dheera_model.slm_available else 'Echo Mode'}")
    print("=" * 60 + "\n")
    
    yield
    
    # Shutdown
    print("\n👋 Shutting down Dheera API Server...")


# Create FastAPI app
app = FastAPI(
    title="Dheera API",
    description="""
# Dheera API Server

Unified API for the Dheera RLHF + DQN + SLM model.

## Features
- **OpenAI-compatible** chat and completion endpoints
- **DQN Action Selection** - Intelligent strategy selection
- **RLHF Scoring** - Response quality prediction
- **Curiosity Bonus** - Novelty/exploration rewards
- **Feedback Loop** - Continuous learning from user ratings

## Model Architecture
- **Base**: phi3:mini (3.8B params)
- **DQN**: Double DQN with Dueling (~50K params)
- **Reward Model**: MLP (~100K params)
- **Curiosity**: RND (~100K params)

## Usage
```python
import openai

client = openai.OpenAI(
    base_url="http://localhost:8000/v1",
    api_key="not-needed"
)

response = client.chat.completions.create(
    model="dheera-v0.3.0",
    messages=[{"role": "user", "content": "Hello!"}]
)
```
    """,
    version="0.3.0",
    lifespan=lifespan
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# =============================================================================
# API Endpoints
# =============================================================================

@app.get("/")
async def root():
    """Root endpoint with API info."""
    return {
        "name": "Dheera API",
        "version": "0.3.0",
        "status": "running",
        "model": "dheera-v0.3.0",
        "endpoints": {
            "chat": "/v1/chat/completions",
            "completions": "/v1/completions",
            "models": "/v1/models",
            "feedback": "/v1/feedback",
            "health": "/health",
            "stats": "/stats"
        }
    }


@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "model_loaded": dheera_model is not None,
        "slm_available": dheera_model.slm_available if dheera_model else False,
        "timestamp": datetime.now().isoformat()
    }


@app.get("/stats")
async def get_stats():
    """Get server and model statistics."""
    if not dheera_model:
        raise HTTPException(status_code=503, detail="Model not loaded")
        
    return {
        "model": dheera_model.MODEL_ID,
        "requests": dheera_model.total_requests,
        "tokens_generated": dheera_model.total_tokens_generated,
        "dqn_epsilon": dheera_model.dqn.epsilon,
        "action_distribution": {
            dheera_model.SPECS["supported_actions"][i]: count 
            for i, count in dheera_model.action_distribution.items()
        },
        "active_sessions": len(dheera_model.contexts),
        "cached_responses": len(dheera_model.response_cache)
    }


@app.get("/v1/models")
async def list_models():
    """List available models (OpenAI-compatible)."""
    if not dheera_model:
        raise HTTPException(status_code=503, detail="Model not loaded")
        
    return {
        "object": "list",
        "data": [dheera_model.get_model_info()]
    }


@app.get("/v1/models/{model_id}")
async def get_model(model_id: str):
    """Get model information (OpenAI-compatible)."""
    if not dheera_model:
        raise HTTPException(status_code=503, detail="Model not loaded")
        
    if model_id != dheera_model.MODEL_ID and model_id != "dheera":
        raise HTTPException(status_code=404, detail=f"Model {model_id} not found")
        
    return dheera_model.get_model_info()


@app.post("/v1/chat/completions")
async def chat_completions(request: ChatCompletionRequest):
    """
    Chat completions endpoint (OpenAI-compatible).
    
    Enhanced with Dheera's DQN action selection and RLHF scoring.
    """
    if not dheera_model:
        raise HTTPException(status_code=503, detail="Model not loaded")
    
    try:
        # Generate response
        result = await dheera_model.generate(
            messages=request.messages,
            temperature=request.temperature,
            max_tokens=request.max_tokens or 1024,
            use_dqn=request.use_dqn,
            use_rlhf=request.use_rlhf,
            use_curiosity=request.use_curiosity,
            session_id=request.user,
            stream=request.stream
        )
        
        # Build response
        choice = Choice(
            index=0,
            message=ChatMessage(role="assistant", content=result["response_text"]),
            finish_reason="stop",
            action_taken=result["action"]["name"] if request.return_action_info else None,
            action_confidence=result["action"]["confidence"] if request.return_action_info else None,
            reward_score=result["scores"]["reward"] if request.return_action_info else None,
            curiosity_bonus=result["scores"]["curiosity"] if request.return_action_info else None
        )
        
        response = ChatCompletionResponse(
            id=result["response_id"],
            created=int(datetime.now().timestamp()),
            model=dheera_model.MODEL_ID,
            choices=[choice],
            usage=Usage(
                prompt_tokens=result["tokens"]["prompt"],
                completion_tokens=result["tokens"]["completion"],
                total_tokens=result["tokens"]["total"]
            ),
            dheera_metadata={
                "action": result["action"],
                "scores": result["scores"],
                "session_id": result["session_id"]
            } if request.return_action_info else None
        )
        
        return response
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/v1/completions")
async def completions(request: CompletionRequest):
    """Text completions endpoint (OpenAI-compatible)."""
    if not dheera_model:
        raise HTTPException(status_code=503, detail="Model not loaded")
    
    # Convert to chat format
    messages = [ChatMessage(role="user", content=request.prompt)]
    
    result = await dheera_model.generate(
        messages=messages,
        temperature=request.temperature,
        max_tokens=request.max_tokens or 1024
    )
    
    return {
        "id": result["response_id"],
        "object": "text_completion",
        "created": int(datetime.now().timestamp()),
        "model": dheera_model.MODEL_ID,
        "choices": [{
            "text": result["response_text"],
            "index": 0,
            "finish_reason": "stop"
        }],
        "usage": {
            "prompt_tokens": result["tokens"]["prompt"],
            "completion_tokens": result["tokens"]["completion"],
            "total_tokens": result["tokens"]["total"]
        }
    }


@app.post("/v1/feedback")
async def provide_feedback(request: FeedbackRequest):
    """
    Provide feedback for RLHF training.
    
    Use this endpoint to rate responses and improve the model.
    """
    if not dheera_model:
        raise HTTPException(status_code=503, detail="Model not loaded")
    
    # Convert feedback type to rating if provided
    rating = request.rating
    if request.feedback_type:
        feedback_map = {"++": 1.0, "+": 0.5, "-": -0.5, "--": -1.0}
        rating = feedback_map.get(request.feedback_type, rating)
    
    success = dheera_model.provide_feedback(request.response_id, rating)
    
    if not success:
        raise HTTPException(status_code=404, detail="Response ID not found")
        
    return {
        "status": "success",
        "response_id": request.response_id,
        "rating": rating,
        "message": "Feedback recorded for RLHF training"
    }


# =============================================================================
# Main Entry Point
# =============================================================================

def main():
    """Main entry point."""
    import argparse
    
    parser = argparse.ArgumentParser(description="Dheera API Server")
    parser.add_argument("--host", default="127.0.0.1", help="Host to bind to")
    parser.add_argument("--port", type=int, default=8000, help="Port to bind to")
    parser.add_argument("--reload", action="store_true", help="Enable auto-reload")
    parser.add_argument("--workers", type=int, default=1, help="Number of workers")
    
    args = parser.parse_args()
    
    print(f"""
╔═══════════════════════════════════════════════════════════════╗
║              धीर  DHEERA API SERVER                           ║
║              RLHF + DQN + SLM Model API                       ║
╠═══════════════════════════════════════════════════════════════╣
║                                                               ║
║  Endpoints:                                                   ║
║    POST /v1/chat/completions  - Chat (OpenAI-compatible)     ║
║    POST /v1/completions       - Completions                   ║
║    GET  /v1/models            - List models                   ║
║    POST /v1/feedback          - RLHF feedback                 ║
║    GET  /health               - Health check                  ║
║    GET  /stats                - Statistics                    ║
║                                                               ║
║  Server: http://{args.host}:{args.port}                             ║
║  Docs:   http://{args.host}:{args.port}/docs                        ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
    """)
    
    uvicorn.run(
        "api_server:app",
        host=args.host,
        port=args.port,
        reload=args.reload,
        workers=args.workers
    )


if __name__ == "__main__":
    main()
