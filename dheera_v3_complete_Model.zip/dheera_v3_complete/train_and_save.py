#!/usr/bin/env python3
"""
Dheera Training & Model Export Script
=====================================
Trains the complete RLHF + DQN + SLM system and saves all components.

This script:
1. Initializes DQN agent with curiosity-driven exploration
2. Trains with simulated or interactive feedback (RLHF)
3. Integrates with SLM (Ollama/phi3) for response generation
4. Saves all model weights and configurations

Usage:
    python train_and_save.py                      # Interactive training
    python train_and_save.py --auto --episodes 100  # Auto training
    python train_and_save.py --export-only        # Just export current state
    python train_and_save.py --load checkpoint/   # Load and continue training
"""

import os
import sys
import json
import time
import shutil
import random
import argparse
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict, Any, List, Tuple
from dataclasses import dataclass, asdict

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent))

import numpy as np
import torch

# Core components
from core.dqn_agent import DQNAgent
from core.action_space import ActionSpace, Action
from core.state_builder import StateBuilder, ConversationContext
from core.curiosity_rnd import CuriosityModule

# Memory components  
from memory.replay_buffer import ReplayBuffer, PrioritizedReplayBuffer
from memory.episodic_memory import EpisodicMemory, MemoryEntry, Episode

# RLHF components
from rlhf.reward_model import RewardModel
from rlhf.preference_learner import PreferenceLearner
from rlhf.feedback_collector import FeedbackCollector, FeedbackEntry

# Brain components
from brain.slm_interface import SLMInterface

# Cognitive components
from cognitive.intent_classifier import IntentClassifier


@dataclass
class TrainingConfig:
    """Training configuration."""
    # Training settings
    num_episodes: int = 100
    max_steps_per_episode: int = 50
    warmup_episodes: int = 10
    
    # DQN settings
    state_dim: int = 64
    action_dim: int = 7
    hidden_dim: int = 128
    gamma: float = 0.99
    lr: float = 0.001
    batch_size: int = 32
    buffer_capacity: int = 100000
    epsilon_start: float = 1.0
    epsilon_end: float = 0.05
    epsilon_decay_steps: int = 5000
    target_update_freq: int = 100
    
    # Curiosity settings
    curiosity_enabled: bool = True
    curiosity_coef: float = 0.1
    
    # RLHF settings
    rlhf_enabled: bool = True
    feedback_weight: float = 1.0
    preference_lr: float = 0.0001
    
    # SLM settings
    slm_provider: str = "ollama"
    slm_model: str = "phi3:mini"
    slm_enabled: bool = True
    
    # Save settings
    save_dir: str = "./trained_models"
    save_every: int = 10
    checkpoint_name: str = "dheera_rlhf_dqn"
    
    def to_dict(self) -> dict:
        return asdict(self)
    
    @classmethod
    def from_dict(cls, d: dict) -> "TrainingConfig":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


class DheeraTrainer:
    """
    Complete Dheera Training System
    Combines DQN + RLHF + SLM into a trainable agent.
    """
    
    def __init__(self, config: TrainingConfig):
        self.config = config
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {self.device}")
        
        # Initialize components
        self._init_components()
        
        # Training state
        self.total_steps = 0
        self.episode_rewards = []
        self.training_history = []
        
    def _init_components(self):
        """Initialize all training components."""
        print("\n📦 Initializing components...")
        
        # Action space
        self.action_space = ActionSpace()
        print(f"  ✓ Action Space ({self.action_space.size} actions)")
        
        # State builder
        self.state_builder = StateBuilder(state_dim=self.config.state_dim)
        print(f"  ✓ State Builder (dim={self.config.state_dim})")
        
        # DQN Agent
        self.dqn = DQNAgent(
            state_dim=self.config.state_dim,
            action_dim=self.config.action_dim,
            hidden_dim=self.config.hidden_dim,
            gamma=self.config.gamma,
            lr=self.config.lr,
            batch_size=self.config.batch_size,
            buffer_capacity=self.config.buffer_capacity,
            epsilon_start=self.config.epsilon_start,
            epsilon_end=self.config.epsilon_end,
            epsilon_decay_steps=self.config.epsilon_decay_steps,
            target_update_freq=self.config.target_update_freq,
            device=self.device
        )
        print(f"  ✓ DQN Agent (hidden={self.config.hidden_dim})")
        
        # Curiosity Module
        if self.config.curiosity_enabled:
            self.curiosity = CuriosityModule(
                state_dim=self.config.state_dim,
                hidden_dim=self.config.hidden_dim,
                device=self.device
            )
            print(f"  ✓ Curiosity Module (RND)")
        else:
            self.curiosity = None
            
        # Replay Buffer (Prioritized)
        self.replay_buffer = PrioritizedReplayBuffer(
            capacity=self.config.buffer_capacity,
            alpha=0.6,
            beta_start=0.4
        )
        print(f"  ✓ Prioritized Replay Buffer (capacity={self.config.buffer_capacity})")
        
        # Episodic Memory
        self.episodic_memory = EpisodicMemory()
        print(f"  ✓ Episodic Memory")
        
        # RLHF Components
        if self.config.rlhf_enabled:
            self.reward_model = RewardModel(
                state_dim=self.config.state_dim,
                action_dim=self.config.action_dim,
                hidden_dim=self.config.hidden_dim
            )
            self.preference_learner = PreferenceLearner(
                reward_model=self.reward_model,
                lr=self.config.preference_lr
            )
            self.feedback_collector = FeedbackCollector()
            print(f"  ✓ RLHF Components (Reward Model + Preference Learner)")
        else:
            self.reward_model = None
            self.preference_learner = None
            self.feedback_collector = None
            
        # SLM Interface
        if self.config.slm_enabled:
            try:
                self.slm = SLMInterface(
                    provider=self.config.slm_provider,
                    model=self.config.slm_model
                )
                if self.slm.is_available():
                    print(f"  ✓ SLM Interface ({self.config.slm_provider}/{self.config.slm_model})")
                else:
                    print(f"  ⚠ SLM not available, using echo mode")
                    self.slm.use_echo_mode()
            except Exception as e:
                print(f"  ⚠ SLM init failed: {e}, using echo mode")
                self.slm = None
        else:
            self.slm = None
            
        # Intent Classifier
        self.intent_classifier = IntentClassifier()
        print(f"  ✓ Intent Classifier")
        
        print("✅ All components initialized!\n")
        
    def compute_reward(
        self,
        state: np.ndarray,
        action: int,
        response_quality: float = 0.0,
        human_feedback: Optional[float] = None,
        task_success: bool = False
    ) -> float:
        """
        Compute combined reward from multiple sources.
        
        Components:
        1. Intrinsic reward (curiosity)
        2. Human feedback (RLHF)
        3. Learned reward model
        4. Task completion bonus
        """
        reward = 0.0
        
        # 1. Intrinsic curiosity reward
        if self.curiosity is not None:
            intrinsic = self.curiosity.compute_intrinsic_reward(state)
            reward += self.config.curiosity_coef * intrinsic
            
        # 2. Human feedback (highest weight)
        if human_feedback is not None:
            reward += self.config.feedback_weight * human_feedback
            
            # Store feedback for RLHF training
            if self.feedback_collector:
                self.feedback_collector.add_feedback(FeedbackEntry(
                    state=state.tolist(),
                    action=action,
                    feedback=human_feedback,
                    timestamp=datetime.now()
                ))
                
        # 3. Learned reward model prediction
        if self.reward_model is not None and human_feedback is None:
            state_tensor = torch.FloatTensor(state).unsqueeze(0).to(self.device)
            action_tensor = torch.LongTensor([action]).to(self.device)
            with torch.no_grad():
                learned_reward = self.reward_model(state_tensor, action_tensor).item()
            reward += 0.5 * learned_reward  # Lower weight than human feedback
            
        # 4. Task success bonus
        if task_success:
            reward += 1.0
            
        # 5. Response quality (if available)
        reward += 0.3 * response_quality
        
        return reward
    
    def train_step(
        self,
        state: np.ndarray,
        action: int,
        reward: float,
        next_state: np.ndarray,
        done: bool
    ) -> Dict[str, float]:
        """Execute one training step."""
        # Store transition
        self.dqn.remember(state, action, reward, next_state, done)
        
        # Train DQN
        loss = 0.0
        if len(self.dqn.buffer) >= self.config.batch_size:
            loss = self.dqn.train_step()
            
        # Update curiosity module
        if self.curiosity is not None:
            self.curiosity.update(state)
            
        # Train reward model periodically
        rlhf_loss = 0.0
        if (self.preference_learner is not None and 
            self.total_steps % 100 == 0 and
            len(self.feedback_collector.feedback_history) >= 10):
            rlhf_loss = self.preference_learner.train_step(
                self.feedback_collector.get_preference_pairs()
            )
            
        self.total_steps += 1
        
        return {
            "dqn_loss": loss,
            "rlhf_loss": rlhf_loss,
            "epsilon": self.dqn.epsilon,
            "buffer_size": len(self.dqn.buffer)
        }
    
    def generate_response(self, query: str, action: Action) -> str:
        """Generate response using SLM based on chosen action."""
        if self.slm is None:
            return f"[{action.name}] Response to: {query}"
            
        # Build prompt based on action
        action_prompts = {
            0: f"Provide a direct, concise answer to: {query}",
            1: f"Ask a clarifying question about: {query}",
            2: f"Use a tool to help answer: {query}",
            3: f"Search the web for information about: {query}",
            4: f"Break down this complex task into steps: {query}",
            5: f"Think step by step about: {query}",
            6: f"Politely decline or redirect: {query}"
        }
        
        prompt = action_prompts.get(action.id, f"Respond to: {query}")
        
        try:
            response = self.slm.generate(prompt, max_tokens=256)
            return response.text if hasattr(response, 'text') else str(response)
        except Exception as e:
            return f"[{action.name}] {query}"
    
    def run_episode(
        self,
        queries: List[str],
        interactive: bool = False
    ) -> Dict[str, Any]:
        """Run one training episode."""
        episode_reward = 0.0
        episode_steps = 0
        episode_data = []
        
        # Create conversation context
        context = ConversationContext()
        
        for query in queries[:self.config.max_steps_per_episode]:
            # Build state
            state = self.state_builder.build(query, context)
            
            # Select action
            action_id = self.dqn.select_action(state)
            action = self.action_space.get_action(action_id)
            
            # Generate response
            response = self.generate_response(query, action)
            
            # Get feedback
            if interactive:
                print(f"\n🗣️ Query: {query}")
                print(f"🤖 Action: {action.name}")
                print(f"💬 Response: {response[:200]}...")
                feedback_str = input("Feedback (++/+/0/-/--) or Enter to skip: ").strip()
                feedback_map = {"++": 1.0, "+": 0.5, "0": 0.0, "-": -0.5, "--": -1.0}
                human_feedback = feedback_map.get(feedback_str)
            else:
                # Simulated feedback based on action appropriateness
                human_feedback = self._simulate_feedback(query, action_id)
            
            # Compute reward
            reward = self.compute_reward(
                state=state,
                action=action_id,
                human_feedback=human_feedback
            )
            
            # Update context
            context.add_turn(query, response)
            
            # Build next state
            next_state = self.state_builder.build("", context)
            done = (episode_steps >= self.config.max_steps_per_episode - 1)
            
            # Training step
            metrics = self.train_step(state, action_id, reward, next_state, done)
            
            episode_reward += reward
            episode_steps += 1
            
            episode_data.append({
                "query": query,
                "action": action.name,
                "reward": reward,
                "feedback": human_feedback
            })
            
        return {
            "total_reward": episode_reward,
            "steps": episode_steps,
            "avg_reward": episode_reward / max(episode_steps, 1),
            "data": episode_data,
            "metrics": metrics
        }
    
    def _simulate_feedback(self, query: str, action_id: int) -> float:
        """Simulate human feedback for auto-training."""
        # Classify intent
        intent = self.intent_classifier.classify(query)
        
        # Simple heuristics for feedback
        query_lower = query.lower()
        
        # Direct questions -> prefer DIRECT_RESPONSE
        if any(w in query_lower for w in ["what", "who", "when", "where", "how"]):
            if action_id == 0:  # DIRECT_RESPONSE
                return random.uniform(0.5, 1.0)
            elif action_id == 3:  # SEARCH_WEB
                return random.uniform(0.3, 0.7)
                
        # Complex tasks -> prefer BREAK_DOWN_TASK
        if any(w in query_lower for w in ["create", "build", "design", "implement"]):
            if action_id == 4:  # BREAK_DOWN_TASK
                return random.uniform(0.5, 1.0)
            elif action_id == 2:  # USE_TOOL
                return random.uniform(0.3, 0.7)
                
        # Confusion -> prefer CLARIFY_QUESTION
        if any(w in query_lower for w in ["confused", "unclear", "don't understand"]):
            if action_id == 1:  # CLARIFY_QUESTION
                return random.uniform(0.5, 1.0)
                
        # Code requests -> prefer USE_TOOL
        if any(w in query_lower for w in ["code", "script", "program", "function"]):
            if action_id == 2:  # USE_TOOL
                return random.uniform(0.5, 1.0)
                
        # Default: slight positive for reasonable actions
        return random.uniform(-0.2, 0.3)
    
    def train(
        self,
        num_episodes: Optional[int] = None,
        interactive: bool = False,
        queries: Optional[List[str]] = None
    ):
        """
        Main training loop.
        
        Args:
            num_episodes: Number of episodes to train
            interactive: Whether to get real human feedback
            queries: Custom training queries (or use defaults)
        """
        num_episodes = num_episodes or self.config.num_episodes
        
        # Default training queries
        if queries is None:
            queries = self._get_training_queries()
            
        print(f"\n🚀 Starting training for {num_episodes} episodes...")
        print(f"   Mode: {'Interactive' if interactive else 'Auto'}")
        print(f"   Queries per episode: {min(len(queries), self.config.max_steps_per_episode)}")
        print("=" * 60)
        
        start_time = time.time()
        
        for episode in range(num_episodes):
            # Shuffle queries for variety
            episode_queries = random.sample(queries, min(len(queries), self.config.max_steps_per_episode))
            
            # Run episode
            result = self.run_episode(episode_queries, interactive=interactive)
            
            self.episode_rewards.append(result["total_reward"])
            self.training_history.append({
                "episode": episode,
                "reward": result["total_reward"],
                "avg_reward": result["avg_reward"],
                "steps": result["steps"],
                "epsilon": result["metrics"]["epsilon"]
            })
            
            # Progress logging
            if (episode + 1) % 10 == 0 or episode == 0:
                avg_reward = np.mean(self.episode_rewards[-10:])
                print(f"Episode {episode+1:4d} | "
                      f"Reward: {result['total_reward']:+.2f} | "
                      f"Avg(10): {avg_reward:+.2f} | "
                      f"ε: {result['metrics']['epsilon']:.3f} | "
                      f"Buffer: {result['metrics']['buffer_size']}")
                
            # Save checkpoint periodically
            if (episode + 1) % self.config.save_every == 0:
                self.save_checkpoint(f"checkpoint_ep{episode+1}")
                
        elapsed = time.time() - start_time
        print("=" * 60)
        print(f"✅ Training complete! ({elapsed:.1f}s)")
        print(f"   Final avg reward: {np.mean(self.episode_rewards[-10:]):.3f}")
        
    def _get_training_queries(self) -> List[str]:
        """Get default training queries."""
        return [
            # Direct questions
            "What is machine learning?",
            "Who invented the telephone?",
            "When was Python created?",
            "Where is the Eiffel Tower?",
            "How does photosynthesis work?",
            
            # Complex tasks
            "Create a REST API for user management",
            "Build a neural network from scratch",
            "Design a database schema for an e-commerce site",
            "Implement a binary search tree",
            
            # Clarification needed
            "I'm confused about this",
            "Can you explain that again?",
            "What do you mean by that?",
            "I don't understand the difference",
            
            # Code requests
            "Write a Python function to sort a list",
            "Create a JavaScript class for a shopping cart",
            "Show me how to use async/await",
            "Write unit tests for this code",
            
            # Search queries
            "What's the latest news about AI?",
            "Find information about climate change",
            "Search for Python best practices",
            "What are the current stock prices?",
            
            # Reasoning tasks
            "Compare React and Vue.js",
            "Analyze the pros and cons of microservices",
            "Evaluate different sorting algorithms",
            "Think through this logic problem",
            
            # Edge cases
            "Hello",
            "Thanks!",
            "Can you help me?",
            "I need assistance with something sensitive",
        ]
    
    def save_checkpoint(self, name: Optional[str] = None):
        """Save training checkpoint."""
        name = name or self.config.checkpoint_name
        save_dir = Path(self.config.save_dir) / name
        save_dir.mkdir(parents=True, exist_ok=True)
        
        print(f"\n💾 Saving checkpoint to {save_dir}...")
        
        # 1. Save DQN weights
        dqn_path = save_dir / "dqn_agent.pt"
        self.dqn.save(str(dqn_path))
        print(f"  ✓ DQN Agent saved")
        
        # 2. Save curiosity module
        if self.curiosity is not None:
            curiosity_path = save_dir / "curiosity_rnd.pt"
            self.curiosity.save(str(curiosity_path))
            print(f"  ✓ Curiosity Module saved")
            
        # 3. Save reward model (RLHF)
        if self.reward_model is not None:
            reward_path = save_dir / "reward_model.pt"
            torch.save(self.reward_model.state_dict(), reward_path)
            print(f"  ✓ Reward Model saved")
            
        # 4. Save training config
        config_path = save_dir / "config.json"
        with open(config_path, 'w') as f:
            json.dump(self.config.to_dict(), f, indent=2)
        print(f"  ✓ Config saved")
        
        # 5. Save training history
        history_path = save_dir / "training_history.json"
        with open(history_path, 'w') as f:
            json.dump(self.training_history, f, indent=2)
        print(f"  ✓ Training history saved")
        
        # 6. Save feedback data (RLHF)
        if self.feedback_collector is not None:
            feedback_path = save_dir / "feedback_data.json"
            self.feedback_collector.save(str(feedback_path))
            print(f"  ✓ Feedback data saved")
            
        # 7. Save model info
        info_path = save_dir / "model_info.json"
        info = {
            "name": "Dheera RLHF+DQN+SLM",
            "version": "0.3.0",
            "created": datetime.now().isoformat(),
            "total_steps": self.total_steps,
            "episodes_trained": len(self.episode_rewards),
            "final_epsilon": self.dqn.epsilon,
            "device": str(self.device),
            "components": {
                "dqn": True,
                "curiosity": self.curiosity is not None,
                "rlhf": self.reward_model is not None,
                "slm": self.config.slm_model if self.slm else None
            }
        }
        with open(info_path, 'w') as f:
            json.dump(info, f, indent=2)
        print(f"  ✓ Model info saved")
        
        print(f"✅ Checkpoint saved to: {save_dir}")
        return str(save_dir)
    
    def load_checkpoint(self, checkpoint_dir: str):
        """Load training checkpoint."""
        checkpoint_dir = Path(checkpoint_dir)
        
        if not checkpoint_dir.exists():
            raise FileNotFoundError(f"Checkpoint not found: {checkpoint_dir}")
            
        print(f"\n📂 Loading checkpoint from {checkpoint_dir}...")
        
        # 1. Load DQN weights
        dqn_path = checkpoint_dir / "dqn_agent.pt"
        if dqn_path.exists():
            self.dqn.load(str(dqn_path))
            print(f"  ✓ DQN Agent loaded")
            
        # 2. Load curiosity module
        curiosity_path = checkpoint_dir / "curiosity_rnd.pt"
        if curiosity_path.exists() and self.curiosity is not None:
            self.curiosity.load(str(curiosity_path))
            print(f"  ✓ Curiosity Module loaded")
            
        # 3. Load reward model
        reward_path = checkpoint_dir / "reward_model.pt"
        if reward_path.exists() and self.reward_model is not None:
            self.reward_model.load_state_dict(torch.load(reward_path))
            print(f"  ✓ Reward Model loaded")
            
        # 4. Load training history
        history_path = checkpoint_dir / "training_history.json"
        if history_path.exists():
            with open(history_path, 'r') as f:
                self.training_history = json.load(f)
            self.episode_rewards = [h["reward"] for h in self.training_history]
            print(f"  ✓ Training history loaded ({len(self.training_history)} episodes)")
            
        # 5. Load feedback data
        feedback_path = checkpoint_dir / "feedback_data.json"
        if feedback_path.exists() and self.feedback_collector is not None:
            self.feedback_collector.load(str(feedback_path))
            print(f"  ✓ Feedback data loaded")
            
        print(f"✅ Checkpoint loaded!")
        
    def export_model(self, export_dir: Optional[str] = None) -> str:
        """
        Export the complete trained model for deployment.
        Creates a self-contained package with all components.
        """
        export_dir = export_dir or f"./exports/dheera_v0.3.0_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        export_path = Path(export_dir)
        export_path.mkdir(parents=True, exist_ok=True)
        
        print(f"\n📦 Exporting model to {export_path}...")
        
        # Save all components
        self.save_checkpoint(str(export_path / "weights"))
        
        # Create loader script
        loader_script = '''#!/usr/bin/env python3
"""
Dheera Model Loader
Load the trained RLHF + DQN + SLM model.
"""

import sys
from pathlib import Path

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

import json
import torch
from core.dqn_agent import DQNAgent
from core.curiosity_rnd import CuriosityModule
from rlhf.reward_model import RewardModel


def load_dheera_model(checkpoint_dir: str = None):
    """Load the complete Dheera model."""
    if checkpoint_dir is None:
        checkpoint_dir = Path(__file__).parent / "weights"
    else:
        checkpoint_dir = Path(checkpoint_dir)
    
    # Load config
    config_path = checkpoint_dir / "config.json"
    with open(config_path, 'r') as f:
        config = json.load(f)
    
    # Load model info
    info_path = checkpoint_dir / "model_info.json"
    with open(info_path, 'r') as f:
        info = json.load(f)
    
    print(f"Loading Dheera v{info.get('version', '0.3.0')}")
    print(f"  Trained for {info.get('episodes_trained', 0)} episodes")
    print(f"  Total steps: {info.get('total_steps', 0)}")
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    # Load DQN
    dqn = DQNAgent(
        state_dim=config['state_dim'],
        action_dim=config['action_dim'],
        hidden_dim=config['hidden_dim'],
        device=device
    )
    dqn.load(str(checkpoint_dir / "dqn_agent.pt"))
    
    # Load Curiosity (optional)
    curiosity = None
    if (checkpoint_dir / "curiosity_rnd.pt").exists():
        curiosity = CuriosityModule(
            state_dim=config['state_dim'],
            hidden_dim=config['hidden_dim'],
            device=device
        )
        curiosity.load(str(checkpoint_dir / "curiosity_rnd.pt"))
    
    # Load Reward Model (optional)
    reward_model = None
    if (checkpoint_dir / "reward_model.pt").exists():
        reward_model = RewardModel(
            state_dim=config['state_dim'],
            action_dim=config['action_dim'],
            hidden_dim=config['hidden_dim']
        )
        reward_model.load_state_dict(torch.load(checkpoint_dir / "reward_model.pt"))
    
    return {
        "dqn": dqn,
        "curiosity": curiosity,
        "reward_model": reward_model,
        "config": config,
        "info": info
    }


if __name__ == "__main__":
    model = load_dheera_model()
    print("\\n✅ Model loaded successfully!")
    print(f"   DQN epsilon: {model['dqn'].epsilon:.4f}")
'''
        
        loader_path = export_path / "load_model.py"
        with open(loader_path, 'w') as f:
            f.write(loader_script)
        print(f"  ✓ Loader script created")
        
        # Create README
        readme = f"""# Dheera RLHF + DQN + SLM Model

## Model Information
- **Version**: 0.3.0
- **Exported**: {datetime.now().isoformat()}
- **Episodes Trained**: {len(self.episode_rewards)}
- **Total Steps**: {self.total_steps}

## Components
- **DQN Agent**: Deep Q-Network for action selection
- **Curiosity Module**: RND-based intrinsic motivation
- **Reward Model**: Learned from human feedback (RLHF)
- **SLM Integration**: {self.config.slm_model}

## Usage

```python
from load_model import load_dheera_model

# Load the trained model
model = load_dheera_model()

# Use DQN for action selection
action = model['dqn'].select_action(state)

# Get intrinsic reward
if model['curiosity']:
    intrinsic = model['curiosity'].compute_intrinsic_reward(state)
```

## Files
- `weights/` - Model weights and checkpoints
- `load_model.py` - Helper script to load the model
- `README.md` - This file

## Training Configuration
```json
{json.dumps(self.config.to_dict(), indent=2)}
```
"""
        
        readme_path = export_path / "README.md"
        with open(readme_path, 'w') as f:
            f.write(readme)
        print(f"  ✓ README created")
        
        print(f"\n✅ Model exported to: {export_path}")
        return str(export_path)


def main():
    parser = argparse.ArgumentParser(
        description="Train and save Dheera RLHF + DQN + SLM model",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python train_and_save.py                        # Interactive training (100 episodes)
  python train_and_save.py --auto                 # Auto training with simulated feedback
  python train_and_save.py --auto --episodes 500  # Train for 500 episodes
  python train_and_save.py --export-only          # Export current model without training
  python train_and_save.py --load ./checkpoint    # Continue from checkpoint
        """
    )
    
    parser.add_argument("--episodes", "-e", type=int, default=100,
                        help="Number of training episodes (default: 100)")
    parser.add_argument("--auto", action="store_true",
                        help="Auto training with simulated feedback")
    parser.add_argument("--interactive", "-i", action="store_true",
                        help="Interactive training with human feedback")
    parser.add_argument("--export-only", action="store_true",
                        help="Export model without training")
    parser.add_argument("--load", type=str,
                        help="Load checkpoint before training")
    parser.add_argument("--save-dir", type=str, default="./trained_models",
                        help="Directory to save models")
    parser.add_argument("--no-curiosity", action="store_true",
                        help="Disable curiosity module")
    parser.add_argument("--no-rlhf", action="store_true",
                        help="Disable RLHF components")
    parser.add_argument("--no-slm", action="store_true",
                        help="Disable SLM integration")
    parser.add_argument("--model", type=str, default="phi3:mini",
                        help="SLM model to use (default: phi3:mini)")
    
    args = parser.parse_args()
    
    print("""
╔═══════════════════════════════════════════════════════╗
║     धीर  DHEERA - Training & Export                   ║
║     RLHF + DQN + SLM                                  ║
╚═══════════════════════════════════════════════════════╝
    """)
    
    # Create config
    config = TrainingConfig(
        num_episodes=args.episodes,
        save_dir=args.save_dir,
        curiosity_enabled=not args.no_curiosity,
        rlhf_enabled=not args.no_rlhf,
        slm_enabled=not args.no_slm,
        slm_model=args.model
    )
    
    # Initialize trainer
    trainer = DheeraTrainer(config)
    
    # Load checkpoint if specified
    if args.load:
        trainer.load_checkpoint(args.load)
        
    # Export only mode
    if args.export_only:
        export_path = trainer.export_model()
        print(f"\n🎉 Model exported to: {export_path}")
        return
        
    # Training mode
    interactive = args.interactive and not args.auto
    trainer.train(num_episodes=args.episodes, interactive=interactive)
    
    # Save final model
    print("\n" + "=" * 60)
    final_path = trainer.save_checkpoint("final_model")
    
    # Export
    export_path = trainer.export_model()
    
    print(f"""
╔═══════════════════════════════════════════════════════╗
║                 Training Complete!                    ║
╚═══════════════════════════════════════════════════════╝

📁 Saved locations:
   Checkpoint: {final_path}
   Export:     {export_path}

🚀 To use the trained model:
   python {export_path}/load_model.py

📊 Training summary:
   Episodes:     {len(trainer.episode_rewards)}
   Total steps:  {trainer.total_steps}
   Final reward: {np.mean(trainer.episode_rewards[-10:]):.3f} (avg last 10)
""")


if __name__ == "__main__":
    main()
