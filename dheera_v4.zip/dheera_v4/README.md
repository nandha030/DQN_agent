# 🧠 Dheera v4.0 - Intelligent Emotional AI Companion

**धीर** (Sanskrit: Courageous, Wise, Patient)

An AI that truly understands you - combining emotional intelligence, computer vision, long-term memory, and continuous learning into one unified companion.

---

## 🌟 What Makes Dheera Different?

| Feature | Traditional Chatbots | Dheera v4 |
|---------|---------------------|-----------|
| **Emotional Awareness** | ❌ Ignores emotions | ✅ Detects and responds to feelings |
| **Memory** | ❌ Forgets everything | ✅ Remembers you across sessions |
| **Vision** | ❌ Text only | ✅ Sees and identifies objects (YOLO) |
| **Learning** | ❌ Static | ✅ Learns from your feedback (RLHF) |
| **Action Selection** | ❌ One approach | ✅ 15 strategies via DQN |
| **Personalization** | ❌ Same for everyone | ✅ Adapts to YOU |

---

## 🏗️ Architecture

```
┌──────────────────────────────────────────────────────────────────────────┐
│                         DHEERA v4 ARCHITECTURE                           │
├──────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  ┌─────────────────────────────────────────────────────────────────┐    │
│  │                    PERCEPTION LAYER                              │    │
│  │  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐            │    │
│  │  │  Text   │  │ Emotion │  │  YOLO   │  │  Voice  │            │    │
│  │  │ Parser  │  │Detector │  │ Vision  │  │ (Future)│            │    │
│  │  └────┬────┘  └────┬────┘  └────┬────┘  └────┬────┘            │    │
│  └───────┼────────────┼────────────┼────────────┼──────────────────┘    │
│          └────────────┴─────┬──────┴────────────┘                       │
│                             ▼                                            │
│  ┌─────────────────────────────────────────────────────────────────┐    │
│  │                    MEMORY LAYER                                  │    │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐        │    │
│  │  │ Working  │  │ Episodic │  │ Semantic │  │Emotional │        │    │
│  │  │ Memory   │  │ Memory   │  │ Memory   │  │ Memory   │        │    │
│  │  │(Current) │  │ (Past)   │  │ (Facts)  │  │(Patterns)│        │    │
│  │  └──────────┘  └──────────┘  └──────────┘  └──────────┘        │    │
│  │                                                                  │    │
│  │  ┌────────────────────────────────────────────────────────┐     │    │
│  │  │                    USER PROFILE                         │     │    │
│  │  │  Name, Preferences, Facts, Likes, Emotional Baseline   │     │    │
│  │  └────────────────────────────────────────────────────────┘     │    │
│  └─────────────────────────┬───────────────────────────────────────┘    │
│                            ▼                                             │
│  ┌─────────────────────────────────────────────────────────────────┐    │
│  │                    REASONING LAYER                               │    │
│  │                                                                  │    │
│  │    ┌───────────────────────────────────────────────────┐        │    │
│  │    │              State Vector (128-dim)               │        │    │
│  │    │  [Query + Emotion + Memory + Vision + Context]    │        │    │
│  │    └───────────────────────┬───────────────────────────┘        │    │
│  │                            ▼                                     │    │
│  │    ┌─────────────┐   ┌─────────────┐   ┌─────────────┐          │    │
│  │    │  Emotional  │   │  Curiosity  │   │    RLHF     │          │    │
│  │    │    DQN      │   │    (RND)    │   │   Reward    │          │    │
│  │    │  (Actions)  │   │ (Explore)   │   │   Model     │          │    │
│  │    └──────┬──────┘   └──────┬──────┘   └──────┬──────┘          │    │
│  │           │                 │                 │                  │    │
│  │           └─────────────────┴─────────────────┘                  │    │
│  │                            │                                     │    │
│  │                   Select Best Action                             │    │
│  └─────────────────────────────┬───────────────────────────────────┘    │
│                                ▼                                         │
│  ┌─────────────────────────────────────────────────────────────────┐    │
│  │                    ACTION LAYER (15 Actions)                     │    │
│  │                                                                  │    │
│  │  Information:  [RAG] [Web Search] [Vision] [Direct Answer]      │    │
│  │  Reasoning:    [Think Step-by-Step] [Break Down] [Clarify]      │    │
│  │  Emotional:    [Empathize] [Comfort] [Celebrate] [Encourage]    │    │
│  │  Memory:       [Remember Fact] [Recall Memory]                   │    │
│  │  Meta:         [Multi-Tool] [Defer]                              │    │
│  └─────────────────────────────┬───────────────────────────────────┘    │
│                                ▼                                         │
│  ┌─────────────────────────────────────────────────────────────────┐    │
│  │                    GENERATION LAYER                              │    │
│  │                                                                  │    │
│  │    Tool Results + User Context + Emotional Tone + Personality   │    │
│  │                            │                                     │    │
│  │                            ▼                                     │    │
│  │                    Language Model                                │    │
│  │               (TinyLlama / phi3 / etc.)                         │    │
│  └─────────────────────────────┬───────────────────────────────────┘    │
│                                ▼                                         │
│                         Response to User                                 │
└──────────────────────────────────────────────────────────────────────────┘
```

---

## 🚀 Quick Start

### 1. Installation

```bash
# Clone or extract
cd dheera_v4

# Install dependencies
pip install torch transformers fastapi uvicorn ultralytics duckduckgo-search

# Or full install
pip install -r requirements.txt
```

### 2. Run Interactive Chat

```bash
python dheera_v4.py
```

### 3. Run API Server

```bash
python dheera_v4_api.py --port 8000
```

### 4. Use with OpenAI SDK

```python
from openai import OpenAI

client = OpenAI(
    base_url="http://localhost:8000/v1",
    api_key="not-needed"
)

# Chat
response = client.chat.completions.create(
    model="dheera-v4",
    messages=[
        {"role": "user", "content": "I'm feeling stressed about work lately"}
    ]
)

print(response.choices[0].message.content)
# Dheera detects stress and responds empathetically
```

---

## 🎯 The 15 Actions

Dheera uses a DQN (Deep Q-Network) to select the best action for each situation:

### Information Actions
| # | Action | When Used |
|---|--------|-----------|
| 0 | Direct Answer | Simple questions, greetings |
| 1 | RAG Retrieve | Questions about stored knowledge |
| 2 | Web Search | Current events, facts to look up |
| 3 | Vision Analyze | When image is provided |

### Reasoning Actions
| # | Action | When Used |
|---|--------|-----------|
| 4 | Think Step-by-Step | Complex problems |
| 5 | Ask Clarification | Ambiguous requests |
| 6 | Break Down Task | Large tasks |

### Emotional Actions
| # | Action | When Used |
|---|--------|-----------|
| 7 | Empathize | User shares feelings |
| 8 | Celebrate | User shares good news |
| 9 | Comfort | User is sad/distressed |
| 10 | Encourage | User needs motivation |

### Memory Actions
| # | Action | When Used |
|---|--------|-----------|
| 11 | Remember Fact | User shares personal info |
| 12 | Recall Memory | User references past |

### Meta Actions
| # | Action | When Used |
|---|--------|-----------|
| 13 | Multi-Tool | Complex query needing multiple tools |
| 14 | Defer | Can't help with request |

---

## 💭 Emotional Intelligence

Dheera detects 8 emotions (Plutchik's wheel):

| Emotion | Detection Keywords | Response Style |
|---------|-------------------|----------------|
| 😊 Joy | happy, excited, love | Celebrate, share enthusiasm |
| 😢 Sadness | sad, depressed, lonely | Comfort, empathize |
| 😠 Anger | angry, frustrated, hate | Validate, calm |
| 😰 Fear | scared, worried, anxious | Reassure, comfort |
| 😮 Surprise | wow, shocked, unexpected | Engage, explore |
| 🤢 Disgust | gross, horrible | Acknowledge |
| 🤝 Trust | believe, faith, confident | Reinforce |
| 🤔 Anticipation | waiting, hoping, excited | Build excitement |

**Emotional DQN**: When user is distressed, the DQN biases toward emotional actions (Empathize, Comfort, Encourage) rather than just answering the question.

---

## 🧠 Memory System

### What Dheera Remembers

```python
UserProfile:
  - name: "Nandha"
  - facts: {"job": "AI researcher", "pet": "dog named Max"}
  - likes: ["Python", "machine learning", "coffee"]
  - dislikes: ["cold weather"]
  - emotional_baseline: slightly positive
  - total_messages: 150
  - first_interaction: 2024-01-15
```

### Memory Types

1. **Working Memory**: Current conversation (last 20 messages)
2. **Episodic Memory**: Past conversations ("Remember when we discussed...")
3. **Semantic Memory**: Facts about user ("You mentioned you work at...")
4. **Emotional Memory**: User's emotional patterns ("You seem happier on weekends")

### Automatic Learning

Dheera automatically extracts:
- Your name ("My name is...")
- Likes ("I love...", "I like...")
- Dislikes ("I hate...", "I don't like...")
- Facts ("I work at...", "I live in...")

---

## 👁️ Vision (YOLO)

Analyze images with state-of-the-art object detection:

```python
# Via API
curl -X POST http://localhost:8000/v1/vision/analyze \
  -F "file=@photo.jpg" \
  -F "query=What objects do you see?"

# Response
{
  "response": "I can see a person, a laptop, and a coffee cup...",
  "vision": {
    "objects": [
      {"name": "person", "confidence": 0.95},
      {"name": "laptop", "confidence": 0.89},
      {"name": "cup", "confidence": 0.82}
    ]
  }
}
```

```python
# Via Python
dheera.analyze_image("photo.jpg", "What's in this image?")
```

---

## 📡 API Reference

### Chat (OpenAI-compatible)

```bash
POST /v1/chat/completions

{
  "model": "dheera-v4",
  "messages": [
    {"role": "user", "content": "Hello!"}
  ],
  "return_emotion": true,
  "return_action": true
}
```

Response includes:
- `choices[0].message.content`: Response text
- `dheera.emotion`: Detected emotion
- `dheera.action`: Action taken

### Vision

```bash
POST /v1/vision/analyze
Content-Type: multipart/form-data

file: <image>
query: "What do you see?"
```

### Memory

```bash
GET /v1/memory          # View what Dheera remembers
POST /v1/memory         # Add a fact
DELETE /v1/memory/{key} # Remove a fact
```

### Feedback (RLHF)

```bash
POST /v1/feedback

{
  "rating": 0.8,
  "comment": "Very helpful response!"
}
```

---

## 🔧 Configuration

```python
from dheera_v4 import DheeraV4, DheeraConfig

config = DheeraConfig(
    # LLM
    llm_model="TinyLlama/TinyLlama-1.1B-Chat-v1.0",  # or "microsoft/phi-2"
    max_tokens=512,
    temperature=0.7,
    
    # Vision
    vision_enabled=True,
    yolo_model="yolov8n",  # nano, small, medium, large
    
    # Emotional
    empathy_weight=0.3,  # How much to bias toward emotional actions
    
    # Memory
    memory_capacity=10000,
    user_profile_path="./user_data/profile.json"
)

dheera = DheeraV4(config)
```

---

## 📊 How Learning Works

### 1. DQN Learning
- State = [Query features + Emotion + Memory + Context]
- Action = One of 15 possible actions
- Reward = User feedback + Task success + Emotional appropriateness

### 2. RLHF (Reinforcement Learning from Human Feedback)
```python
# User provides feedback
dheera.provide_feedback(rating=0.8)  # "That was helpful!"

# Dheera learns that this (state, action) pair was good
# Future similar situations will prefer similar actions
```

### 3. Curiosity (RND - Random Network Distillation)
- Explores novel situations
- Prevents getting stuck in same patterns
- Balances exploitation vs exploration

---

## 🆚 Comparison: RAG vs DQN+RLHF

| | RAG | DQN+RLHF (Dheera) |
|---|-----|-------------------|
| **Purpose** | Find information | Choose how to respond |
| **Learning** | None | Learns from feedback |
| **Personalization** | Same for everyone | Adapts to user |
| **Emotional** | No | Yes |
| **Actions** | Just retrieve | 15 different strategies |

**Dheera uses BOTH**: DQN decides whether to use RAG, web search, empathy, etc.

---

## 📁 File Structure

```
dheera_v4/
├── dheera_v4.py        # Main system (2000+ lines)
├── dheera_v4_api.py    # API server
├── requirements.txt    # Dependencies
├── README.md           # This file
│
├── user_data/          # Persistent storage
│   ├── profile.json    # User profile
│   └── feedback.jsonl  # RLHF feedback
│
├── knowledge/          # RAG knowledge base
│   └── *.txt           # Documents
│
├── model_cache/        # Downloaded models
│
└── checkpoints/        # Saved states
    └── dheera_v4/
        ├── dqn.pt
        ├── curiosity.pt
        └── reward_model.pt
```

---

## 🛠️ Troubleshooting

### YOLO not working
```bash
pip install ultralytics opencv-python
```

### LLM too slow
Use a smaller model:
```python
config = DheeraConfig(llm_model="distilgpt2")
```

### Out of memory
```bash
# Use CPU
export CUDA_VISIBLE_DEVICES=""
python dheera_v4.py
```

---

## 🔮 Future Roadmap

- [ ] Voice input/output
- [ ] Multi-modal understanding (video)
- [ ] Proactive check-ins ("How was your day?")
- [ ] Goal tracking
- [ ] Calendar integration
- [ ] Mood journaling
- [ ] Fine-tuned emotional responses

---

## 📜 License

Apache 2.0

---

## 🙏 Acknowledgments

- DQN: DeepMind
- RLHF: OpenAI/Anthropic
- RND Curiosity: OpenAI
- YOLO: Ultralytics
- Emotion Model: Plutchik's Wheel

---

**धीर - Courageous, Wise, Patient**

*An AI companion that truly understands you.*
