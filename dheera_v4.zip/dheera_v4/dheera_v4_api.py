#!/usr/bin/env python3
"""
Dheera v4 API Server
====================
OpenAI-compatible API for the intelligent emotional AI companion.

Endpoints:
- POST /v1/chat/completions  - Chat with Dheera
- POST /v1/vision/analyze    - Analyze images
- GET  /v1/models            - Model info
- GET  /v1/memory            - User memory/profile
- POST /v1/feedback          - RLHF feedback
- GET  /health               - Health check

Usage:
    python dheera_v4_api.py --port 8000
    
Then use with any OpenAI-compatible client:
    from openai import OpenAI
    client = OpenAI(base_url="http://localhost:8000/v1", api_key="not-needed")
"""

import os
import sys
import json
import uuid
import base64
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict, Any, List, Union

# FastAPI
try:
    from fastapi import FastAPI, HTTPException, UploadFile, File, Form
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import JSONResponse
    from pydantic import BaseModel, Field
    import uvicorn
except ImportError:
    print("Installing FastAPI...")
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "fastapi", "uvicorn", "pydantic", "python-multipart"])
    from fastapi import FastAPI, HTTPException, UploadFile, File, Form
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import JSONResponse
    from pydantic import BaseModel, Field
    import uvicorn

# Import Dheera
from dheera_v4 import DheeraV4, DheeraConfig


# =============================================================================
# API MODELS
# =============================================================================

class ChatMessage(BaseModel):
    role: str
    content: str
    name: Optional[str] = None


class ChatRequest(BaseModel):
    model: str = "dheera-v4"
    messages: List[ChatMessage]
    temperature: float = 0.7
    max_tokens: int = 512
    stream: bool = False
    user: Optional[str] = None
    
    # Dheera-specific
    return_emotion: bool = Field(default=True, description="Include emotion detection")
    return_action: bool = Field(default=True, description="Include action info")


class VisionRequest(BaseModel):
    image_url: Optional[str] = None  # URL or base64
    query: str = "What do you see in this image?"


class FeedbackRequest(BaseModel):
    rating: float = Field(..., ge=-1, le=1)
    comment: Optional[str] = ""


class MemoryUpdateRequest(BaseModel):
    fact_key: str
    fact_value: str


# =============================================================================
# API SERVER
# =============================================================================

def create_app(dheera: DheeraV4) -> FastAPI:
    """Create FastAPI application."""
    
    app = FastAPI(
        title="Dheera v4 API",
        description="""
# Dheera v4 - Intelligent Emotional AI Companion

An AI that truly understands you:
- **Emotional Intelligence**: Detects and responds to your emotions
- **Computer Vision**: Sees and identifies objects (YOLO)
- **Long-term Memory**: Remembers you and your preferences
- **Real Tools**: Web search, RAG, code execution
- **Continuous Learning**: Gets better with your feedback (RLHF)

## Quick Start

```python
from openai import OpenAI

client = OpenAI(
    base_url="http://localhost:8000/v1",
    api_key="not-needed"
)

response = client.chat.completions.create(
    model="dheera-v4",
    messages=[{"role": "user", "content": "Hello! I'm feeling a bit stressed today."}]
)

print(response.choices[0].message.content)
# Dheera will detect your stress and respond empathetically
```
        """,
        version="4.0.0"
    )
    
    # CORS
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    # Temp directory for images
    temp_dir = Path("./temp_images")
    temp_dir.mkdir(exist_ok=True)
    
    # -------------------------------------------------------------------------
    # ENDPOINTS
    # -------------------------------------------------------------------------
    
    @app.get("/")
    async def root():
        """API information."""
        return {
            "name": "Dheera v4 API",
            "version": "4.0.0",
            "description": "Intelligent Emotional AI Companion",
            "features": [
                "Emotional Intelligence",
                "Computer Vision (YOLO)",
                "Long-term Memory",
                "Web Search",
                "RAG Knowledge Base",
                "RLHF Learning"
            ],
            "endpoints": {
                "chat": "/v1/chat/completions",
                "vision": "/v1/vision/analyze",
                "memory": "/v1/memory",
                "feedback": "/v1/feedback",
                "models": "/v1/models",
                "health": "/health"
            }
        }
    
    @app.get("/health")
    async def health():
        """Health check."""
        return {
            "status": "healthy",
            "model": "dheera-v4",
            "components": {
                "llm": dheera.llm is not None,
                "vision": dheera.vision.available,
                "web_search": dheera.web_search.available
            }
        }
    
    @app.get("/v1/models")
    async def list_models():
        """List available models."""
        stats = dheera.get_stats()
        
        return {
            "object": "list",
            "data": [{
                "id": "dheera-v4",
                "object": "model",
                "created": int(datetime.now().timestamp()),
                "owned_by": "dheera",
                "name": "Dheera v4 - Intelligent Emotional AI Companion",
                "description": "AI companion with emotional intelligence, vision, memory, and learning",
                "capabilities": {
                    "chat": True,
                    "vision": stats["tools"]["vision"],
                    "web_search": stats["tools"]["web_search"],
                    "memory": True,
                    "emotional_intelligence": True,
                    "rlhf_feedback": True
                },
                "architecture": {
                    "components": [
                        "Emotional DQN (action selection)",
                        "RLHF Reward Model (quality prediction)",
                        "Curiosity Module (exploration)",
                        "YOLO (object detection)",
                        "RAG (knowledge retrieval)",
                        "Long-term Memory (user modeling)"
                    ],
                    "action_space": 15,
                    "state_dim": 128,
                    "emotional_awareness": True
                },
                "user_stats": stats["user"]
            }]
        }
    
    @app.post("/v1/chat/completions")
    async def chat_completions(request: ChatRequest):
        """
        Chat with Dheera (OpenAI-compatible).
        
        Dheera will:
        1. Detect your emotional state
        2. Select the best action strategy
        3. Use tools if needed (search, RAG, etc.)
        4. Generate an emotionally appropriate response
        """
        # Get user message
        user_message = ""
        for msg in request.messages:
            if msg.role == "user":
                user_message = msg.content
        
        if not user_message:
            raise HTTPException(400, "No user message found")
        
        # Generate response
        result = dheera(user_message, return_details=True)
        
        # Build response
        response_content = result["response"]
        
        # Create OpenAI-compatible response
        response = {
            "id": f"dheera-{uuid.uuid4().hex[:12]}",
            "object": "chat.completion",
            "created": int(datetime.now().timestamp()),
            "model": "dheera-v4",
            "choices": [{
                "index": 0,
                "message": {
                    "role": "assistant",
                    "content": response_content
                },
                "finish_reason": "stop"
            }],
            "usage": {
                "prompt_tokens": len(user_message.split()),
                "completion_tokens": len(response_content.split()),
                "total_tokens": len(user_message.split()) + len(response_content.split())
            }
        }
        
        # Add Dheera-specific info
        if request.return_emotion or request.return_action:
            response["dheera"] = {}
            
            if request.return_emotion:
                response["dheera"]["emotion"] = result["emotion"]
            
            if request.return_action:
                response["dheera"]["action"] = result["action"]
                response["dheera"]["scores"] = result["scores"]
        
        return response
    
    @app.post("/v1/vision/analyze")
    async def analyze_vision(
        file: Optional[UploadFile] = File(None),
        image_url: Optional[str] = Form(None),
        query: str = Form("What do you see in this image?")
    ):
        """
        Analyze an image using YOLO and respond.
        
        Accepts either:
        - file: Uploaded image file
        - image_url: Base64 encoded image or URL
        """
        if not dheera.vision.available:
            raise HTTPException(503, "Vision system not available. Install: pip install ultralytics")
        
        image_path = None
        
        try:
            if file:
                # Save uploaded file
                image_path = temp_dir / f"{uuid.uuid4().hex}.jpg"
                content = await file.read()
                with open(image_path, "wb") as f:
                    f.write(content)
                    
            elif image_url:
                if image_url.startswith("data:image"):
                    # Base64 encoded
                    header, data = image_url.split(",", 1)
                    image_bytes = base64.b64decode(data)
                    image_path = temp_dir / f"{uuid.uuid4().hex}.jpg"
                    with open(image_path, "wb") as f:
                        f.write(image_bytes)
                else:
                    # URL - would need to download
                    raise HTTPException(400, "URL images not yet supported. Please upload or use base64.")
            else:
                raise HTTPException(400, "No image provided. Use 'file' upload or 'image_url'.")
            
            # Analyze
            result = dheera(query, image_path=str(image_path), return_details=True)
            
            return {
                "response": result["response"],
                "vision": result.get("vision", {}),
                "emotion": result["emotion"],
                "action": result["action"]
            }
            
        finally:
            # Cleanup
            if image_path and image_path.exists():
                try:
                    image_path.unlink()
                except:
                    pass
    
    @app.get("/v1/memory")
    async def get_memory():
        """Get what Dheera remembers about the user."""
        profile = dheera.memory.user_profile
        
        return {
            "user_id": profile.user_id,
            "name": profile.name,
            "facts": profile.facts,
            "likes": profile.likes,
            "dislikes": profile.dislikes,
            "communication_style": profile.communication_style,
            "total_messages": profile.total_messages,
            "first_interaction": profile.first_interaction.isoformat(),
            "last_interaction": profile.last_interaction.isoformat(),
            "average_sentiment": profile.average_sentiment,
            "relationship_duration_days": (datetime.now() - profile.first_interaction).days
        }
    
    @app.post("/v1/memory")
    async def update_memory(request: MemoryUpdateRequest):
        """Manually add a fact to Dheera's memory."""
        dheera.memory.user_profile.facts[request.fact_key] = request.fact_value
        dheera.memory.save_profile()
        
        return {
            "status": "success",
            "message": f"I'll remember that your {request.fact_key} is {request.fact_value}"
        }
    
    @app.delete("/v1/memory/{fact_key}")
    async def delete_memory(fact_key: str):
        """Remove a fact from memory."""
        if fact_key in dheera.memory.user_profile.facts:
            del dheera.memory.user_profile.facts[fact_key]
            dheera.memory.save_profile()
            return {"status": "success", "message": f"Forgot about {fact_key}"}
        raise HTTPException(404, f"No memory of {fact_key}")
    
    @app.post("/v1/feedback")
    async def provide_feedback(request: FeedbackRequest):
        """
        Provide feedback on last response for RLHF training.
        
        Rating scale:
        - 1.0: Excellent, exactly what I wanted
        - 0.5: Good, helpful
        - 0.0: Neutral, okay
        - -0.5: Not great, could be better
        - -1.0: Bad, not helpful at all
        """
        dheera.provide_feedback(request.rating, request.comment)
        
        return {
            "status": "success",
            "message": "Thank you! Your feedback helps me understand you better.",
            "rating": request.rating
        }
    
    @app.get("/v1/stats")
    async def get_stats():
        """Get detailed system statistics."""
        return dheera.get_stats()
    
    @app.post("/v1/save")
    async def save_checkpoint():
        """Save current state."""
        dheera.save()
        return {"status": "success", "message": "Saved successfully"}
    
    @app.get("/v1/actions")
    async def list_actions():
        """List all available actions Dheera can take."""
        from dheera_v4 import ActionSpace, ActionType
        
        actions = []
        for action_type in ActionType:
            info = ActionSpace.ACTIONS[action_type]
            actions.append({
                "id": action_type.value,
                "name": info.name,
                "description": info.description,
                "emotional_valence": info.emotional_valence,
                "requires_tool": info.requires_tool
            })
        
        return {"actions": actions}
    
    return app


def run_api_server(dheera: DheeraV4, host: str = "127.0.0.1", port: int = 8000):
    """Run the API server."""
    
    app = create_app(dheera)
    
    print(f"""
╔═══════════════════════════════════════════════════════════════════╗
║              धीर  DHEERA v4 API SERVER                            ║
║              Intelligent Emotional AI Companion                   ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║  Endpoints:                                                       ║
║    POST /v1/chat/completions  - Chat (OpenAI-compatible)         ║
║    POST /v1/vision/analyze    - Analyze images                    ║
║    GET  /v1/memory            - View user memory                  ║
║    POST /v1/feedback          - Provide RLHF feedback             ║
║    GET  /v1/models            - Model information                 ║
║                                                                   ║
║  Server: http://{host}:{port}                                         ║
║  Docs:   http://{host}:{port}/docs                                    ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
    """)
    
    uvicorn.run(app, host=host, port=port)


# =============================================================================
# MAIN
# =============================================================================

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Dheera v4 API Server")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--no-llm", action="store_true")
    
    args = parser.parse_args()
    
    # Initialize Dheera
    dheera = DheeraV4(load_llm=not args.no_llm)
    
    # Run server
    run_api_server(dheera, host=args.host, port=args.port)
