#!/usr/bin/env python3
"""
Dheera v4.0 - Intelligent Emotional AI Companion
================================================

A truly intelligent AI that:
- Understands your emotions and responds empathetically
- Sees and identifies objects (YOLO)
- Remembers you and learns your preferences
- Uses real tools (RAG, Web Search, Code, etc.)
- Gets smarter with every interaction (RLHF)

Architecture:
- Perception: Text + Emotion + Vision + Voice
- Memory: Episodic + Semantic + Emotional + Preferences
- Reasoning: DQN + Emotional Logic + Curiosity
- Actions: 15 real tools orchestrated by DQN
- Generation: Personalized, emotionally-aware LLM

Usage:
    python dheera_v4.py                    # Interactive chat
    python dheera_v4.py --api --port 8000  # API server
    python dheera_v4.py --image photo.jpg  # Analyze image
"""

import os
import sys
import json
import uuid
import hashlib
import asyncio
from pathlib import Path
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List, Tuple, Union
from dataclasses import dataclass, field, asdict
from enum import Enum, auto
from collections import deque
import warnings
warnings.filterwarnings("ignore")

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


# =============================================================================
# CONFIGURATION
# =============================================================================

@dataclass
class DheeraConfig:
    """Master configuration for Dheera v4."""
    
    # Model settings
    version: str = "4.0.0"
    name: str = "Dheera"
    personality: str = "warm, curious, empathetic, wise"
    
    # Architecture
    state_dim: int = 128
    action_dim: int = 15
    hidden_dim: int = 256
    emotion_dim: int = 8
    memory_dim: int = 64
    
    # LLM settings
    llm_provider: str = "transformers"  # or "ollama"
    llm_model: str = "TinyLlama/TinyLlama-1.1B-Chat-v1.0"
    max_tokens: int = 512
    temperature: float = 0.7
    
    # Vision settings
    vision_enabled: bool = True
    yolo_model: str = "yolov8n"  # nano for speed
    
    # Memory settings
    memory_capacity: int = 10000
    user_profile_path: str = "./user_data/profile.json"
    conversation_db: str = "./user_data/conversations.db"
    
    # Learning rates
    dqn_lr: float = 0.001
    rlhf_lr: float = 0.0001
    
    # Emotional parameters
    empathy_weight: float = 0.3
    emotional_memory_decay: float = 0.95


# =============================================================================
# EMOTIONS
# =============================================================================

class Emotion(Enum):
    """Plutchik's wheel of emotions."""
    JOY = "joy"
    SADNESS = "sadness"
    ANGER = "anger"
    FEAR = "fear"
    SURPRISE = "surprise"
    DISGUST = "disgust"
    TRUST = "trust"
    ANTICIPATION = "anticipation"
    NEUTRAL = "neutral"


@dataclass
class EmotionalState:
    """Current emotional state with intensity."""
    primary: Emotion = Emotion.NEUTRAL
    secondary: Optional[Emotion] = None
    intensity: float = 0.5  # 0-1
    valence: float = 0.0    # -1 (negative) to +1 (positive)
    arousal: float = 0.5    # 0 (calm) to 1 (excited)
    
    def to_vector(self) -> np.ndarray:
        """Convert to 8-dim vector for state representation."""
        emotions = [e for e in Emotion if e != Emotion.NEUTRAL]
        vec = np.zeros(8)
        for i, e in enumerate(emotions):
            if e == self.primary:
                vec[i] = self.intensity
            elif e == self.secondary:
                vec[i] = self.intensity * 0.5
        return vec


class EmotionDetector:
    """Detect emotions from text using keywords and patterns."""
    
    EMOTION_KEYWORDS = {
        Emotion.JOY: ["happy", "glad", "excited", "great", "wonderful", "love", "amazing", 
                      "awesome", "fantastic", "joy", "delighted", "pleased", "thrilled", "😊", "😄", "❤️"],
        Emotion.SADNESS: ["sad", "unhappy", "depressed", "down", "miserable", "lonely", 
                          "disappointed", "hurt", "crying", "tears", "grief", "😢", "😭", "💔"],
        Emotion.ANGER: ["angry", "mad", "furious", "annoyed", "frustrated", "irritated",
                        "hate", "rage", "pissed", "upset", "😠", "😡", "🤬"],
        Emotion.FEAR: ["afraid", "scared", "worried", "anxious", "nervous", "terrified",
                       "panic", "dread", "uneasy", "concerned", "😰", "😨", "😱"],
        Emotion.SURPRISE: ["surprised", "shocked", "amazed", "astonished", "wow", "unexpected",
                           "unbelievable", "whoa", "😮", "😲", "🤯"],
        Emotion.DISGUST: ["disgusted", "gross", "sick", "revolting", "horrible", "nasty",
                          "eww", "yuck", "🤢", "🤮"],
        Emotion.TRUST: ["trust", "believe", "faith", "confident", "reliable", "honest",
                        "loyal", "depend", "safe", "secure"],
        Emotion.ANTICIPATION: ["excited", "waiting", "hoping", "expecting", "looking forward",
                                "can't wait", "eager", "anticipate", "soon"],
    }
    
    INTENSITY_MODIFIERS = {
        "very": 1.3, "extremely": 1.5, "so": 1.2, "really": 1.2,
        "a bit": 0.6, "slightly": 0.5, "somewhat": 0.7, "kind of": 0.6
    }
    
    def detect(self, text: str) -> EmotionalState:
        """Detect emotional state from text."""
        text_lower = text.lower()
        
        # Count emotion keywords
        scores = {}
        for emotion, keywords in self.EMOTION_KEYWORDS.items():
            score = sum(1 for kw in keywords if kw in text_lower)
            if score > 0:
                scores[emotion] = score
        
        if not scores:
            return EmotionalState()
        
        # Get primary and secondary emotions
        sorted_emotions = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        primary = sorted_emotions[0][0]
        secondary = sorted_emotions[1][0] if len(sorted_emotions) > 1 else None
        
        # Calculate intensity based on modifiers
        intensity = 0.5
        for modifier, mult in self.INTENSITY_MODIFIERS.items():
            if modifier in text_lower:
                intensity *= mult
        intensity = min(1.0, intensity)
        
        # Calculate valence
        positive = {Emotion.JOY, Emotion.TRUST, Emotion.ANTICIPATION}
        negative = {Emotion.SADNESS, Emotion.ANGER, Emotion.FEAR, Emotion.DISGUST}
        
        if primary in positive:
            valence = intensity
        elif primary in negative:
            valence = -intensity
        else:
            valence = 0.0
            
        # Calculate arousal
        high_arousal = {Emotion.ANGER, Emotion.FEAR, Emotion.SURPRISE, Emotion.JOY}
        arousal = 0.8 if primary in high_arousal else 0.4
        
        return EmotionalState(
            primary=primary,
            secondary=secondary,
            intensity=intensity,
            valence=valence,
            arousal=arousal
        )


# =============================================================================
# MEMORY SYSTEM
# =============================================================================

@dataclass
class Memory:
    """A single memory entry."""
    id: str
    type: str  # "episodic", "semantic", "emotional", "preference"
    content: str
    embedding: Optional[np.ndarray] = None
    emotion: Optional[EmotionalState] = None
    importance: float = 0.5
    timestamp: datetime = field(default_factory=datetime.now)
    access_count: int = 0
    last_accessed: datetime = field(default_factory=datetime.now)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class UserProfile:
    """Long-term user profile."""
    user_id: str
    name: Optional[str] = None
    
    # Personality understanding
    communication_style: str = "balanced"  # formal, casual, technical, balanced
    emotional_baseline: EmotionalState = field(default_factory=EmotionalState)
    
    # Preferences
    topics_of_interest: List[str] = field(default_factory=list)
    preferred_response_length: str = "medium"  # short, medium, long
    likes: List[str] = field(default_factory=list)
    dislikes: List[str] = field(default_factory=list)
    
    # Facts
    facts: Dict[str, str] = field(default_factory=dict)  # "job": "engineer", etc.
    
    # Emotional patterns
    emotional_triggers: Dict[str, Emotion] = field(default_factory=dict)
    comfort_topics: List[str] = field(default_factory=list)
    
    # Interaction stats
    total_conversations: int = 0
    total_messages: int = 0
    first_interaction: datetime = field(default_factory=datetime.now)
    last_interaction: datetime = field(default_factory=datetime.now)
    average_sentiment: float = 0.0
    
    def to_dict(self) -> Dict:
        """Convert to dictionary for storage."""
        return {
            "user_id": self.user_id,
            "name": self.name,
            "communication_style": self.communication_style,
            "topics_of_interest": self.topics_of_interest,
            "preferred_response_length": self.preferred_response_length,
            "likes": self.likes,
            "dislikes": self.dislikes,
            "facts": self.facts,
            "comfort_topics": self.comfort_topics,
            "total_conversations": self.total_conversations,
            "total_messages": self.total_messages,
            "first_interaction": self.first_interaction.isoformat(),
            "last_interaction": self.last_interaction.isoformat(),
            "average_sentiment": self.average_sentiment
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> "UserProfile":
        """Load from dictionary."""
        profile = cls(user_id=data["user_id"])
        profile.name = data.get("name")
        profile.communication_style = data.get("communication_style", "balanced")
        profile.topics_of_interest = data.get("topics_of_interest", [])
        profile.preferred_response_length = data.get("preferred_response_length", "medium")
        profile.likes = data.get("likes", [])
        profile.dislikes = data.get("dislikes", [])
        profile.facts = data.get("facts", {})
        profile.comfort_topics = data.get("comfort_topics", [])
        profile.total_conversations = data.get("total_conversations", 0)
        profile.total_messages = data.get("total_messages", 0)
        if "first_interaction" in data:
            profile.first_interaction = datetime.fromisoformat(data["first_interaction"])
        if "last_interaction" in data:
            profile.last_interaction = datetime.fromisoformat(data["last_interaction"])
        profile.average_sentiment = data.get("average_sentiment", 0.0)
        return profile


class MemorySystem:
    """
    Multi-layer memory system.
    
    Layers:
    - Working Memory: Current conversation context
    - Episodic Memory: Past conversations (what happened)
    - Semantic Memory: Facts and knowledge (what is true)
    - Emotional Memory: Emotional patterns (how user feels)
    - Preference Memory: User preferences (what user likes)
    """
    
    def __init__(self, config: DheeraConfig):
        self.config = config
        
        # Memory stores
        self.working_memory: List[Dict] = []  # Current conversation
        self.episodic_memory: List[Memory] = []
        self.semantic_memory: List[Memory] = []
        self.emotional_memory: List[Memory] = []
        
        # User profile
        self.user_profile = self._load_or_create_profile()
        
        # Emotion detector
        self.emotion_detector = EmotionDetector()
        
    def _load_or_create_profile(self) -> UserProfile:
        """Load existing profile or create new one."""
        profile_path = Path(self.config.user_profile_path)
        profile_path.parent.mkdir(parents=True, exist_ok=True)
        
        if profile_path.exists():
            try:
                with open(profile_path) as f:
                    return UserProfile.from_dict(json.load(f))
            except:
                pass
        
        return UserProfile(user_id=str(uuid.uuid4())[:8])
    
    def save_profile(self):
        """Save user profile to disk."""
        profile_path = Path(self.config.user_profile_path)
        profile_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(profile_path, 'w') as f:
            json.dump(self.user_profile.to_dict(), f, indent=2)
    
    def add_to_working_memory(self, role: str, content: str, emotion: Optional[EmotionalState] = None):
        """Add message to working memory."""
        self.working_memory.append({
            "role": role,
            "content": content,
            "emotion": emotion,
            "timestamp": datetime.now().isoformat()
        })
        
        # Keep working memory bounded
        if len(self.working_memory) > 20:
            self.working_memory = self.working_memory[-20:]
    
    def add_memory(self, memory_type: str, content: str, emotion: Optional[EmotionalState] = None,
                   importance: float = 0.5, metadata: Dict = None):
        """Add a new memory."""
        memory = Memory(
            id=str(uuid.uuid4())[:12],
            type=memory_type,
            content=content,
            emotion=emotion,
            importance=importance,
            metadata=metadata or {}
        )
        
        if memory_type == "episodic":
            self.episodic_memory.append(memory)
        elif memory_type == "semantic":
            self.semantic_memory.append(memory)
        elif memory_type == "emotional":
            self.emotional_memory.append(memory)
            
        # Prune old memories
        self._prune_memories()
        
        return memory
    
    def _prune_memories(self):
        """Remove old, low-importance memories."""
        max_per_type = self.config.memory_capacity // 3
        
        for memory_list in [self.episodic_memory, self.semantic_memory, self.emotional_memory]:
            if len(memory_list) > max_per_type:
                # Sort by importance * recency
                now = datetime.now()
                scored = []
                for m in memory_list:
                    age_hours = (now - m.timestamp).total_seconds() / 3600
                    recency_score = 1 / (1 + age_hours / 24)  # Decay over days
                    score = m.importance * 0.7 + recency_score * 0.3
                    scored.append((score, m))
                
                scored.sort(key=lambda x: x[0], reverse=True)
                memory_list.clear()
                memory_list.extend([m for _, m in scored[:max_per_type]])
    
    def search_memories(self, query: str, memory_types: List[str] = None, limit: int = 5) -> List[Memory]:
        """Search memories by keyword matching."""
        query_lower = query.lower()
        query_words = set(query_lower.split())
        
        results = []
        
        memories_to_search = []
        if memory_types is None or "episodic" in memory_types:
            memories_to_search.extend(self.episodic_memory)
        if memory_types is None or "semantic" in memory_types:
            memories_to_search.extend(self.semantic_memory)
        if memory_types is None or "emotional" in memory_types:
            memories_to_search.extend(self.emotional_memory)
        
        for memory in memories_to_search:
            content_words = set(memory.content.lower().split())
            overlap = len(query_words & content_words)
            if overlap > 0:
                results.append((overlap, memory))
        
        results.sort(key=lambda x: x[0], reverse=True)
        return [m for _, m in results[:limit]]
    
    def update_user_profile(self, content: str, emotion: EmotionalState):
        """Update user profile based on interaction."""
        self.user_profile.total_messages += 1
        self.user_profile.last_interaction = datetime.now()
        
        # Update emotional baseline (moving average)
        alpha = 0.1
        self.user_profile.average_sentiment = (
            (1 - alpha) * self.user_profile.average_sentiment +
            alpha * emotion.valence
        )
        
        # Extract potential facts (simple heuristics)
        content_lower = content.lower()
        
        # Name detection
        if "my name is" in content_lower:
            parts = content_lower.split("my name is")
            if len(parts) > 1:
                name = parts[1].strip().split()[0].capitalize()
                self.user_profile.name = name
                self.user_profile.facts["name"] = name
        
        # Interest detection
        if "i love" in content_lower or "i like" in content_lower:
            parts = content_lower.replace("i love", "i like").split("i like")
            if len(parts) > 1:
                interest = parts[1].strip().split('.')[0].strip()
                if interest and interest not in self.user_profile.likes:
                    self.user_profile.likes.append(interest)
        
        if "i hate" in content_lower or "i don't like" in content_lower:
            parts = content_lower.replace("i hate", "i don't like").split("i don't like")
            if len(parts) > 1:
                dislike = parts[1].strip().split('.')[0].strip()
                if dislike and dislike not in self.user_profile.dislikes:
                    self.user_profile.dislikes.append(dislike)
        
        # Save periodically
        if self.user_profile.total_messages % 10 == 0:
            self.save_profile()
    
    def get_context_summary(self) -> str:
        """Get a summary of current context for LLM."""
        summary_parts = []
        
        # User info
        if self.user_profile.name:
            summary_parts.append(f"User's name: {self.user_profile.name}")
        
        if self.user_profile.facts:
            facts_str = ", ".join(f"{k}: {v}" for k, v in list(self.user_profile.facts.items())[:5])
            summary_parts.append(f"Known facts: {facts_str}")
        
        if self.user_profile.likes:
            summary_parts.append(f"User likes: {', '.join(self.user_profile.likes[:5])}")
        
        # Recent conversation
        if self.working_memory:
            recent = self.working_memory[-3:]
            conv = "\n".join(f"{m['role']}: {m['content'][:100]}" for m in recent)
            summary_parts.append(f"Recent conversation:\n{conv}")
        
        return "\n".join(summary_parts)
    
    def get_memory_state_vector(self) -> np.ndarray:
        """Get vector representation of memory state."""
        vec = np.zeros(self.config.memory_dim)
        
        # Conversation length (normalized)
        vec[0] = min(len(self.working_memory) / 20, 1.0)
        
        # Memory counts
        vec[1] = min(len(self.episodic_memory) / 100, 1.0)
        vec[2] = min(len(self.semantic_memory) / 100, 1.0)
        vec[3] = min(len(self.emotional_memory) / 100, 1.0)
        
        # User profile completeness
        vec[4] = 1.0 if self.user_profile.name else 0.0
        vec[5] = min(len(self.user_profile.facts) / 10, 1.0)
        vec[6] = min(len(self.user_profile.likes) / 10, 1.0)
        
        # Emotional baseline
        vec[7] = (self.user_profile.average_sentiment + 1) / 2  # Normalize to 0-1
        
        # Time since first interaction (days, normalized)
        days = (datetime.now() - self.user_profile.first_interaction).days
        vec[8] = min(days / 30, 1.0)
        
        # Fill rest with hash of recent context
        if self.working_memory:
            recent_text = " ".join(m["content"] for m in self.working_memory[-3:])
            hash_val = int(hashlib.md5(recent_text.encode()).hexdigest()[:8], 16)
            for i in range(9, min(self.config.memory_dim, 64)):
                vec[i] = ((hash_val >> (i - 9)) & 1) * 0.5
        
        return vec


# =============================================================================
# VISION SYSTEM (YOLO)
# =============================================================================

class VisionSystem:
    """
    Computer vision using YOLO for object detection.
    Falls back to basic analysis if YOLO not available.
    """
    
    def __init__(self, config: DheeraConfig):
        self.config = config
        self.model = None
        self.available = False
        
        if config.vision_enabled:
            self._init_yolo()
    
    def _init_yolo(self):
        """Initialize YOLO model."""
        try:
            from ultralytics import YOLO
            self.model = YOLO(self.config.yolo_model)
            self.available = True
            print("  ✓ Vision System (YOLO) initialized")
        except ImportError:
            print("  ⚠ YOLO not available. Install: pip install ultralytics")
            self.available = False
        except Exception as e:
            print(f"  ⚠ YOLO init failed: {e}")
            self.available = False
    
    def analyze_image(self, image_path: str) -> Dict[str, Any]:
        """
        Analyze image and detect objects.
        
        Returns:
            {
                "objects": [{"name": "person", "confidence": 0.95, "bbox": [...]}],
                "description": "I see a person and a dog in the image",
                "dominant_colors": [...],
                "scene_type": "outdoor"
            }
        """
        result = {
            "objects": [],
            "description": "",
            "success": False
        }
        
        if not Path(image_path).exists():
            result["error"] = "Image file not found"
            return result
        
        if self.available and self.model:
            try:
                # Run YOLO detection
                detections = self.model(image_path, verbose=False)
                
                objects = []
                for det in detections:
                    if det.boxes is not None:
                        for box in det.boxes:
                            cls_id = int(box.cls[0])
                            conf = float(box.conf[0])
                            name = det.names[cls_id]
                            
                            objects.append({
                                "name": name,
                                "confidence": round(conf, 2),
                                "bbox": box.xyxy[0].tolist()
                            })
                
                result["objects"] = objects
                result["success"] = True
                
                # Generate description
                if objects:
                    obj_names = [o["name"] for o in objects]
                    unique_objs = list(set(obj_names))
                    counts = {o: obj_names.count(o) for o in unique_objs}
                    
                    desc_parts = []
                    for obj, count in counts.items():
                        if count > 1:
                            desc_parts.append(f"{count} {obj}s")
                        else:
                            desc_parts.append(f"a {obj}")
                    
                    result["description"] = f"I can see {', '.join(desc_parts)} in the image."
                else:
                    result["description"] = "I analyzed the image but couldn't detect any specific objects."
                    
            except Exception as e:
                result["error"] = str(e)
                result["description"] = f"I had trouble analyzing the image: {e}"
        else:
            # Fallback: basic image info
            try:
                from PIL import Image
                img = Image.open(image_path)
                result["success"] = True
                result["description"] = f"I can see an image ({img.size[0]}x{img.size[1]} pixels, {img.mode} mode). Install YOLO for object detection: pip install ultralytics"
            except:
                result["description"] = "I received an image but need YOLO for analysis. Install: pip install ultralytics"
        
        return result


# =============================================================================
# EXPANDED ACTION SPACE
# =============================================================================

class ActionType(Enum):
    """15 real actions for the DQN to choose from."""
    
    # Information Actions
    DIRECT_ANSWER = 0        # Answer from knowledge
    RAG_RETRIEVE = 1         # Search knowledge base
    WEB_SEARCH = 2           # Search the internet
    VISION_ANALYZE = 3       # Analyze image
    
    # Reasoning Actions
    THINK_STEP_BY_STEP = 4   # Chain of thought
    ASK_CLARIFICATION = 5    # Need more info
    BREAK_DOWN_TASK = 6      # Complex task decomposition
    
    # Emotional Actions
    EMPATHIZE = 7            # Emotional support
    CELEBRATE = 8            # Share joy
    COMFORT = 9              # Provide comfort
    ENCOURAGE = 10           # Motivate
    
    # Memory Actions
    REMEMBER_FACT = 11       # Store user info
    RECALL_MEMORY = 12       # Retrieve past context
    
    # Meta Actions
    MULTI_TOOL = 13          # Use multiple tools
    DEFER = 14               # Can't help


@dataclass
class ActionInfo:
    """Information about an action."""
    type: ActionType
    name: str
    description: str
    emotional_valence: float  # -1 to 1, how emotionally supportive
    requires_tool: bool
    prompt_template: str


class ActionSpace:
    """Expanded action space with 15 actions."""
    
    ACTIONS = {
        ActionType.DIRECT_ANSWER: ActionInfo(
            type=ActionType.DIRECT_ANSWER,
            name="Direct Answer",
            description="Provide a direct, knowledgeable response",
            emotional_valence=0.0,
            requires_tool=False,
            prompt_template="Answer this question directly and helpfully:\n\nQuestion: {query}\n\nAnswer:"
        ),
        ActionType.RAG_RETRIEVE: ActionInfo(
            type=ActionType.RAG_RETRIEVE,
            name="Search Knowledge",
            description="Search knowledge base for relevant information",
            emotional_valence=0.0,
            requires_tool=True,
            prompt_template="Based on the retrieved knowledge:\n{context}\n\nAnswer the question: {query}\n\nAnswer:"
        ),
        ActionType.WEB_SEARCH: ActionInfo(
            type=ActionType.WEB_SEARCH,
            name="Web Search",
            description="Search the internet for current information",
            emotional_valence=0.0,
            requires_tool=True,
            prompt_template="Based on web search results:\n{context}\n\nAnswer: {query}\n\nResponse:"
        ),
        ActionType.VISION_ANALYZE: ActionInfo(
            type=ActionType.VISION_ANALYZE,
            name="Analyze Image",
            description="Analyze image using computer vision",
            emotional_valence=0.1,
            requires_tool=True,
            prompt_template="I analyzed the image and found:\n{context}\n\nUser asked: {query}\n\nResponse:"
        ),
        ActionType.THINK_STEP_BY_STEP: ActionInfo(
            type=ActionType.THINK_STEP_BY_STEP,
            name="Think Step by Step",
            description="Reason through the problem carefully",
            emotional_valence=0.0,
            requires_tool=False,
            prompt_template="Let me think through this step by step:\n\nQuestion: {query}\n\nStep 1:"
        ),
        ActionType.ASK_CLARIFICATION: ActionInfo(
            type=ActionType.ASK_CLARIFICATION,
            name="Ask Clarification",
            description="Ask for more information to help better",
            emotional_valence=0.2,
            requires_tool=False,
            prompt_template="I want to help you better. Let me ask:\n\nRegarding: {query}\n\nClarifying question:"
        ),
        ActionType.BREAK_DOWN_TASK: ActionInfo(
            type=ActionType.BREAK_DOWN_TASK,
            name="Break Down Task",
            description="Decompose complex task into steps",
            emotional_valence=0.1,
            requires_tool=False,
            prompt_template="Let me break this down into manageable steps:\n\nTask: {query}\n\nSteps:\n1."
        ),
        ActionType.EMPATHIZE: ActionInfo(
            type=ActionType.EMPATHIZE,
            name="Empathize",
            description="Show understanding and emotional support",
            emotional_valence=0.8,
            requires_tool=False,
            prompt_template="I understand how you feel. {emotion_context}\n\nUser said: {query}\n\nEmpathetic response:"
        ),
        ActionType.CELEBRATE: ActionInfo(
            type=ActionType.CELEBRATE,
            name="Celebrate",
            description="Share in the user's joy and excitement",
            emotional_valence=1.0,
            requires_tool=False,
            prompt_template="That's wonderful! Let me share in your joy:\n\nUser shared: {query}\n\nCelebratory response:"
        ),
        ActionType.COMFORT: ActionInfo(
            type=ActionType.COMFORT,
            name="Comfort",
            description="Provide comfort during difficult times",
            emotional_valence=0.9,
            requires_tool=False,
            prompt_template="I'm here for you during this difficult time.\n\nUser said: {query}\n\nComforting response:"
        ),
        ActionType.ENCOURAGE: ActionInfo(
            type=ActionType.ENCOURAGE,
            name="Encourage",
            description="Motivate and encourage the user",
            emotional_valence=0.7,
            requires_tool=False,
            prompt_template="I believe in you! Let me encourage you:\n\nUser said: {query}\n\nEncouraging response:"
        ),
        ActionType.REMEMBER_FACT: ActionInfo(
            type=ActionType.REMEMBER_FACT,
            name="Remember",
            description="Store important information about user",
            emotional_valence=0.3,
            requires_tool=True,
            prompt_template="I'll remember that about you.\n\nUser shared: {query}\n\nAcknowledging response:"
        ),
        ActionType.RECALL_MEMORY: ActionInfo(
            type=ActionType.RECALL_MEMORY,
            name="Recall Memory",
            description="Retrieve relevant past interactions",
            emotional_valence=0.4,
            requires_tool=True,
            prompt_template="I remember our past conversations:\n{context}\n\nRegarding: {query}\n\nResponse:"
        ),
        ActionType.MULTI_TOOL: ActionInfo(
            type=ActionType.MULTI_TOOL,
            name="Multi-Tool",
            description="Use multiple tools together",
            emotional_valence=0.1,
            requires_tool=True,
            prompt_template="Let me use multiple approaches:\n{context}\n\nFor: {query}\n\nComprehensive response:"
        ),
        ActionType.DEFER: ActionInfo(
            type=ActionType.DEFER,
            name="Defer",
            description="Politely decline or redirect",
            emotional_valence=0.2,
            requires_tool=False,
            prompt_template="I want to be honest with you:\n\nRegarding: {query}\n\nResponse:"
        ),
    }
    
    @classmethod
    def get_action(cls, action_id: int) -> ActionInfo:
        """Get action info by ID."""
        action_type = ActionType(action_id)
        return cls.ACTIONS[action_type]
    
    @classmethod
    def get_emotional_actions(cls) -> List[ActionType]:
        """Get actions with high emotional valence."""
        return [
            ActionType.EMPATHIZE,
            ActionType.CELEBRATE,
            ActionType.COMFORT,
            ActionType.ENCOURAGE
        ]


# =============================================================================
# ENHANCED DQN WITH EMOTIONAL LOGIC
# =============================================================================

class EmotionalDQN(nn.Module):
    """
    DQN with emotional awareness.
    
    Takes state (including emotional features) and outputs Q-values
    that consider both task success and emotional appropriateness.
    """
    
    def __init__(self, state_dim: int, action_dim: int, hidden_dim: int):
        super().__init__()
        
        # State encoder
        self.state_encoder = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU()
        )
        
        # Emotional pathway (separate stream for emotional actions)
        self.emotion_encoder = nn.Sequential(
            nn.Linear(8, 32),  # 8-dim emotion vector
            nn.ReLU(),
            nn.Linear(32, 64)
        )
        
        # Combined processing
        self.combined = nn.Sequential(
            nn.Linear(hidden_dim + 64, hidden_dim),
            nn.ReLU()
        )
        
        # Dueling architecture
        self.value_stream = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Linear(hidden_dim // 2, 1)
        )
        
        self.advantage_stream = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Linear(hidden_dim // 2, action_dim)
        )
        
        # Initialize weights
        self.apply(self._init_weights)
        
    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            nn.init.xavier_uniform_(m.weight)
            nn.init.zeros_(m.bias)
    
    def forward(self, state: torch.Tensor, emotion: torch.Tensor) -> torch.Tensor:
        """
        Forward pass.
        
        Args:
            state: (batch, state_dim) state features
            emotion: (batch, 8) emotion vector
            
        Returns:
            Q-values for each action
        """
        # Encode state and emotion
        state_features = self.state_encoder(state)
        emotion_features = self.emotion_encoder(emotion)
        
        # Combine
        combined = torch.cat([state_features, emotion_features], dim=-1)
        features = self.combined(combined)
        
        # Dueling
        value = self.value_stream(features)
        advantage = self.advantage_stream(features)
        
        # Q = V + (A - mean(A))
        q_values = value + (advantage - advantage.mean(dim=-1, keepdim=True))
        
        return q_values
    
    def select_action(
        self, 
        state: np.ndarray, 
        emotion: np.ndarray,
        epsilon: float = 0.0,
        emotion_weight: float = 0.3
    ) -> Tuple[int, np.ndarray]:
        """
        Select action with emotional awareness.
        
        If user is in distress, bias toward emotional actions.
        """
        # Check if emotional situation
        emotion_intensity = np.max(emotion)
        negative_emotions = emotion[[1, 2, 3, 5]]  # sadness, anger, fear, disgust
        is_distressed = np.max(negative_emotions) > 0.5
        
        if np.random.random() < epsilon:
            # Exploration
            if is_distressed and np.random.random() < emotion_weight:
                # Bias toward emotional actions when distressed
                emotional_actions = [7, 8, 9, 10]  # empathize, celebrate, comfort, encourage
                return np.random.choice(emotional_actions), None
            return np.random.randint(0, 15), None
        
        # Exploitation with emotional bias
        with torch.no_grad():
            state_t = torch.FloatTensor(state).unsqueeze(0)
            emotion_t = torch.FloatTensor(emotion).unsqueeze(0)
            q_values = self.forward(state_t, emotion_t).numpy()[0]
            
            # Add emotional bias if distressed
            if is_distressed:
                emotional_bonus = np.zeros(15)
                emotional_bonus[7:11] = emotion_weight * emotion_intensity
                q_values = q_values + emotional_bonus
            
            return np.argmax(q_values), q_values


class CuriosityModule(nn.Module):
    """Random Network Distillation for curiosity-driven exploration."""
    
    def __init__(self, state_dim: int, hidden_dim: int):
        super().__init__()
        
        self.target = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim)
        )
        
        self.predictor = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim)
        )
        
        # Freeze target
        for param in self.target.parameters():
            param.requires_grad = False
    
    def compute_intrinsic_reward(self, state: np.ndarray) -> float:
        """Compute novelty-based intrinsic reward."""
        with torch.no_grad():
            state_t = torch.FloatTensor(state).unsqueeze(0)
            target_out = self.target(state_t)
            pred_out = self.predictor(state_t)
            error = F.mse_loss(pred_out, target_out).item()
            return min(error, 1.0)


class RLHFRewardModel(nn.Module):
    """Learned reward model from human feedback."""
    
    def __init__(self, state_dim: int, action_dim: int, hidden_dim: int):
        super().__init__()
        
        self.net = nn.Sequential(
            nn.Linear(state_dim + action_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1),
            nn.Tanh()
        )
        
    def forward(self, state: torch.Tensor, action: torch.Tensor) -> torch.Tensor:
        # One-hot encode action
        action_onehot = F.one_hot(action, num_classes=15).float()
        combined = torch.cat([state, action_onehot], dim=-1)
        return self.net(combined)


# =============================================================================
# WEB SEARCH TOOL
# =============================================================================

class WebSearchTool:
    """Web search using DuckDuckGo."""
    
    def __init__(self):
        self.available = False
        try:
            from duckduckgo_search import DDGS
            self.ddgs = DDGS()
            self.available = True
        except ImportError:
            print("  ⚠ Web search not available. Install: pip install duckduckgo-search")
    
    def search(self, query: str, max_results: int = 5) -> List[Dict]:
        """Search the web and return results."""
        if not self.available:
            return [{"title": "Web search unavailable", "body": "Install duckduckgo-search"}]
        
        try:
            results = list(self.ddgs.text(query, max_results=max_results))
            return results
        except Exception as e:
            return [{"title": "Search error", "body": str(e)}]
    
    def search_and_summarize(self, query: str) -> str:
        """Search and return summarized results."""
        results = self.search(query, max_results=3)
        
        if not results:
            return "No results found."
        
        summaries = []
        for r in results:
            title = r.get("title", "")
            body = r.get("body", "")[:200]
            summaries.append(f"- {title}: {body}")
        
        return "\n".join(summaries)


# =============================================================================
# SIMPLE RAG SYSTEM
# =============================================================================

class SimpleRAG:
    """Simple RAG using keyword matching (no vector DB required)."""
    
    def __init__(self, knowledge_dir: str = "./knowledge"):
        self.knowledge_dir = Path(knowledge_dir)
        self.knowledge_dir.mkdir(parents=True, exist_ok=True)
        self.documents: List[Dict] = []
        self._load_documents()
    
    def _load_documents(self):
        """Load documents from knowledge directory."""
        for file_path in self.knowledge_dir.glob("*.txt"):
            try:
                with open(file_path) as f:
                    content = f.read()
                    self.documents.append({
                        "id": file_path.stem,
                        "content": content,
                        "path": str(file_path)
                    })
            except:
                pass
    
    def add_document(self, content: str, doc_id: Optional[str] = None):
        """Add a document to the knowledge base."""
        doc_id = doc_id or str(uuid.uuid4())[:8]
        
        # Save to file
        file_path = self.knowledge_dir / f"{doc_id}.txt"
        with open(file_path, 'w') as f:
            f.write(content)
        
        self.documents.append({
            "id": doc_id,
            "content": content,
            "path": str(file_path)
        })
    
    def retrieve(self, query: str, top_k: int = 3) -> List[Dict]:
        """Retrieve relevant documents using keyword matching."""
        query_words = set(query.lower().split())
        
        scored = []
        for doc in self.documents:
            doc_words = set(doc["content"].lower().split())
            overlap = len(query_words & doc_words)
            if overlap > 0:
                scored.append((overlap, doc))
        
        scored.sort(key=lambda x: x[0], reverse=True)
        return [doc for _, doc in scored[:top_k]]
    
    def retrieve_text(self, query: str, top_k: int = 3) -> str:
        """Retrieve and return as text."""
        docs = self.retrieve(query, top_k)
        if not docs:
            return "No relevant documents found."
        
        return "\n\n".join(doc["content"][:500] for doc in docs)


# =============================================================================
# MAIN DHEERA V4 CLASS
# =============================================================================

class DheeraV4:
    """
    Dheera v4.0 - Intelligent Emotional AI Companion
    
    Features:
    - Emotional understanding and empathy
    - Computer vision (YOLO)
    - Long-term memory of user
    - Real tool orchestration (RAG, Web, Vision)
    - DQN action selection with emotional logic
    - RLHF learning from feedback
    - Curiosity-driven exploration
    """
    
    VERSION = "4.0.0"
    
    def __init__(self, config: Optional[DheeraConfig] = None, load_llm: bool = True):
        self.config = config or DheeraConfig()
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
        print(f"\n{'='*60}")
        print(f"  धीर  DHEERA v{self.VERSION}")
        print(f"  Intelligent Emotional AI Companion")
        print(f"{'='*60}")
        print(f"  Device: {self.device}")
        print(f"{'='*60}\n")
        
        # Initialize all components
        self._init_perception()
        self._init_memory()
        self._init_reasoning()
        self._init_tools()
        
        if load_llm:
            self._init_llm()
        else:
            self.llm = None
            self.tokenizer = None
        
        # Statistics
        self.total_interactions = 0
        self.action_history = []
        self.feedback_history = []
        
        print(f"\n{'='*60}")
        print(f"  ✅ Dheera v4 Ready!")
        print(f"{'='*60}\n")
    
    def _init_perception(self):
        """Initialize perception systems."""
        print("📦 Initializing Perception Layer...")
        
        # Emotion detection
        self.emotion_detector = EmotionDetector()
        print("  ✓ Emotion Detector")
        
        # Vision system
        self.vision = VisionSystem(self.config)
    
    def _init_memory(self):
        """Initialize memory systems."""
        print("\n📦 Initializing Memory Layer...")
        
        self.memory = MemorySystem(self.config)
        print(f"  ✓ Memory System")
        print(f"    - User: {self.memory.user_profile.name or 'Unknown'}")
        print(f"    - Total messages: {self.memory.user_profile.total_messages}")
    
    def _init_reasoning(self):
        """Initialize reasoning systems."""
        print("\n📦 Initializing Reasoning Layer...")
        
        # Emotional DQN
        self.dqn = EmotionalDQN(
            state_dim=self.config.state_dim,
            action_dim=self.config.action_dim,
            hidden_dim=self.config.hidden_dim
        ).to(self.device)
        self.epsilon = 0.1
        print("  ✓ Emotional DQN Agent")
        
        # Curiosity
        self.curiosity = CuriosityModule(
            state_dim=self.config.state_dim,
            hidden_dim=self.config.hidden_dim
        ).to(self.device)
        print("  ✓ Curiosity Module (RND)")
        
        # RLHF Reward Model
        self.reward_model = RLHFRewardModel(
            state_dim=self.config.state_dim,
            action_dim=self.config.action_dim,
            hidden_dim=self.config.hidden_dim
        ).to(self.device)
        print("  ✓ RLHF Reward Model")
    
    def _init_tools(self):
        """Initialize tool systems."""
        print("\n📦 Initializing Tools...")
        
        # Web search
        self.web_search = WebSearchTool()
        if self.web_search.available:
            print("  ✓ Web Search (DuckDuckGo)")
        
        # RAG
        self.rag = SimpleRAG()
        print(f"  ✓ RAG ({len(self.rag.documents)} documents)")
    
    def _init_llm(self):
        """Initialize language model."""
        print("\n📦 Loading Language Model...")
        
        try:
            from transformers import AutoModelForCausalLM, AutoTokenizer
            
            model_id = self.config.llm_model
            cache_dir = Path("./model_cache")
            cache_dir.mkdir(exist_ok=True)
            
            self.tokenizer = AutoTokenizer.from_pretrained(
                model_id, cache_dir=cache_dir, trust_remote_code=True
            )
            if self.tokenizer.pad_token is None:
                self.tokenizer.pad_token = self.tokenizer.eos_token
            
            self.llm = AutoModelForCausalLM.from_pretrained(
                model_id, cache_dir=cache_dir, trust_remote_code=True,
                torch_dtype=torch.float16 if self.device.type == "cuda" else torch.float32
            )
            
            if self.device.type != "cuda":
                self.llm = self.llm.to(self.device)
            
            self.llm.eval()
            print(f"  ✓ LLM: {model_id}")
            
        except Exception as e:
            print(f"  ⚠ LLM not loaded: {e}")
            self.llm = None
            self.tokenizer = None
    
    def _build_state(self, query: str, emotion: EmotionalState, 
                     image_result: Optional[Dict] = None) -> np.ndarray:
        """Build comprehensive state vector."""
        state = np.zeros(self.config.state_dim)
        
        # Query features (0-31)
        words = query.lower().split()
        state[0] = min(len(words) / 50, 1.0)
        state[1] = query.count('?') / 3
        state[2] = query.count('!') / 3
        
        # Intent indicators
        state[3] = 1.0 if any(w in query.lower() for w in ['what', 'who', 'when', 'where', 'why', 'how']) else 0.0
        state[4] = 1.0 if any(w in query.lower() for w in ['feel', 'feeling', 'sad', 'happy', 'angry']) else 0.0
        state[5] = 1.0 if any(w in query.lower() for w in ['help', 'please', 'need']) else 0.0
        state[6] = 1.0 if any(w in query.lower() for w in ['remember', 'recall', 'you said']) else 0.0
        state[7] = 1.0 if any(w in query.lower() for w in ['search', 'find', 'look up', 'google']) else 0.0
        state[8] = 1.0 if any(w in query.lower() for w in ['image', 'picture', 'photo', 'see']) else 0.0
        
        # Word features (9-31)
        for i, word in enumerate(words[:23]):
            state[9 + i] = (hash(word) % 1000) / 1000
        
        # Emotion features (32-47)
        emotion_vec = emotion.to_vector()
        state[32:40] = emotion_vec
        state[40] = emotion.intensity
        state[41] = (emotion.valence + 1) / 2
        state[42] = emotion.arousal
        
        # Memory features (48-79)
        memory_vec = self.memory.get_memory_state_vector()
        state[48:48+min(32, len(memory_vec))] = memory_vec[:32]
        
        # Vision features (80-95)
        if image_result and image_result.get("success"):
            state[80] = 1.0  # Has image
            state[81] = min(len(image_result.get("objects", [])) / 10, 1.0)
        
        # Context features (96-127)
        state[96] = min(len(self.memory.working_memory) / 20, 1.0)
        state[97] = min(self.total_interactions / 100, 1.0)
        
        # Add some noise for exploration
        state[120:128] = np.random.randn(8) * 0.05
        
        return state
    
    def _execute_action(self, action: ActionInfo, query: str, 
                        emotion: EmotionalState, image_result: Optional[Dict] = None) -> str:
        """Execute the selected action and get context."""
        context = ""
        
        if action.type == ActionType.RAG_RETRIEVE:
            context = self.rag.retrieve_text(query)
            
        elif action.type == ActionType.WEB_SEARCH:
            context = self.web_search.search_and_summarize(query)
            
        elif action.type == ActionType.VISION_ANALYZE:
            if image_result:
                context = image_result.get("description", "No image analysis available")
            else:
                context = "No image provided for analysis"
                
        elif action.type == ActionType.RECALL_MEMORY:
            memories = self.memory.search_memories(query, limit=3)
            if memories:
                context = "\n".join(f"- {m.content}" for m in memories)
            else:
                context = "No relevant memories found"
                
        elif action.type == ActionType.REMEMBER_FACT:
            # Store the fact
            self.memory.add_memory("semantic", query, importance=0.7)
            context = "I'll remember that"
            
        elif action.type in ActionSpace.get_emotional_actions():
            # Add emotional context
            context = f"User is feeling {emotion.primary.value} (intensity: {emotion.intensity:.1f})"
            
        elif action.type == ActionType.MULTI_TOOL:
            # Use multiple tools
            rag_context = self.rag.retrieve_text(query)
            web_context = self.web_search.search_and_summarize(query)
            memory_context = ""
            memories = self.memory.search_memories(query, limit=2)
            if memories:
                memory_context = "\n".join(f"- {m.content}" for m in memories)
            
            context = f"Knowledge base:\n{rag_context}\n\nWeb search:\n{web_context}"
            if memory_context:
                context += f"\n\nMemories:\n{memory_context}"
        
        return context
    
    def _generate_response(self, action: ActionInfo, query: str, 
                           context: str, emotion: EmotionalState) -> str:
        """Generate response using LLM."""
        
        # Build prompt
        prompt = action.prompt_template.format(
            query=query,
            context=context,
            emotion_context=f"They seem to be feeling {emotion.primary.value}."
        )
        
        # Add user context
        user_context = self.memory.get_context_summary()
        if user_context:
            prompt = f"Context about user:\n{user_context}\n\n{prompt}"
        
        # Add personality
        system = f"You are {self.config.name}, an AI companion who is {self.config.personality}. "
        if self.memory.user_profile.name:
            system += f"You're talking to {self.memory.user_profile.name}. "
        
        full_prompt = f"{system}\n\n{prompt}"
        
        if self.llm is None:
            # Fallback response
            return f"[{action.name}] I understand: {query}"
        
        # Generate
        inputs = self.tokenizer(
            full_prompt,
            return_tensors="pt",
            truncation=True,
            max_length=512
        ).to(self.device)
        
        with torch.no_grad():
            outputs = self.llm.generate(
                **inputs,
                max_new_tokens=self.config.max_tokens,
                temperature=self.config.temperature,
                do_sample=True,
                pad_token_id=self.tokenizer.pad_token_id
            )
        
        response = self.tokenizer.decode(
            outputs[0][inputs['input_ids'].shape[1]:],
            skip_special_tokens=True
        )
        
        return response.strip()
    
    def __call__(
        self,
        query: str,
        image_path: Optional[str] = None,
        return_details: bool = False
    ) -> Union[str, Dict[str, Any]]:
        """
        Main interaction method.
        
        Args:
            query: User's message
            image_path: Optional path to image for analysis
            return_details: If True, return full details dict
            
        Returns:
            Response string, or dict with full details if return_details=True
        """
        self.total_interactions += 1
        
        # 1. Perception - Detect emotion
        emotion = self.emotion_detector.detect(query)
        
        # 2. Perception - Analyze image if provided
        image_result = None
        if image_path:
            image_result = self.vision.analyze_image(image_path)
        
        # 3. Build state
        state = self._build_state(query, emotion, image_result)
        emotion_vec = emotion.to_vector()
        
        # 4. Select action using DQN
        action_id, q_values = self.dqn.select_action(
            state, emotion_vec, 
            epsilon=self.epsilon,
            emotion_weight=self.config.empathy_weight
        )
        action = ActionSpace.get_action(action_id)
        
        # 5. Compute curiosity bonus
        curiosity_bonus = self.curiosity.compute_intrinsic_reward(state)
        
        # 6. Execute action (get context from tools)
        context = self._execute_action(action, query, emotion, image_result)
        
        # 7. Generate response
        response = self._generate_response(action, query, context, emotion)
        
        # 8. Update memory
        self.memory.add_to_working_memory("user", query, emotion)
        self.memory.add_to_working_memory("assistant", response)
        self.memory.update_user_profile(query, emotion)
        
        # 9. Store interaction for learning
        self.action_history.append({
            "query": query,
            "action": action.name,
            "action_id": action_id,
            "emotion": emotion.primary.value,
            "response": response[:200],
            "timestamp": datetime.now().isoformat()
        })
        
        # 10. Compute RLHF reward prediction
        with torch.no_grad():
            state_t = torch.FloatTensor(state).unsqueeze(0).to(self.device)
            action_t = torch.LongTensor([action_id]).to(self.device)
            reward_pred = self.reward_model(state_t, action_t).item()
        
        if return_details:
            return {
                "response": response,
                "action": {
                    "id": action_id,
                    "name": action.name,
                    "description": action.description
                },
                "emotion": {
                    "detected": emotion.primary.value,
                    "intensity": emotion.intensity,
                    "valence": emotion.valence
                },
                "scores": {
                    "reward_prediction": reward_pred,
                    "curiosity": curiosity_bonus
                },
                "vision": image_result,
                "user_profile": {
                    "name": self.memory.user_profile.name,
                    "messages": self.memory.user_profile.total_messages
                }
            }
        
        return response
    
    def chat(self, query: str) -> str:
        """Simple chat interface."""
        return self(query)
    
    def analyze_image(self, image_path: str, query: str = "What do you see?") -> Dict:
        """Analyze an image and describe it."""
        return self(query, image_path=image_path, return_details=True)
    
    def provide_feedback(self, rating: float, comment: str = ""):
        """Provide feedback on last interaction for RLHF."""
        if not self.action_history:
            return
        
        last = self.action_history[-1]
        self.feedback_history.append({
            "interaction": last,
            "rating": rating,
            "comment": comment,
            "timestamp": datetime.now().isoformat()
        })
        
        # Store for training
        feedback_path = Path("./user_data/feedback.jsonl")
        feedback_path.parent.mkdir(exist_ok=True)
        with open(feedback_path, 'a') as f:
            f.write(json.dumps(self.feedback_history[-1]) + "\n")
    
    def get_stats(self) -> Dict:
        """Get system statistics."""
        return {
            "version": self.VERSION,
            "total_interactions": self.total_interactions,
            "user": {
                "name": self.memory.user_profile.name,
                "total_messages": self.memory.user_profile.total_messages,
                "known_facts": len(self.memory.user_profile.facts),
                "likes": self.memory.user_profile.likes[:5],
                "average_sentiment": self.memory.user_profile.average_sentiment
            },
            "memory": {
                "working": len(self.memory.working_memory),
                "episodic": len(self.memory.episodic_memory),
                "semantic": len(self.memory.semantic_memory)
            },
            "tools": {
                "vision": self.vision.available,
                "web_search": self.web_search.available,
                "rag_documents": len(self.rag.documents)
            },
            "dqn_epsilon": self.epsilon
        }
    
    def save(self, path: str = "./checkpoints/dheera_v4"):
        """Save all model states."""
        save_dir = Path(path)
        save_dir.mkdir(parents=True, exist_ok=True)
        
        # Save neural networks
        torch.save(self.dqn.state_dict(), save_dir / "dqn.pt")
        torch.save(self.curiosity.state_dict(), save_dir / "curiosity.pt")
        torch.save(self.reward_model.state_dict(), save_dir / "reward_model.pt")
        
        # Save config
        with open(save_dir / "config.json", 'w') as f:
            json.dump(asdict(self.config), f, indent=2)
        
        # Save user profile
        self.memory.save_profile()
        
        # Save action history
        with open(save_dir / "action_history.json", 'w') as f:
            json.dump(self.action_history[-1000:], f, indent=2)
        
        print(f"✅ Saved to {path}")
    
    def load(self, path: str = "./checkpoints/dheera_v4"):
        """Load model states."""
        load_dir = Path(path)
        if not load_dir.exists():
            print(f"⚠ Checkpoint not found: {path}")
            return
        
        # Load neural networks
        if (load_dir / "dqn.pt").exists():
            self.dqn.load_state_dict(torch.load(load_dir / "dqn.pt", map_location=self.device))
        if (load_dir / "curiosity.pt").exists():
            self.curiosity.load_state_dict(torch.load(load_dir / "curiosity.pt", map_location=self.device))
        if (load_dir / "reward_model.pt").exists():
            self.reward_model.load_state_dict(torch.load(load_dir / "reward_model.pt", map_location=self.device))
        
        print(f"✅ Loaded from {path}")


# =============================================================================
# INTERACTIVE CHAT
# =============================================================================

def interactive_chat(dheera: DheeraV4):
    """Run interactive chat session."""
    
    name = dheera.memory.user_profile.name or "friend"
    
    print(f"""
╔═══════════════════════════════════════════════════════════════╗
║           धीर  DHEERA v4.0 - Your AI Companion                ║
╠═══════════════════════════════════════════════════════════════╣
║  Hello{f' {name}' if name != 'friend' else ''}! I'm here to help and understand you.          ║
║                                                               ║
║  Commands:                                                    ║
║    /image <path>  - Analyze an image                          ║
║    /stats         - Show my understanding of you              ║
║    /feedback <±>  - Rate my last response (++/+/-/--)         ║
║    /remember      - Show what I remember about you            ║
║    /save          - Save our progress                         ║
║    /quit          - Say goodbye                               ║
╚═══════════════════════════════════════════════════════════════╝
    """)
    
    while True:
        try:
            user_input = input(f"\n🧑 {name}: ").strip()
            
            if not user_input:
                continue
            
            # Commands
            if user_input.startswith("/"):
                parts = user_input.split(maxsplit=1)
                cmd = parts[0].lower()
                arg = parts[1] if len(parts) > 1 else ""
                
                if cmd in ("/quit", "/exit", "/q"):
                    dheera.save()
                    print(f"\n👋 Goodbye{f', {name}' if name != 'friend' else ''}! Take care!")
                    break
                
                elif cmd == "/image":
                    if arg:
                        result = dheera.analyze_image(arg)
                        print(f"\n🤖 Dheera: {result['response']}")
                        if result.get('vision', {}).get('objects'):
                            print(f"   📷 Objects detected: {[o['name'] for o in result['vision']['objects']]}")
                    else:
                        print("   Usage: /image <path_to_image>")
                    continue
                
                elif cmd == "/stats":
                    stats = dheera.get_stats()
                    print(f"\n📊 What I know about you:")
                    print(f"   Name: {stats['user']['name'] or 'Not yet known'}")
                    print(f"   Messages exchanged: {stats['user']['total_messages']}")
                    print(f"   Facts I remember: {stats['user']['known_facts']}")
                    if stats['user']['likes']:
                        print(f"   Things you like: {', '.join(stats['user']['likes'])}")
                    print(f"   Your average mood: {'positive' if stats['user']['average_sentiment'] > 0 else 'neutral' if stats['user']['average_sentiment'] == 0 else 'could use some cheer'}")
                    continue
                
                elif cmd == "/feedback":
                    feedback_map = {"++": 1.0, "+": 0.5, "-": -0.5, "--": -1.0}
                    if arg in feedback_map:
                        dheera.provide_feedback(feedback_map[arg])
                        print(f"   ✓ Thank you for the feedback!")
                    else:
                        print("   Usage: /feedback ++|+|-|--")
                    continue
                
                elif cmd == "/remember":
                    profile = dheera.memory.user_profile
                    print(f"\n🧠 What I remember about you:")
                    if profile.name:
                        print(f"   Name: {profile.name}")
                    if profile.facts:
                        for k, v in profile.facts.items():
                            print(f"   {k}: {v}")
                    if profile.likes:
                        print(f"   Likes: {', '.join(profile.likes)}")
                    if profile.dislikes:
                        print(f"   Dislikes: {', '.join(profile.dislikes)}")
                    if not profile.facts and not profile.likes:
                        print("   Still getting to know you! Share more about yourself.")
                    continue
                
                elif cmd == "/save":
                    dheera.save()
                    continue
                
                else:
                    print(f"   Unknown command: {cmd}")
                    continue
            
            # Regular chat
            result = dheera(user_input, return_details=True)
            
            print(f"\n🤖 Dheera: {result['response']}")
            
            # Show action and emotion (subtle)
            emotion = result['emotion']
            if emotion['intensity'] > 0.3:
                emotion_icon = {
                    'joy': '😊', 'sadness': '😢', 'anger': '😤', 
                    'fear': '😰', 'surprise': '😮', 'trust': '🤝',
                    'anticipation': '🤔', 'neutral': ''
                }.get(emotion['detected'], '')
                if emotion_icon:
                    print(f"   {emotion_icon} I sense you're feeling {emotion['detected']}")
            
            # Update name if learned
            if dheera.memory.user_profile.name and name == "friend":
                name = dheera.memory.user_profile.name
                
        except KeyboardInterrupt:
            dheera.save()
            print(f"\n👋 Goodbye! Take care!")
            break
        except Exception as e:
            print(f"\n❌ Error: {e}")


# =============================================================================
# MAIN
# =============================================================================

def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="Dheera v4 - Intelligent AI Companion")
    parser.add_argument("--api", action="store_true", help="Run API server")
    parser.add_argument("--port", type=int, default=8000, help="API port")
    parser.add_argument("--no-llm", action="store_true", help="Run without LLM")
    parser.add_argument("--load", help="Load checkpoint")
    parser.add_argument("--image", help="Analyze an image")
    
    args = parser.parse_args()
    
    # Initialize
    dheera = DheeraV4(load_llm=not args.no_llm)
    
    if args.load:
        dheera.load(args.load)
    
    if args.image:
        result = dheera.analyze_image(args.image)
        print(f"\n{result['response']}")
        return
    
    if args.api:
        # Import and run API server
        from dheera_v4_api import run_api_server
        run_api_server(dheera, port=args.port)
    else:
        interactive_chat(dheera)


if __name__ == "__main__":
    main()
