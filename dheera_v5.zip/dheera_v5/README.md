# 🧠 Dheera v5.0 - Super Intelligence

**धीर** (Sanskrit: Courageous, Wise, Patient)

A **continuously learning** AI companion that combines:
- 🌈 **Rainbow DQN** (all 6 improvements)
- 💭 **Emotional Intelligence**
- 👁️ **Computer Vision** (YOLO)
- 🧠 **Long-term Memory**
- 🔍 **RAG + Web Search**
- 📚 **RLHF** (learns from your feedback)
- 🔄 **Dual LLM Support** (Ollama + HuggingFace)

**This AI gets smarter with every conversation.**

---

## 🌟 What Makes Dheera v5 Special?

| Feature | Basic Chatbot | Dheera v5 |
|---------|---------------|-----------|
| Remembers you | ❌ | ✅ Persistent memory |
| Understands emotions | ❌ | ✅ 8 emotions detected |
| Sees images | ❌ | ✅ YOLO object detection |
| Learns from feedback | ❌ | ✅ Rainbow DQN + RLHF |
| Chooses strategy | ❌ | ✅ 15 actions (DQN) |
| Improves over time | ❌ | ✅ Continuous learning |

---

## 🏗️ Architecture

```
╔══════════════════════════════════════════════════════════════════╗
║                     DHEERA v5 ARCHITECTURE                        ║
╠══════════════════════════════════════════════════════════════════╣
║                                                                  ║
║  INPUT: Text / Image                                             ║
║          │                                                       ║
║          ▼                                                       ║
║  ┌────────────────────────────────────────────────────────┐      ║
║  │              PERCEPTION LAYER                          │      ║
║  │  [Text Parser] [Emotion Detector] [YOLO Vision]       │      ║
║  └────────────────────────┬───────────────────────────────┘      ║
║                           ▼                                      ║
║  ┌────────────────────────────────────────────────────────┐      ║
║  │              MEMORY LAYER                              │      ║
║  │  [Working] [Episodic] [Semantic] [User Profile]       │      ║
║  │                    SQLite Database                     │      ║
║  └────────────────────────┬───────────────────────────────┘      ║
║                           ▼                                      ║
║  ┌────────────────────────────────────────────────────────┐      ║
║  │              REASONING LAYER                           │      ║
║  │                                                        │      ║
║  │   State (128-dim) ──► Rainbow DQN ──► Action          │      ║
║  │         │                  │             │             │      ║
║  │         │            ┌─────┴─────┐       │             │      ║
║  │         │            │           │       │             │      ║
║  │         │       Curiosity    RLHF       │             │      ║
║  │         │         (RND)     Reward      │             │      ║
║  │         │            │           │       │             │      ║
║  │         └────────────┴─────┬─────┴───────┘             │      ║
║  │                            │                           │      ║
║  │  Rainbow DQN Components:                               │      ║
║  │  ✓ Double DQN (reduce overestimation)                 │      ║
║  │  ✓ Dueling Networks (value + advantage)               │      ║
║  │  ✓ Noisy Networks (exploration)                       │      ║
║  │  ✓ Prioritized Experience Replay                      │      ║
║  │  ✓ N-step Returns (better credit)                     │      ║
║  │  ✓ Distributional RL (C51)                            │      ║
║  └────────────────────────┬───────────────────────────────┘      ║
║                           ▼                                      ║
║  ┌────────────────────────────────────────────────────────┐      ║
║  │              ACTION LAYER (15 Actions)                 │      ║
║  │                                                        │      ║
║  │  Information: [Direct] [RAG] [Web] [Vision]           │      ║
║  │  Reasoning:   [Think] [Clarify] [Break Down]          │      ║
║  │  Emotional:   [Empathize] [Comfort] [Celebrate]       │      ║
║  │  Memory:      [Remember] [Recall]                     │      ║
║  │  Meta:        [Multi-Tool] [Defer]                    │      ║
║  └────────────────────────┬───────────────────────────────┘      ║
║                           ▼                                      ║
║  ┌────────────────────────────────────────────────────────┐      ║
║  │              GENERATION LAYER                          │      ║
║  │                                                        │      ║
║  │    Ollama (phi3:mini)  OR  Transformers (TinyLlama)   │      ║
║  │                                                        │      ║
║  │    Context + Emotion + Personality = Response         │      ║
║  └────────────────────────────────────────────────────────┘      ║
║                           │                                      ║
║                           ▼                                      ║
║  OUTPUT: Response + Emotion + Action Info                        ║
║                           │                                      ║
║                           ▼                                      ║
║  ┌────────────────────────────────────────────────────────┐      ║
║  │              LEARNING LOOP                             │      ║
║  │                                                        │      ║
║  │  Interaction ──► Store Experience ──► Train DQN       │      ║
║  │       │                                    │           │      ║
║  │       └─── User Feedback ──► Train RLHF ──┘           │      ║
║  │                                                        │      ║
║  │  Every interaction makes Dheera smarter!              │      ║
║  └────────────────────────────────────────────────────────┘      ║
╚══════════════════════════════════════════════════════════════════╝
```

---

## 🚀 Quick Start

### Installation

```bash
# Clone/extract the package
cd dheera_v5

# Install dependencies
pip install torch transformers fastapi uvicorn ultralytics duckduckgo-search

# Or use requirements.txt
pip install -r requirements.txt
```

### Option 1: With Ollama (Recommended - Best Quality)

```bash
# Install Ollama from https://ollama.ai
ollama pull phi3:mini

# Run Dheera
python dheera.py --llm ollama
```

### Option 2: With HuggingFace Transformers

```bash
# No extra setup needed - models download automatically
python dheera.py --llm transformers
```

### Run Interactive Chat

```bash
python dheera.py
```

### Run API Server

```bash
python dheera.py --api --port 8000

# Or directly
python api_server.py --port 8000
```

---

## 📡 API Usage

### OpenAI-Compatible

```python
from openai import OpenAI

client = OpenAI(
    base_url="http://localhost:8000/v1",
    api_key="not-needed"
)

# Chat
response = client.chat.completions.create(
    model="dheera-v5",
    messages=[{"role": "user", "content": "I'm feeling stressed about work"}]
)

print(response.choices[0].message.content)
# Dheera detects stress and responds empathetically

# Access Dheera-specific info
print(response.dheera.emotion)   # {'primary': 'FEAR', 'intensity': 0.6}
print(response.dheera.action)    # {'name': 'Comfort', 'type': 'COMFORT'}
```

### Direct API Calls

```bash
# Chat
curl -X POST http://localhost:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "dheera-v5",
    "messages": [{"role": "user", "content": "Hello!"}]
  }'

# Analyze image
curl -X POST http://localhost:8000/v1/vision/analyze \
  -F "file=@photo.jpg" \
  -F "query=What do you see?"

# Provide feedback (helps Dheera learn)
curl -X POST http://localhost:8000/v1/feedback \
  -H "Content-Type: application/json" \
  -d '{"rating": 0.8, "comment": "Great response!"}'

# Trigger training
curl -X POST http://localhost:8000/v1/train \
  -H "Content-Type: application/json" \
  -d '{"steps": 10}'

# View statistics
curl http://localhost:8000/v1/stats
```

---

## 🌈 Rainbow DQN Explained

Dheera uses **Rainbow DQN**, which combines 6 major improvements:

| Improvement | What It Does | Why It Matters |
|-------------|--------------|----------------|
| **Double DQN** | Uses two networks to reduce overestimation | More accurate Q-values |
| **Dueling Networks** | Separates state value from action advantage | Better action selection |
| **Noisy Networks** | Learned exploration (no epsilon needed) | Smarter exploration |
| **PER** | Prioritized Experience Replay | Learns from important experiences |
| **N-step Returns** | Looks N steps ahead | Better credit assignment |
| **C51** | Distributional RL (51 atoms) | Captures uncertainty |

**Plus emotional awareness**: When you're distressed, Dheera biases toward empathetic actions!

---

## 💭 Emotional Intelligence

Dheera detects 8 emotions (Plutchik's wheel):

| Emotion | Detection | Dheera's Response |
|---------|-----------|-------------------|
| 😊 Joy | "happy", "excited", "love" | Celebrates with you |
| 😢 Sadness | "sad", "depressed", "lonely" | Offers comfort |
| 😠 Anger | "angry", "frustrated", "hate" | Validates and calms |
| 😰 Fear | "scared", "worried", "anxious" | Reassures |
| 😮 Surprise | "wow", "shocked" | Engages curiosity |
| 🤢 Disgust | "gross", "horrible" | Acknowledges |
| 🤝 Trust | "believe", "faith" | Reinforces |
| 🤔 Anticipation | "waiting", "hoping" | Builds excitement |

---

## 🎯 The 15 Actions

| ID | Action | When Used |
|----|--------|-----------|
| 0 | Direct Answer | Simple questions |
| 1 | RAG Retrieve | Knowledge base queries |
| 2 | Web Search | Current events, facts |
| 3 | Vision Analyze | Image analysis |
| 4 | Think Step by Step | Complex problems |
| 5 | Ask Clarification | Ambiguous requests |
| 6 | Break Down | Large tasks |
| 7 | Empathize | User shares feelings |
| 8 | Celebrate | User is happy |
| 9 | Comfort | User is distressed |
| 10 | Encourage | User needs motivation |
| 11 | Remember | Store user info |
| 12 | Recall | Retrieve memories |
| 13 | Multi-Tool | Complex queries |
| 14 | Defer | Can't help |

---

## 🔄 Continuous Learning

### How Dheera Learns

```
1. Every interaction:
   - State (query + emotion + context) → DQN → Action
   - Action → Tool → LLM → Response
   - Store experience in replay buffer
   - Train DQN every N interactions

2. User feedback:
   - You rate responses (++, +, -, --)
   - RLHF reward model learns your preferences
   - Better predictions = better action selection

3. Over time:
   - DQN learns which actions work best
   - RLHF learns what you like
   - Curiosity discovers new approaches
   - Dheera becomes YOUR AI companion
```

### Provide Feedback

In chat:
```
/feedback ++    # Excellent
/feedback +     # Good
/feedback -     # Not great
/feedback --    # Bad
```

Via API:
```python
requests.post("http://localhost:8000/v1/feedback", json={
    "rating": 0.8,
    "comment": "Very helpful!"
})
```

---

## 📁 File Structure

```
dheera_v5/
├── dheera.py           # Main system
├── api_server.py       # API server
├── requirements.txt    # Dependencies
├── README.md           # This file
│
├── core/
│   ├── __init__.py
│   └── rainbow_dqn.py  # Rainbow DQN implementation
│
├── data/
│   └── dheera.db       # SQLite database
│
├── knowledge/
│   └── *.txt           # RAG documents
│
├── checkpoints/
│   └── dheera_v5/
│       ├── rainbow_dqn.pt
│       ├── curiosity.pt
│       └── reward_model.pt
│
└── model_cache/        # Downloaded LLM models
```

---

## ⚙️ Configuration

```python
from dheera import DheeraV5, DheeraConfig

config = DheeraConfig(
    # LLM
    llm_provider="auto",  # "auto", "ollama", "transformers"
    ollama_model="phi3:mini",
    transformers_model="TinyLlama/TinyLlama-1.1B-Chat-v1.0",
    
    # Vision
    vision_enabled=True,
    yolo_model="yolov8n",
    
    # Learning
    learning_enabled=True,
    train_every_n=5,
    
    # Rainbow DQN
    n_atoms=51,
    n_steps=3,
    gamma=0.99,
    
    # Emotional
    empathy_weight=0.3
)

dheera = DheeraV5(config)
```

---

## 🆚 v3 vs v4 vs v5

| Feature | v3 | v4 | v5 |
|---------|----|----|-----|
| DQN Type | Basic | Emotional | **Rainbow** |
| LLM | Ollama only | HuggingFace only | **Both** |
| Database | Files | Memory | **SQLite** |
| Actions | 7 | 15 | **15** |
| Persistence | ❌ | Partial | **Full** |
| Learning | Manual | On interaction | **Continuous** |
| API | Basic | OpenAI-compat | **Full + WebSocket** |

---

## 🛠️ Troubleshooting

### Ollama not connecting
```bash
# Check if Ollama is running
curl http://localhost:11434/api/tags

# Start Ollama
ollama serve
```

### YOLO not working
```bash
pip install ultralytics opencv-python
```

### Out of memory
```bash
# Use smaller model
python dheera.py --llm transformers

# Or in config
config = DheeraConfig(transformers_model="distilgpt2")
```

### Response quality issues
- Use Ollama with phi3:mini (better quality)
- Provide more feedback to help learning
- Let it train longer

---

## 🔮 Roadmap

- [ ] Voice input/output
- [ ] Multi-turn planning
- [ ] Proactive check-ins
- [ ] Goal tracking
- [ ] Plugin system
- [ ] Cloud sync

---

## 📜 License

Apache 2.0

---

## 🙏 Credits

- Rainbow DQN: DeepMind
- RLHF: OpenAI/Anthropic
- RND Curiosity: OpenAI
- YOLO: Ultralytics
- Ollama: Ollama.ai
- Transformers: HuggingFace

---

**धीर - Courageous, Wise, Patient**

*An AI that learns to understand YOU.*
