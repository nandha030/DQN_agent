#!/usr/bin/env python3
"""
Rainbow DQN - Complete Implementation
=====================================

All 6 improvements from the Rainbow paper:
1. Double DQN - Reduces overestimation bias
2. Dueling Networks - Separates value and advantage
3. Noisy Networks - Exploration without epsilon-greedy
4. Prioritized Experience Replay - Focus on important experiences
5. N-step Returns - Better credit assignment
6. Distributional RL (C51) - Models full return distribution

Plus:
7. Emotional Awareness - Biases actions based on detected emotions
8. Curiosity Integration - Intrinsic rewards for exploration
"""

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Tuple, Optional, Dict, List
from collections import deque
import random
import math


# =============================================================================
# NOISY LINEAR LAYER
# =============================================================================

class NoisyLinear(nn.Module):
    """
    Noisy Linear Layer for exploration.
    Replaces epsilon-greedy with learned parametric noise.
    """
    
    def __init__(self, in_features: int, out_features: int, std_init: float = 0.5):
        super().__init__()
        
        self.in_features = in_features
        self.out_features = out_features
        self.std_init = std_init
        
        # Learnable parameters
        self.weight_mu = nn.Parameter(torch.empty(out_features, in_features))
        self.weight_sigma = nn.Parameter(torch.empty(out_features, in_features))
        self.bias_mu = nn.Parameter(torch.empty(out_features))
        self.bias_sigma = nn.Parameter(torch.empty(out_features))
        
        # Factorized noise buffers
        self.register_buffer('weight_epsilon', torch.empty(out_features, in_features))
        self.register_buffer('bias_epsilon', torch.empty(out_features))
        
        self.reset_parameters()
        self.reset_noise()
    
    def reset_parameters(self):
        """Initialize parameters."""
        mu_range = 1 / math.sqrt(self.in_features)
        self.weight_mu.data.uniform_(-mu_range, mu_range)
        self.weight_sigma.data.fill_(self.std_init / math.sqrt(self.in_features))
        self.bias_mu.data.uniform_(-mu_range, mu_range)
        self.bias_sigma.data.fill_(self.std_init / math.sqrt(self.out_features))
    
    def _scale_noise(self, size: int) -> torch.Tensor:
        """Generate factorized Gaussian noise."""
        x = torch.randn(size, device=self.weight_mu.device)
        return x.sign().mul_(x.abs().sqrt_())
    
    def reset_noise(self):
        """Resample noise for exploration."""
        epsilon_in = self._scale_noise(self.in_features)
        epsilon_out = self._scale_noise(self.out_features)
        self.weight_epsilon.copy_(epsilon_out.outer(epsilon_in))
        self.bias_epsilon.copy_(epsilon_out)
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.training:
            weight = self.weight_mu + self.weight_sigma * self.weight_epsilon
            bias = self.bias_mu + self.bias_sigma * self.bias_epsilon
        else:
            weight = self.weight_mu
            bias = self.bias_mu
        return F.linear(x, weight, bias)


# =============================================================================
# PRIORITIZED EXPERIENCE REPLAY
# =============================================================================

class SumTree:
    """
    Sum Tree for efficient prioritized sampling.
    Stores priorities in a binary tree for O(log n) sampling.
    """
    
    def __init__(self, capacity: int):
        self.capacity = capacity
        self.tree = np.zeros(2 * capacity - 1)
        self.data = np.zeros(capacity, dtype=object)
        self.write_idx = 0
        self.n_entries = 0
    
    def _propagate(self, idx: int, change: float):
        """Propagate priority change up the tree."""
        parent = (idx - 1) // 2
        self.tree[parent] += change
        if parent != 0:
            self._propagate(parent, change)
    
    def _retrieve(self, idx: int, s: float) -> int:
        """Find sample index for given cumulative sum."""
        left = 2 * idx + 1
        right = left + 1
        
        if left >= len(self.tree):
            return idx
        
        if s <= self.tree[left]:
            return self._retrieve(left, s)
        else:
            return self._retrieve(right, s - self.tree[left])
    
    @property
    def total(self) -> float:
        return self.tree[0]
    
    def add(self, priority: float, data):
        """Add experience with priority."""
        idx = self.write_idx + self.capacity - 1
        self.data[self.write_idx] = data
        self.update(idx, priority)
        
        self.write_idx = (self.write_idx + 1) % self.capacity
        self.n_entries = min(self.n_entries + 1, self.capacity)
    
    def update(self, idx: int, priority: float):
        """Update priority of existing experience."""
        change = priority - self.tree[idx]
        self.tree[idx] = priority
        self._propagate(idx, change)
    
    def get(self, s: float) -> Tuple[int, float, object]:
        """Sample experience by cumulative sum."""
        idx = self._retrieve(0, s)
        data_idx = idx - self.capacity + 1
        return idx, self.tree[idx], self.data[data_idx]


class PrioritizedReplayBuffer:
    """
    Prioritized Experience Replay Buffer.
    Samples important experiences more frequently.
    """
    
    def __init__(
        self, 
        capacity: int,
        alpha: float = 0.6,  # Priority exponent
        beta_start: float = 0.4,  # Initial importance sampling
        beta_frames: int = 100000  # Frames to anneal beta
    ):
        self.capacity = capacity
        self.alpha = alpha
        self.beta_start = beta_start
        self.beta_frames = beta_frames
        self.frame = 1
        
        self.tree = SumTree(capacity)
        self.max_priority = 1.0
        self.min_priority = 1e-6
    
    @property
    def beta(self) -> float:
        """Annealed importance sampling weight."""
        return min(1.0, self.beta_start + self.frame * (1.0 - self.beta_start) / self.beta_frames)
    
    def add(self, state, action, reward, next_state, done, emotion=None, extra=None):
        """Add experience with max priority."""
        experience = (state, action, reward, next_state, done, emotion, extra)
        priority = self.max_priority ** self.alpha
        self.tree.add(priority, experience)
    
    def sample(self, batch_size: int) -> Tuple:
        """Sample batch with priorities."""
        batch = []
        indices = []
        priorities = []
        segment = self.tree.total / batch_size
        
        for i in range(batch_size):
            a = segment * i
            b = segment * (i + 1)
            s = random.uniform(a, b)
            
            idx, priority, data = self.tree.get(s)
            if data is not None and data != 0:
                batch.append(data)
                indices.append(idx)
                priorities.append(priority)
        
        # Calculate importance sampling weights
        self.frame += 1
        probs = np.array(priorities) / self.tree.total
        weights = (self.tree.n_entries * probs) ** (-self.beta)
        weights = weights / weights.max()
        
        # Unpack batch
        states = np.array([e[0] for e in batch])
        actions = np.array([e[1] for e in batch])
        rewards = np.array([e[2] for e in batch])
        next_states = np.array([e[3] for e in batch])
        dones = np.array([e[4] for e in batch])
        emotions = [e[5] for e in batch]
        
        return (
            states, actions, rewards, next_states, dones, emotions,
            indices, weights
        )
    
    def update_priorities(self, indices: List[int], td_errors: np.ndarray):
        """Update priorities based on TD errors."""
        for idx, td_error in zip(indices, td_errors):
            priority = (abs(td_error) + self.min_priority) ** self.alpha
            self.max_priority = max(self.max_priority, priority)
            self.tree.update(idx, priority)
    
    def __len__(self) -> int:
        return self.tree.n_entries


# =============================================================================
# N-STEP BUFFER
# =============================================================================

class NStepBuffer:
    """
    N-step returns buffer for better credit assignment.
    Accumulates n-step returns before adding to replay.
    """
    
    def __init__(self, n_steps: int = 3, gamma: float = 0.99):
        self.n_steps = n_steps
        self.gamma = gamma
        self.buffer = deque(maxlen=n_steps)
    
    def add(self, state, action, reward, next_state, done, emotion=None) -> Optional[Tuple]:
        """
        Add transition and return n-step transition if ready.
        """
        self.buffer.append((state, action, reward, next_state, done, emotion))
        
        if len(self.buffer) < self.n_steps:
            return None
        
        # Calculate n-step return
        n_step_return = 0
        for i, (_, _, r, _, d, _) in enumerate(self.buffer):
            n_step_return += (self.gamma ** i) * r
            if d:
                break
        
        # Get first state/action and last next_state
        first = self.buffer[0]
        last = self.buffer[-1]
        
        return (
            first[0],  # state
            first[1],  # action
            n_step_return,  # n-step reward
            last[3],  # next_state (n steps ahead)
            last[4],  # done
            first[5],  # emotion
        )
    
    def flush(self) -> List[Tuple]:
        """Flush remaining transitions at episode end."""
        transitions = []
        while len(self.buffer) > 0:
            # Calculate partial n-step return
            n_step_return = 0
            for i, (_, _, r, _, d, _) in enumerate(self.buffer):
                n_step_return += (self.gamma ** i) * r
                if d:
                    break
            
            first = self.buffer[0]
            last = self.buffer[-1]
            
            transitions.append((
                first[0], first[1], n_step_return,
                last[3], last[4], first[5]
            ))
            self.buffer.popleft()
        
        return transitions
    
    def reset(self):
        self.buffer.clear()


# =============================================================================
# RAINBOW DQN NETWORK
# =============================================================================

class RainbowDQN(nn.Module):
    """
    Rainbow DQN with all improvements:
    - Dueling architecture
    - Noisy networks
    - Distributional RL (C51)
    - Emotional awareness
    """
    
    def __init__(
        self,
        state_dim: int,
        action_dim: int,
        emotion_dim: int = 8,
        hidden_dim: int = 256,
        n_atoms: int = 51,  # C51 atoms
        v_min: float = -10.0,
        v_max: float = 10.0,
        noisy: bool = True
    ):
        super().__init__()
        
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.emotion_dim = emotion_dim
        self.n_atoms = n_atoms
        self.v_min = v_min
        self.v_max = v_max
        
        # Support for distributional RL
        self.register_buffer(
            'support',
            torch.linspace(v_min, v_max, n_atoms)
        )
        self.delta_z = (v_max - v_min) / (n_atoms - 1)
        
        # Linear layer type
        Linear = NoisyLinear if noisy else nn.Linear
        
        # State encoder
        self.state_encoder = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU()
        )
        
        # Emotion encoder
        self.emotion_encoder = nn.Sequential(
            nn.Linear(emotion_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 64)
        )
        
        # Combined feature dimension
        feature_dim = hidden_dim + 64
        
        # Dueling streams with noisy layers
        # Value stream (how good is this state?)
        self.value_stream = nn.Sequential(
            Linear(feature_dim, hidden_dim),
            nn.ReLU(),
            Linear(hidden_dim, n_atoms)
        )
        
        # Advantage stream (how good is each action?)
        self.advantage_stream = nn.Sequential(
            Linear(feature_dim, hidden_dim),
            nn.ReLU(),
            Linear(hidden_dim, action_dim * n_atoms)
        )
        
        # Initialize
        self.apply(self._init_weights)
    
    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            nn.init.xavier_uniform_(m.weight)
            if m.bias is not None:
                nn.init.zeros_(m.bias)
    
    def forward(
        self, 
        state: torch.Tensor, 
        emotion: torch.Tensor
    ) -> torch.Tensor:
        """
        Forward pass returning action distributions.
        
        Returns:
            Distribution over atoms for each action: (batch, action_dim, n_atoms)
        """
        batch_size = state.size(0)
        
        # Encode state and emotion
        state_features = self.state_encoder(state)
        emotion_features = self.emotion_encoder(emotion)
        
        # Combine features
        features = torch.cat([state_features, emotion_features], dim=-1)
        
        # Dueling architecture
        value = self.value_stream(features).view(batch_size, 1, self.n_atoms)
        advantage = self.advantage_stream(features).view(batch_size, self.action_dim, self.n_atoms)
        
        # Q = V + (A - mean(A))
        q_atoms = value + advantage - advantage.mean(dim=1, keepdim=True)
        
        # Softmax over atoms to get distribution
        q_dist = F.softmax(q_atoms, dim=-1)
        
        return q_dist
    
    def get_q_values(
        self, 
        state: torch.Tensor, 
        emotion: torch.Tensor
    ) -> torch.Tensor:
        """Get expected Q-values from distribution."""
        q_dist = self.forward(state, emotion)
        q_values = (q_dist * self.support).sum(dim=-1)
        return q_values
    
    def reset_noise(self):
        """Reset noise in noisy layers."""
        for module in self.modules():
            if isinstance(module, NoisyLinear):
                module.reset_noise()


# =============================================================================
# RAINBOW AGENT
# =============================================================================

class RainbowAgent:
    """
    Complete Rainbow DQN Agent with all components.
    
    Features:
    - Double DQN
    - Dueling Networks
    - Noisy Networks
    - Prioritized Experience Replay
    - N-step Returns
    - Distributional RL (C51)
    - Emotional Awareness
    - Curiosity Integration
    """
    
    def __init__(
        self,
        state_dim: int,
        action_dim: int,
        emotion_dim: int = 8,
        hidden_dim: int = 256,
        # Distributional
        n_atoms: int = 51,
        v_min: float = -10.0,
        v_max: float = 10.0,
        # Learning
        lr: float = 0.0001,
        gamma: float = 0.99,
        # N-step
        n_steps: int = 3,
        # Replay
        buffer_size: int = 100000,
        batch_size: int = 32,
        # PER
        alpha: float = 0.6,
        beta_start: float = 0.4,
        # Target network
        target_update_freq: int = 1000,
        # Emotional
        emotion_weight: float = 0.3,
        # Device
        device: str = "cpu"
    ):
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.emotion_dim = emotion_dim
        self.gamma = gamma
        self.n_steps = n_steps
        self.batch_size = batch_size
        self.target_update_freq = target_update_freq
        self.emotion_weight = emotion_weight
        self.device = torch.device(device)
        
        # Distributional parameters
        self.n_atoms = n_atoms
        self.v_min = v_min
        self.v_max = v_max
        self.support = torch.linspace(v_min, v_max, n_atoms).to(self.device)
        self.delta_z = (v_max - v_min) / (n_atoms - 1)
        
        # Networks
        self.online_net = RainbowDQN(
            state_dim, action_dim, emotion_dim, hidden_dim,
            n_atoms, v_min, v_max, noisy=True
        ).to(self.device)
        
        self.target_net = RainbowDQN(
            state_dim, action_dim, emotion_dim, hidden_dim,
            n_atoms, v_min, v_max, noisy=True
        ).to(self.device)
        
        self.target_net.load_state_dict(self.online_net.state_dict())
        self.target_net.eval()
        
        # Optimizer
        self.optimizer = torch.optim.Adam(self.online_net.parameters(), lr=lr)
        
        # Replay buffer
        self.replay_buffer = PrioritizedReplayBuffer(
            buffer_size, alpha, beta_start
        )
        
        # N-step buffer
        self.n_step_buffer = NStepBuffer(n_steps, gamma)
        
        # Training state
        self.train_steps = 0
        self.learning_started = False
        
        # Heuristics for untrained model
        self.use_heuristics = True
    
    def select_action(
        self,
        state: np.ndarray,
        emotion: np.ndarray,
        query: str = "",
        training: bool = True
    ) -> Tuple[int, Optional[np.ndarray]]:
        """
        Select action using noisy networks (no epsilon needed).
        Falls back to heuristics for untrained model.
        """
        # Use heuristics for common cases (helps untrained model)
        if self.use_heuristics and query:
            heuristic_action = self._get_heuristic_action(query, emotion)
            if heuristic_action is not None:
                return heuristic_action, None
        
        # Reset noise for exploration
        if training:
            self.online_net.reset_noise()
        
        with torch.no_grad():
            state_t = torch.FloatTensor(state).unsqueeze(0).to(self.device)
            emotion_t = torch.FloatTensor(emotion).unsqueeze(0).to(self.device)
            
            q_values = self.online_net.get_q_values(state_t, emotion_t)
            
            # Apply emotional bias
            q_values = self._apply_emotional_bias(q_values, emotion)
            
            action = q_values.argmax(dim=-1).item()
            
        return action, q_values.cpu().numpy()[0]
    
    def _get_heuristic_action(self, query: str, emotion: np.ndarray) -> Optional[int]:
        """Heuristic action selection for common patterns."""
        query_lower = query.lower()
        
        # Action IDs (must match ActionType enum)
        DIRECT_ANSWER = 0
        RAG_RETRIEVE = 1
        WEB_SEARCH = 2
        VISION_ANALYZE = 3
        THINK_STEP = 4
        CLARIFY = 5
        BREAK_DOWN = 6
        EMPATHIZE = 7
        CELEBRATE = 8
        COMFORT = 9
        ENCOURAGE = 10
        
        # Greetings
        if any(g in query_lower for g in ["hello", "hi ", "hey", "good morning", "good evening"]):
            return DIRECT_ANSWER
        
        # Vision requests
        if any(w in query_lower for w in ["image", "picture", "photo", "see this", "look at"]):
            return VISION_ANALYZE
        
        # Search requests
        if any(w in query_lower for w in ["search", "google", "look up", "find online", "latest"]):
            return WEB_SEARCH
        
        # Knowledge requests
        if any(w in query_lower for w in ["remember", "you know", "we discussed", "i told you"]):
            return RAG_RETRIEVE
        
        # Emotional states
        negative_emotions = emotion[[1, 2, 3, 5]]  # sadness, anger, fear, disgust
        positive_emotions = emotion[[0, 6, 7]]  # joy, trust, anticipation
        
        if np.max(negative_emotions) > 0.5:
            if emotion[1] > 0.5:  # Sadness
                return COMFORT
            return EMPATHIZE
        
        if emotion[0] > 0.5:  # Joy
            return CELEBRATE
        
        # Complex questions
        if any(w in query_lower for w in ["explain", "why", "how does", "what is"]):
            return THINK_STEP
        
        # Tasks
        if any(w in query_lower for w in ["create", "build", "make", "write"]):
            return BREAK_DOWN
        
        return None  # Use DQN
    
    def _apply_emotional_bias(
        self, 
        q_values: torch.Tensor, 
        emotion: np.ndarray
    ) -> torch.Tensor:
        """Apply emotional bias to Q-values."""
        emotion_intensity = np.max(emotion)
        negative_emotions = emotion[[1, 2, 3, 5]]
        
        if np.max(negative_emotions) > 0.5:
            # Boost emotional actions when user is distressed
            emotional_bonus = torch.zeros(self.action_dim, device=self.device)
            emotional_bonus[7:11] = self.emotion_weight * emotion_intensity
            q_values = q_values + emotional_bonus
        
        return q_values
    
    def store_transition(
        self,
        state: np.ndarray,
        action: int,
        reward: float,
        next_state: np.ndarray,
        done: bool,
        emotion: np.ndarray = None
    ):
        """Store transition with n-step processing."""
        n_step_transition = self.n_step_buffer.add(
            state, action, reward, next_state, done, emotion
        )
        
        if n_step_transition:
            self.replay_buffer.add(*n_step_transition)
        
        if done:
            # Flush remaining transitions
            for transition in self.n_step_buffer.flush():
                self.replay_buffer.add(*transition)
    
    def train_step(self) -> Optional[float]:
        """Perform one training step."""
        if len(self.replay_buffer) < self.batch_size:
            return None
        
        self.learning_started = True
        self.train_steps += 1
        
        # Sample batch
        (states, actions, rewards, next_states, dones, emotions,
         indices, weights) = self.replay_buffer.sample(self.batch_size)
        
        # Convert to tensors
        states_t = torch.FloatTensor(states).to(self.device)
        actions_t = torch.LongTensor(actions).to(self.device)
        rewards_t = torch.FloatTensor(rewards).to(self.device)
        next_states_t = torch.FloatTensor(next_states).to(self.device)
        dones_t = torch.FloatTensor(dones).to(self.device)
        weights_t = torch.FloatTensor(weights).to(self.device)
        
        # Handle emotions
        if emotions[0] is not None:
            emotions_t = torch.FloatTensor(np.array(emotions)).to(self.device)
        else:
            emotions_t = torch.zeros(self.batch_size, self.emotion_dim).to(self.device)
        
        # Current distribution
        current_dist = self.online_net(states_t, emotions_t)
        current_dist = current_dist[range(self.batch_size), actions_t]
        
        # Target distribution (Double DQN)
        with torch.no_grad():
            # Reset target noise
            self.target_net.reset_noise()
            
            # Get next actions from online network (Double DQN)
            next_q = self.online_net.get_q_values(next_states_t, emotions_t)
            next_actions = next_q.argmax(dim=-1)
            
            # Get distribution from target network
            next_dist = self.target_net(next_states_t, emotions_t)
            next_dist = next_dist[range(self.batch_size), next_actions]
            
            # Project distribution
            target_dist = self._project_distribution(
                rewards_t, dones_t, next_dist
            )
        
        # Cross-entropy loss
        loss = -(target_dist * current_dist.clamp(min=1e-5).log()).sum(dim=-1)
        
        # Apply importance sampling weights
        weighted_loss = (loss * weights_t).mean()
        
        # Optimize
        self.optimizer.zero_grad()
        weighted_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.online_net.parameters(), 10.0)
        self.optimizer.step()
        
        # Update priorities
        td_errors = loss.detach().cpu().numpy()
        self.replay_buffer.update_priorities(indices, td_errors)
        
        # Reset online noise
        self.online_net.reset_noise()
        
        # Update target network
        if self.train_steps % self.target_update_freq == 0:
            self.target_net.load_state_dict(self.online_net.state_dict())
        
        return weighted_loss.item()
    
    def _project_distribution(
        self,
        rewards: torch.Tensor,
        dones: torch.Tensor,
        next_dist: torch.Tensor
    ) -> torch.Tensor:
        """Project target distribution for distributional RL."""
        batch_size = rewards.size(0)
        
        # Compute projected support
        # Tz = r + gamma^n * z (clipped to [v_min, v_max])
        gamma_n = self.gamma ** self.n_steps
        Tz = rewards.unsqueeze(1) + (1 - dones.unsqueeze(1)) * gamma_n * self.support
        Tz = Tz.clamp(self.v_min, self.v_max)
        
        # Compute projection indices
        b = (Tz - self.v_min) / self.delta_z
        l = b.floor().long()
        u = b.ceil().long()
        
        # Handle edge cases
        l[(u > 0) * (l == u)] -= 1
        u[(l < (self.n_atoms - 1)) * (l == u)] += 1
        
        # Distribute probability
        target_dist = torch.zeros_like(next_dist)
        
        offset = torch.arange(batch_size, device=self.device).unsqueeze(1) * self.n_atoms
        
        target_dist.view(-1).index_add_(
            0, (l + offset).view(-1), (next_dist * (u.float() - b)).view(-1)
        )
        target_dist.view(-1).index_add_(
            0, (u + offset).view(-1), (next_dist * (b - l.float())).view(-1)
        )
        
        return target_dist
    
    def save(self, path: str):
        """Save agent state."""
        torch.save({
            'online_net': self.online_net.state_dict(),
            'target_net': self.target_net.state_dict(),
            'optimizer': self.optimizer.state_dict(),
            'train_steps': self.train_steps,
            'use_heuristics': self.use_heuristics,
        }, path)
    
    def load(self, path: str):
        """Load agent state."""
        checkpoint = torch.load(path, map_location=self.device)
        self.online_net.load_state_dict(checkpoint['online_net'])
        self.target_net.load_state_dict(checkpoint['target_net'])
        self.optimizer.load_state_dict(checkpoint['optimizer'])
        self.train_steps = checkpoint.get('train_steps', 0)
        self.use_heuristics = checkpoint.get('use_heuristics', True)
        
        # After sufficient training, reduce heuristics
        if self.train_steps > 10000:
            self.use_heuristics = False


# =============================================================================
# CURIOSITY MODULE (RND)
# =============================================================================

class CuriosityRND(nn.Module):
    """
    Random Network Distillation for curiosity-driven exploration.
    Provides intrinsic rewards for novel states.
    """
    
    def __init__(self, state_dim: int, hidden_dim: int = 256, output_dim: int = 128):
        super().__init__()
        
        # Fixed random target network
        self.target = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, output_dim)
        )
        
        # Predictor network (learns to match target)
        self.predictor = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, output_dim)
        )
        
        # Freeze target
        for param in self.target.parameters():
            param.requires_grad = False
        
        # Running stats for normalization
        self.running_mean = 0.0
        self.running_std = 1.0
        self.count = 0
    
    def compute_intrinsic_reward(self, state: np.ndarray) -> float:
        """Compute curiosity-based intrinsic reward."""
        with torch.no_grad():
            state_t = torch.FloatTensor(state).unsqueeze(0)
            target_out = self.target(state_t)
            pred_out = self.predictor(state_t)
            error = F.mse_loss(pred_out, target_out).item()
            
            # Normalize
            normalized = (error - self.running_mean) / (self.running_std + 1e-8)
            
            # Update stats
            self.count += 1
            delta = error - self.running_mean
            self.running_mean += delta / self.count
            self.running_std = np.sqrt(
                ((self.count - 1) * self.running_std ** 2 + delta * (error - self.running_mean)) / self.count
            )
            
            return min(max(normalized, 0.0), 1.0)
    
    def train_step(self, states: torch.Tensor) -> float:
        """Train predictor to reduce curiosity on visited states."""
        target_out = self.target(states)
        pred_out = self.predictor(states)
        loss = F.mse_loss(pred_out, target_out)
        return loss


# =============================================================================
# RLHF REWARD MODEL
# =============================================================================

class RLHFRewardModel(nn.Module):
    """
    Learned reward model from human feedback.
    Predicts user satisfaction given state and action.
    """
    
    def __init__(self, state_dim: int, action_dim: int, hidden_dim: int = 256):
        super().__init__()
        
        self.action_dim = action_dim
        
        self.net = nn.Sequential(
            nn.Linear(state_dim + action_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_dim, 1),
            nn.Tanh()  # Output in [-1, 1]
        )
        
        self.optimizer = torch.optim.Adam(self.parameters(), lr=0.0001)
    
    def forward(self, state: torch.Tensor, action: torch.Tensor) -> torch.Tensor:
        action_onehot = F.one_hot(action, num_classes=self.action_dim).float()
        combined = torch.cat([state, action_onehot], dim=-1)
        return self.net(combined)
    
    def predict_reward(self, state: np.ndarray, action: int) -> float:
        """Predict reward for state-action pair."""
        with torch.no_grad():
            state_t = torch.FloatTensor(state).unsqueeze(0)
            action_t = torch.LongTensor([action])
            return self.forward(state_t, action_t).item()
    
    def train_on_feedback(
        self,
        state: np.ndarray,
        action: int,
        feedback: float  # -1 to 1
    ) -> float:
        """Train on single feedback instance."""
        state_t = torch.FloatTensor(state).unsqueeze(0)
        action_t = torch.LongTensor([action])
        target = torch.FloatTensor([[feedback]])
        
        prediction = self.forward(state_t, action_t)
        loss = F.mse_loss(prediction, target)
        
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        
        return loss.item()


if __name__ == "__main__":
    # Test Rainbow DQN
    print("Testing Rainbow DQN...")
    
    agent = RainbowAgent(
        state_dim=128,
        action_dim=15,
        emotion_dim=8,
        hidden_dim=256
    )
    
    # Test action selection
    state = np.random.randn(128)
    emotion = np.zeros(8)
    emotion[0] = 0.8  # Joy
    
    action, q_values = agent.select_action(state, emotion, query="Hello!", training=True)
    print(f"Selected action: {action}")
    
    # Test training
    for i in range(100):
        s = np.random.randn(128)
        a = np.random.randint(0, 15)
        r = np.random.randn()
        ns = np.random.randn(128)
        d = False
        e = np.random.randn(8)
        
        agent.store_transition(s, a, r, ns, d, e)
        loss = agent.train_step()
        
        if loss and i % 20 == 0:
            print(f"Step {i}, Loss: {loss:.4f}")
    
    print("Rainbow DQN test complete!")
