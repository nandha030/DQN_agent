#!/usr/bin/env python3
"""
Dheera v5.0 - Super Intelligence
================================

Consolidated architecture combining the best of v3 and v4:
- Rainbow DQN (all 6 improvements)
- Emotional Intelligence
- Computer Vision (YOLO)
- Long-term Memory
- RAG Knowledge Base
- Web Search
- Dual LLM Support (Ollama + HuggingFace)
- Continuous Learning
- RLHF from feedback

This is a LEARNING AI that gets smarter with every interaction.

Usage:
    python dheera.py                    # Interactive chat
    python dheera.py --api --port 8000  # API server
    python dheera.py --llm ollama       # Use Ollama
    python dheera.py --llm transformers # Use HuggingFace
"""

import os
import sys
import json
import uuid
import hashlib
import asyncio
import sqlite3
from pathlib import Path
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List, Tuple, Union
from dataclasses import dataclass, field, asdict
from enum import Enum, auto
from collections import deque
import warnings
warnings.filterwarnings("ignore")

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

# Import our Rainbow DQN
from core.rainbow_dqn import RainbowAgent, CuriosityRND, RLHFRewardModel


# =============================================================================
# CONFIGURATION
# =============================================================================

@dataclass
class DheeraConfig:
    """Master configuration for Dheera v5."""
    
    # Identity
    version: str = "5.0.0"
    name: str = "Dheera"
    personality: str = "warm, curious, empathetic, wise, helpful"
    
    # Architecture
    state_dim: int = 128
    action_dim: int = 15
    hidden_dim: int = 256
    emotion_dim: int = 8
    memory_dim: int = 64
    
    # LLM settings
    llm_provider: str = "auto"  # "auto", "ollama", "transformers"
    ollama_model: str = "phi3:mini"
    transformers_model: str = "TinyLlama/TinyLlama-1.1B-Chat-v1.0"
    max_tokens: int = 512
    temperature: float = 0.7
    
    # Vision
    vision_enabled: bool = True
    yolo_model: str = "yolov8n"
    
    # Memory
    memory_capacity: int = 10000
    db_path: str = "./data/dheera.db"
    
    # Learning
    learning_enabled: bool = True
    train_every_n: int = 5  # Train every N interactions
    batch_size: int = 32
    
    # Rainbow DQN
    n_atoms: int = 51
    n_steps: int = 3
    gamma: float = 0.99
    
    # Emotional
    empathy_weight: float = 0.3


# =============================================================================
# EMOTIONS
# =============================================================================

class Emotion(Enum):
    JOY = 0
    SADNESS = 1
    ANGER = 2
    FEAR = 3
    SURPRISE = 4
    DISGUST = 5
    TRUST = 6
    ANTICIPATION = 7
    NEUTRAL = 8


@dataclass
class EmotionalState:
    primary: Emotion = Emotion.NEUTRAL
    secondary: Optional[Emotion] = None
    intensity: float = 0.5
    valence: float = 0.0
    arousal: float = 0.5
    
    def to_vector(self) -> np.ndarray:
        vec = np.zeros(8)
        if self.primary != Emotion.NEUTRAL:
            vec[self.primary.value] = self.intensity
        if self.secondary and self.secondary != Emotion.NEUTRAL:
            vec[self.secondary.value] = self.intensity * 0.5
        return vec


class EmotionDetector:
    """Detect emotions from text."""
    
    KEYWORDS = {
        Emotion.JOY: ["happy", "glad", "excited", "great", "wonderful", "love", "amazing", 
                      "awesome", "fantastic", "delighted", "pleased", "😊", "😄", "❤️", "🎉"],
        Emotion.SADNESS: ["sad", "unhappy", "depressed", "down", "lonely", "disappointed", 
                          "hurt", "crying", "miss", "😢", "😭", "💔"],
        Emotion.ANGER: ["angry", "mad", "furious", "annoyed", "frustrated", "irritated",
                        "hate", "rage", "😠", "😡", "🤬"],
        Emotion.FEAR: ["afraid", "scared", "worried", "anxious", "nervous", "terrified",
                       "panic", "stressed", "😰", "😨", "😱"],
        Emotion.SURPRISE: ["surprised", "shocked", "amazed", "wow", "unexpected", "😮", "😲", "🤯"],
        Emotion.DISGUST: ["disgusted", "gross", "sick", "horrible", "🤢", "🤮"],
        Emotion.TRUST: ["trust", "believe", "faith", "confident", "reliable", "safe"],
        Emotion.ANTICIPATION: ["excited", "waiting", "hoping", "looking forward", "can't wait"],
    }
    
    INTENSIFIERS = {"very": 1.3, "extremely": 1.5, "so": 1.2, "really": 1.2,
                    "a bit": 0.6, "slightly": 0.5, "somewhat": 0.7}
    
    def detect(self, text: str) -> EmotionalState:
        text_lower = text.lower()
        scores = {}
        
        for emotion, keywords in self.KEYWORDS.items():
            score = sum(1 for kw in keywords if kw in text_lower)
            if score > 0:
                scores[emotion] = score
        
        if not scores:
            return EmotionalState()
        
        sorted_emotions = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        primary = sorted_emotions[0][0]
        secondary = sorted_emotions[1][0] if len(sorted_emotions) > 1 else None
        
        intensity = 0.5
        for mod, mult in self.INTENSIFIERS.items():
            if mod in text_lower:
                intensity *= mult
        intensity = min(1.0, intensity)
        
        positive = {Emotion.JOY, Emotion.TRUST, Emotion.ANTICIPATION}
        negative = {Emotion.SADNESS, Emotion.ANGER, Emotion.FEAR, Emotion.DISGUST}
        
        valence = intensity if primary in positive else (-intensity if primary in negative else 0.0)
        arousal = 0.8 if primary in {Emotion.ANGER, Emotion.FEAR, Emotion.SURPRISE, Emotion.JOY} else 0.4
        
        return EmotionalState(primary, secondary, intensity, valence, arousal)


# =============================================================================
# ACTIONS
# =============================================================================

class ActionType(Enum):
    DIRECT_ANSWER = 0
    RAG_RETRIEVE = 1
    WEB_SEARCH = 2
    VISION_ANALYZE = 3
    THINK_STEP = 4
    CLARIFY = 5
    BREAK_DOWN = 6
    EMPATHIZE = 7
    CELEBRATE = 8
    COMFORT = 9
    ENCOURAGE = 10
    REMEMBER = 11
    RECALL = 12
    MULTI_TOOL = 13
    DEFER = 14


@dataclass
class ActionInfo:
    type: ActionType
    name: str
    description: str
    emotional_valence: float
    prompt_style: str


ACTION_REGISTRY = {
    ActionType.DIRECT_ANSWER: ActionInfo(
        ActionType.DIRECT_ANSWER, "Direct Answer",
        "Answer directly from knowledge", 0.0, "direct"
    ),
    ActionType.RAG_RETRIEVE: ActionInfo(
        ActionType.RAG_RETRIEVE, "Search Knowledge",
        "Search knowledge base", 0.0, "rag"
    ),
    ActionType.WEB_SEARCH: ActionInfo(
        ActionType.WEB_SEARCH, "Web Search",
        "Search the internet", 0.0, "web"
    ),
    ActionType.VISION_ANALYZE: ActionInfo(
        ActionType.VISION_ANALYZE, "Analyze Image",
        "Analyze image with YOLO", 0.1, "vision"
    ),
    ActionType.THINK_STEP: ActionInfo(
        ActionType.THINK_STEP, "Think Step by Step",
        "Reason through carefully", 0.0, "reasoning"
    ),
    ActionType.CLARIFY: ActionInfo(
        ActionType.CLARIFY, "Ask Clarification",
        "Ask for more details", 0.2, "clarify"
    ),
    ActionType.BREAK_DOWN: ActionInfo(
        ActionType.BREAK_DOWN, "Break Down",
        "Decompose into steps", 0.1, "breakdown"
    ),
    ActionType.EMPATHIZE: ActionInfo(
        ActionType.EMPATHIZE, "Empathize",
        "Show understanding", 0.8, "empathy"
    ),
    ActionType.CELEBRATE: ActionInfo(
        ActionType.CELEBRATE, "Celebrate",
        "Share in joy", 1.0, "celebrate"
    ),
    ActionType.COMFORT: ActionInfo(
        ActionType.COMFORT, "Comfort",
        "Provide comfort", 0.9, "comfort"
    ),
    ActionType.ENCOURAGE: ActionInfo(
        ActionType.ENCOURAGE, "Encourage",
        "Motivate and support", 0.7, "encourage"
    ),
    ActionType.REMEMBER: ActionInfo(
        ActionType.REMEMBER, "Remember",
        "Store information", 0.3, "remember"
    ),
    ActionType.RECALL: ActionInfo(
        ActionType.RECALL, "Recall",
        "Retrieve memories", 0.4, "recall"
    ),
    ActionType.MULTI_TOOL: ActionInfo(
        ActionType.MULTI_TOOL, "Multi-Tool",
        "Combine multiple tools", 0.1, "multi"
    ),
    ActionType.DEFER: ActionInfo(
        ActionType.DEFER, "Defer",
        "Cannot help", 0.2, "defer"
    ),
}


# =============================================================================
# DATABASE & MEMORY
# =============================================================================

class DheeraDatabase:
    """SQLite database for persistent storage."""
    
    def __init__(self, db_path: str):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(str(db_path), check_same_thread=False)
        self._init_tables()
    
    def _init_tables(self):
        cursor = self.conn.cursor()
        
        # User profile
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS user_profile (
                key TEXT PRIMARY KEY,
                value TEXT,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Conversations
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS conversations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                role TEXT,
                content TEXT,
                emotion TEXT,
                action_taken INTEGER,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Memories (semantic)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS memories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                type TEXT,
                content TEXT,
                importance REAL DEFAULT 0.5,
                access_count INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_accessed TIMESTAMP
            )
        """)
        
        # RLHF feedback
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS feedback (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                conversation_id INTEGER,
                rating REAL,
                comment TEXT,
                state BLOB,
                action INTEGER,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Experience replay
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS experiences (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                state BLOB,
                action INTEGER,
                reward REAL,
                next_state BLOB,
                done INTEGER,
                emotion BLOB,
                priority REAL DEFAULT 1.0,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Training stats
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS training_stats (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                episode INTEGER,
                loss REAL,
                avg_reward REAL,
                epsilon REAL,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        self.conn.commit()
    
    def get_profile(self, key: str, default=None):
        cursor = self.conn.cursor()
        cursor.execute("SELECT value FROM user_profile WHERE key = ?", (key,))
        row = cursor.fetchone()
        if row:
            try:
                return json.loads(row[0])
            except:
                return row[0]
        return default
    
    def set_profile(self, key: str, value):
        cursor = self.conn.cursor()
        cursor.execute("""
            INSERT OR REPLACE INTO user_profile (key, value, updated_at)
            VALUES (?, ?, CURRENT_TIMESTAMP)
        """, (key, json.dumps(value) if not isinstance(value, str) else value))
        self.conn.commit()
    
    def add_conversation(self, role: str, content: str, emotion: str = None, action: int = None):
        cursor = self.conn.cursor()
        cursor.execute("""
            INSERT INTO conversations (role, content, emotion, action_taken)
            VALUES (?, ?, ?, ?)
        """, (role, content, emotion, action))
        self.conn.commit()
        return cursor.lastrowid
    
    def get_recent_conversations(self, limit: int = 20) -> List[Dict]:
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT role, content, emotion, timestamp 
            FROM conversations 
            ORDER BY timestamp DESC LIMIT ?
        """, (limit,))
        rows = cursor.fetchall()
        return [{"role": r[0], "content": r[1], "emotion": r[2], "timestamp": r[3]} 
                for r in reversed(rows)]
    
    def add_memory(self, mem_type: str, content: str, importance: float = 0.5):
        cursor = self.conn.cursor()
        cursor.execute("""
            INSERT INTO memories (type, content, importance, last_accessed)
            VALUES (?, ?, ?, CURRENT_TIMESTAMP)
        """, (mem_type, content, importance))
        self.conn.commit()
    
    def search_memories(self, query: str, limit: int = 5) -> List[Dict]:
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT id, type, content, importance FROM memories
            WHERE content LIKE ?
            ORDER BY importance DESC, access_count DESC
            LIMIT ?
        """, (f"%{query}%", limit))
        
        results = []
        for row in cursor.fetchall():
            # Update access count
            cursor.execute("""
                UPDATE memories SET access_count = access_count + 1,
                last_accessed = CURRENT_TIMESTAMP WHERE id = ?
            """, (row[0],))
            results.append({"type": row[1], "content": row[2], "importance": row[3]})
        
        self.conn.commit()
        return results
    
    def add_feedback(self, conv_id: int, rating: float, comment: str,
                     state: np.ndarray, action: int):
        cursor = self.conn.cursor()
        cursor.execute("""
            INSERT INTO feedback (conversation_id, rating, comment, state, action)
            VALUES (?, ?, ?, ?, ?)
        """, (conv_id, rating, comment, state.tobytes(), action))
        self.conn.commit()
    
    def add_experience(self, state: np.ndarray, action: int, reward: float,
                       next_state: np.ndarray, done: bool, emotion: np.ndarray,
                       priority: float = 1.0):
        cursor = self.conn.cursor()
        cursor.execute("""
            INSERT INTO experiences (state, action, reward, next_state, done, emotion, priority)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (state.tobytes(), action, reward, next_state.tobytes(), 
              int(done), emotion.tobytes(), priority))
        self.conn.commit()
    
    def sample_experiences(self, batch_size: int) -> List[Tuple]:
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT state, action, reward, next_state, done, emotion, id
            FROM experiences
            ORDER BY priority DESC, RANDOM()
            LIMIT ?
        """, (batch_size,))
        
        experiences = []
        for row in cursor.fetchall():
            state = np.frombuffer(row[0], dtype=np.float32).reshape(-1)
            next_state = np.frombuffer(row[3], dtype=np.float32).reshape(-1)
            emotion = np.frombuffer(row[5], dtype=np.float32).reshape(-1)
            experiences.append((state, row[1], row[2], next_state, bool(row[4]), emotion, row[6]))
        
        return experiences
    
    def update_experience_priority(self, exp_id: int, priority: float):
        cursor = self.conn.cursor()
        cursor.execute("UPDATE experiences SET priority = ? WHERE id = ?", (priority, exp_id))
        self.conn.commit()
    
    def get_stats(self) -> Dict:
        cursor = self.conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM conversations")
        conv_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM memories")
        mem_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM feedback")
        feedback_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM experiences")
        exp_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT AVG(rating) FROM feedback")
        avg_rating = cursor.fetchone()[0] or 0
        
        return {
            "conversations": conv_count,
            "memories": mem_count,
            "feedback": feedback_count,
            "experiences": exp_count,
            "avg_rating": avg_rating
        }
    
    def close(self):
        self.conn.close()


# =============================================================================
# LLM INTERFACE (DUAL SUPPORT)
# =============================================================================

class LLMInterface:
    """
    Unified LLM interface supporting both Ollama and HuggingFace Transformers.
    """
    
    def __init__(self, config: DheeraConfig):
        self.config = config
        self.provider = None
        self.model = None
        self.tokenizer = None
        
        # Try to initialize based on config
        if config.llm_provider == "auto":
            self._auto_detect()
        elif config.llm_provider == "ollama":
            self._init_ollama()
        else:
            self._init_transformers()
    
    def _auto_detect(self):
        """Auto-detect best available LLM."""
        # Try Ollama first (better quality)
        if self._init_ollama():
            return
        
        # Fall back to transformers
        self._init_transformers()
    
    def _init_ollama(self) -> bool:
        """Initialize Ollama connection."""
        try:
            import requests
            response = requests.get("http://localhost:11434/api/tags", timeout=2)
            if response.status_code == 200:
                self.provider = "ollama"
                print(f"  ✓ LLM: Ollama ({self.config.ollama_model})")
                return True
        except:
            pass
        return False
    
    def _init_transformers(self) -> bool:
        """Initialize HuggingFace Transformers."""
        try:
            from transformers import AutoModelForCausalLM, AutoTokenizer
            
            model_id = self.config.transformers_model
            cache_dir = Path("./model_cache")
            cache_dir.mkdir(exist_ok=True)
            
            print(f"  Loading {model_id}...")
            
            self.tokenizer = AutoTokenizer.from_pretrained(
                model_id, cache_dir=cache_dir, trust_remote_code=True
            )
            if self.tokenizer.pad_token is None:
                self.tokenizer.pad_token = self.tokenizer.eos_token
            
            self.model = AutoModelForCausalLM.from_pretrained(
                model_id, cache_dir=cache_dir, trust_remote_code=True,
                torch_dtype=torch.float32
            )
            self.model.eval()
            
            self.provider = "transformers"
            print(f"  ✓ LLM: Transformers ({model_id})")
            return True
            
        except Exception as e:
            print(f"  ⚠ Transformers init failed: {e}")
            return False
    
    def generate(self, prompt: str, max_tokens: int = None) -> str:
        """Generate response from LLM."""
        max_tokens = max_tokens or self.config.max_tokens
        
        if self.provider == "ollama":
            return self._generate_ollama(prompt, max_tokens)
        elif self.provider == "transformers":
            return self._generate_transformers(prompt, max_tokens)
        else:
            return "LLM not available. Please install Ollama or transformers."
    
    def _generate_ollama(self, prompt: str, max_tokens: int) -> str:
        """Generate using Ollama."""
        import requests
        
        try:
            response = requests.post(
                "http://localhost:11434/api/generate",
                json={
                    "model": self.config.ollama_model,
                    "prompt": prompt,
                    "stream": False,
                    "options": {
                        "num_predict": max_tokens,
                        "temperature": self.config.temperature,
                    }
                },
                timeout=60
            )
            
            if response.status_code == 200:
                return response.json().get("response", "").strip()
            else:
                return f"Ollama error: {response.status_code}"
                
        except Exception as e:
            return f"Ollama error: {e}"
    
    def _generate_transformers(self, prompt: str, max_tokens: int) -> str:
        """Generate using Transformers."""
        if self.model is None:
            return "Transformers model not loaded."
        
        inputs = self.tokenizer(
            prompt,
            return_tensors="pt",
            truncation=True,
            max_length=512
        )
        
        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                max_new_tokens=min(max_tokens, 200),
                temperature=self.config.temperature,
                do_sample=True,
                pad_token_id=self.tokenizer.pad_token_id,
                repetition_penalty=1.2,
            )
        
        response = self.tokenizer.decode(
            outputs[0][inputs['input_ids'].shape[1]:],
            skip_special_tokens=True
        )
        
        return self._clean_response(response)
    
    def _clean_response(self, response: str) -> str:
        """Clean up response artifacts."""
        stop_patterns = [
            "User:", "Human:", "Assistant:", 
            "\nUser", "\nHuman", "\nAssistant",
            "Question:", "Answer:",
        ]
        
        for pattern in stop_patterns:
            pos = response.find(pattern)
            if pos > 0:
                response = response[:pos]
        
        response = response.strip().strip('"\'')
        
        if len(response) < 2:
            return "I'm here to help!"
        
        return response


# =============================================================================
# VISION SYSTEM
# =============================================================================

class VisionSystem:
    """YOLO-based computer vision."""
    
    def __init__(self, config: DheeraConfig):
        self.config = config
        self.model = None
        self.available = False
        
        if config.vision_enabled:
            self._init_yolo()
    
    def _init_yolo(self):
        try:
            from ultralytics import YOLO
            self.model = YOLO(self.config.yolo_model)
            self.available = True
            print("  ✓ Vision (YOLO)")
        except ImportError:
            print("  ⚠ YOLO not available")
        except Exception as e:
            print(f"  ⚠ YOLO error: {e}")
    
    def analyze(self, image_path: str) -> Dict[str, Any]:
        """Analyze image and return detected objects."""
        if not self.available:
            return {"success": False, "error": "YOLO not available"}
        
        if not Path(image_path).exists():
            return {"success": False, "error": "Image not found"}
        
        try:
            detections = self.model(image_path, verbose=False)
            
            objects = []
            for det in detections:
                if det.boxes is not None:
                    for box in det.boxes:
                        cls_id = int(box.cls[0])
                        conf = float(box.conf[0])
                        name = det.names[cls_id]
                        objects.append({
                            "name": name,
                            "confidence": round(conf, 2)
                        })
            
            # Generate description
            if objects:
                unique = {}
                for o in objects:
                    unique[o["name"]] = unique.get(o["name"], 0) + 1
                
                desc_parts = []
                for name, count in unique.items():
                    if count > 1:
                        desc_parts.append(f"{count} {name}s")
                    else:
                        desc_parts.append(f"a {name}")
                
                description = f"I can see {', '.join(desc_parts)}."
            else:
                description = "I analyzed the image but couldn't identify specific objects."
            
            return {
                "success": True,
                "objects": objects,
                "description": description
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}


# =============================================================================
# TOOLS
# =============================================================================

class WebSearch:
    """Web search tool."""
    
    def __init__(self):
        self.available = False
        self._init()
    
    def _init(self):
        try:
            from duckduckgo_search import DDGS
            self.ddgs = DDGS()
            self.available = True
        except:
            try:
                from ddgs import DDGS
                self.ddgs = DDGS()
                self.available = True
            except:
                pass
    
    def search(self, query: str, max_results: int = 3) -> str:
        if not self.available:
            return "Web search not available."
        
        try:
            results = list(self.ddgs.text(query, max_results=max_results))
            if not results:
                return "No results found."
            
            summaries = []
            for r in results:
                title = r.get("title", "")
                body = r.get("body", "")[:150]
                summaries.append(f"• {title}: {body}")
            
            return "\n".join(summaries)
        except Exception as e:
            return f"Search error: {e}"


class RAGKnowledge:
    """Simple RAG knowledge base."""
    
    def __init__(self, knowledge_dir: str = "./knowledge"):
        self.knowledge_dir = Path(knowledge_dir)
        self.knowledge_dir.mkdir(parents=True, exist_ok=True)
        self.documents = []
        self._load()
    
    def _load(self):
        for file_path in self.knowledge_dir.glob("*.txt"):
            try:
                with open(file_path) as f:
                    self.documents.append({
                        "id": file_path.stem,
                        "content": f.read()
                    })
            except:
                pass
    
    def add(self, content: str, doc_id: str = None):
        doc_id = doc_id or str(uuid.uuid4())[:8]
        file_path = self.knowledge_dir / f"{doc_id}.txt"
        with open(file_path, 'w') as f:
            f.write(content)
        self.documents.append({"id": doc_id, "content": content})
    
    def search(self, query: str, top_k: int = 3) -> str:
        query_words = set(query.lower().split())
        
        scored = []
        for doc in self.documents:
            doc_words = set(doc["content"].lower().split())
            overlap = len(query_words & doc_words)
            if overlap > 0:
                scored.append((overlap, doc["content"][:300]))
        
        scored.sort(key=lambda x: x[0], reverse=True)
        
        if not scored:
            return "No relevant knowledge found."
        
        return "\n\n".join(text for _, text in scored[:top_k])


# =============================================================================
# STATE BUILDER
# =============================================================================

class StateBuilder:
    """Build state vector for Rainbow DQN."""
    
    def __init__(self, config: DheeraConfig):
        self.config = config
    
    def build(
        self,
        query: str,
        emotion: EmotionalState,
        conversation_history: List[Dict],
        vision_result: Optional[Dict] = None,
        user_profile: Optional[Dict] = None
    ) -> np.ndarray:
        """Build 128-dim state vector."""
        state = np.zeros(self.config.state_dim, dtype=np.float32)
        
        # Query features (0-31)
        words = query.lower().split()
        state[0] = min(len(words) / 50, 1.0)
        state[1] = query.count('?') / 3
        state[2] = query.count('!') / 3
        
        # Intent indicators
        state[3] = 1.0 if any(w in query.lower() for w in ['what', 'who', 'when', 'where', 'why', 'how']) else 0.0
        state[4] = 1.0 if any(w in query.lower() for w in ['feel', 'feeling', 'emotion']) else 0.0
        state[5] = 1.0 if any(w in query.lower() for w in ['help', 'please', 'need']) else 0.0
        state[6] = 1.0 if any(w in query.lower() for w in ['remember', 'recall', 'forgot']) else 0.0
        state[7] = 1.0 if any(w in query.lower() for w in ['search', 'find', 'look up']) else 0.0
        state[8] = 1.0 if any(w in query.lower() for w in ['image', 'picture', 'photo']) else 0.0
        state[9] = 1.0 if any(w in query.lower() for w in ['create', 'make', 'build']) else 0.0
        state[10] = 1.0 if any(w in query.lower() for w in ['explain', 'describe']) else 0.0
        
        # Word embeddings (simple hash-based)
        for i, word in enumerate(words[:20]):
            state[12 + i] = (hash(word) % 1000) / 1000
        
        # Emotion features (32-47)
        emotion_vec = emotion.to_vector()
        state[32:40] = emotion_vec
        state[40] = emotion.intensity
        state[41] = (emotion.valence + 1) / 2
        state[42] = emotion.arousal
        
        # Conversation context (48-79)
        state[48] = min(len(conversation_history) / 20, 1.0)
        
        if conversation_history:
            # Recent messages sentiment
            recent = conversation_history[-5:]
            for i, msg in enumerate(recent):
                if msg.get("emotion"):
                    state[50 + i] = 0.5  # Has emotion
        
        # Vision features (80-95)
        if vision_result and vision_result.get("success"):
            state[80] = 1.0
            state[81] = min(len(vision_result.get("objects", [])) / 10, 1.0)
        
        # User profile features (96-111)
        if user_profile:
            state[96] = 1.0 if user_profile.get("name") else 0.0
            state[97] = min(len(user_profile.get("facts", {})) / 10, 1.0)
            state[98] = min(len(user_profile.get("likes", [])) / 10, 1.0)
        
        # Time features (112-127)
        now = datetime.now()
        state[112] = now.hour / 24
        state[113] = now.weekday() / 7
        
        # Random features for exploration
        state[120:128] = np.random.randn(8) * 0.05
        
        return state


# =============================================================================
# DHEERA V5 - MAIN CLASS
# =============================================================================

class DheeraV5:
    """
    Dheera v5.0 - Super Intelligence
    
    Features:
    - Rainbow DQN (all 6 improvements)
    - Emotional Intelligence
    - Computer Vision (YOLO)
    - Long-term Memory
    - RAG + Web Search
    - Dual LLM Support
    - Continuous Learning
    - RLHF
    """
    
    VERSION = "5.0.0"
    
    def __init__(self, config: Optional[DheeraConfig] = None):
        self.config = config or DheeraConfig()
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
        print(f"""
╔══════════════════════════════════════════════════════════════╗
║          धीर  DHEERA v{self.VERSION} - Super Intelligence          ║
║          Continuously Learning AI Companion                  ║
╠══════════════════════════════════════════════════════════════╣
║  Device: {str(self.device):50} ║
╚══════════════════════════════════════════════════════════════╝
        """)
        
        # Initialize all components
        print("📦 Initializing Components...")
        
        # Database
        self.db = DheeraDatabase(self.config.db_path)
        print(f"  ✓ Database ({self.db.get_stats()['conversations']} conversations)")
        
        # Emotion detector
        self.emotion_detector = EmotionDetector()
        print("  ✓ Emotion Detector")
        
        # State builder
        self.state_builder = StateBuilder(self.config)
        print("  ✓ State Builder")
        
        # Rainbow DQN Agent
        self.agent = RainbowAgent(
            state_dim=self.config.state_dim,
            action_dim=self.config.action_dim,
            emotion_dim=self.config.emotion_dim,
            hidden_dim=self.config.hidden_dim,
            n_atoms=self.config.n_atoms,
            n_steps=self.config.n_steps,
            gamma=self.config.gamma,
            device=str(self.device)
        )
        print("  ✓ Rainbow DQN Agent")
        
        # Curiosity
        self.curiosity = CuriosityRND(
            state_dim=self.config.state_dim,
            hidden_dim=self.config.hidden_dim
        ).to(self.device)
        print("  ✓ Curiosity (RND)")
        
        # RLHF Reward Model
        self.reward_model = RLHFRewardModel(
            state_dim=self.config.state_dim,
            action_dim=self.config.action_dim,
            hidden_dim=self.config.hidden_dim
        ).to(self.device)
        print("  ✓ RLHF Reward Model")
        
        # Vision
        self.vision = VisionSystem(self.config)
        
        # Tools
        self.web_search = WebSearch()
        if self.web_search.available:
            print("  ✓ Web Search")
        
        self.rag = RAGKnowledge()
        print(f"  ✓ RAG ({len(self.rag.documents)} documents)")
        
        # LLM
        self.llm = LLMInterface(self.config)
        
        # Load user profile
        self.user_profile = self._load_user_profile()
        
        # State tracking
        self.interaction_count = 0
        self.last_state = None
        self.last_action = None
        self.last_conv_id = None
        
        # Load checkpoint if exists
        self._load_checkpoint()
        
        print(f"""
╔══════════════════════════════════════════════════════════════╗
║                    ✅ Dheera v5 Ready!                       ║
║                                                              ║
║  User: {str(self.user_profile.get('name', 'Unknown')):52} ║
║  Total interactions: {str(self.db.get_stats()['conversations']):38} ║
║  Learning: {'Enabled' if self.config.learning_enabled else 'Disabled':48} ║
╚══════════════════════════════════════════════════════════════╝
        """)
    
    def _load_user_profile(self) -> Dict:
        """Load user profile from database."""
        return {
            "name": self.db.get_profile("name"),
            "facts": self.db.get_profile("facts", {}),
            "likes": self.db.get_profile("likes", []),
            "dislikes": self.db.get_profile("dislikes", []),
            "first_interaction": self.db.get_profile("first_interaction"),
            "total_messages": self.db.get_profile("total_messages", 0)
        }
    
    def _save_user_profile(self):
        """Save user profile to database."""
        for key, value in self.user_profile.items():
            self.db.set_profile(key, value)
    
    def _load_checkpoint(self):
        """Load saved model checkpoint."""
        checkpoint_path = Path("./checkpoints/dheera_v5")
        if (checkpoint_path / "rainbow_dqn.pt").exists():
            try:
                self.agent.load(str(checkpoint_path / "rainbow_dqn.pt"))
                print("  ✓ Loaded Rainbow DQN checkpoint")
            except Exception as e:
                print(f"  ⚠ Could not load checkpoint: {e}")
    
    def _save_checkpoint(self):
        """Save model checkpoint."""
        checkpoint_path = Path("./checkpoints/dheera_v5")
        checkpoint_path.mkdir(parents=True, exist_ok=True)
        
        self.agent.save(str(checkpoint_path / "rainbow_dqn.pt"))
        
        torch.save(self.curiosity.state_dict(), checkpoint_path / "curiosity.pt")
        torch.save(self.reward_model.state_dict(), checkpoint_path / "reward_model.pt")
    
    def _extract_user_info(self, query: str):
        """Extract and store user information from query."""
        query_lower = query.lower()
        
        # Name extraction
        if "my name is" in query_lower:
            parts = query_lower.split("my name is")
            if len(parts) > 1:
                name = parts[1].strip().split()[0].capitalize()
                self.user_profile["name"] = name
                self.db.set_profile("name", name)
        
        # Likes
        if "i love" in query_lower or "i like" in query_lower:
            parts = query_lower.replace("i love", "i like").split("i like")
            if len(parts) > 1:
                like = parts[1].strip().split('.')[0].strip()
                if like and like not in self.user_profile.get("likes", []):
                    self.user_profile.setdefault("likes", []).append(like)
                    self.db.set_profile("likes", self.user_profile["likes"])
        
        # Dislikes
        if "i hate" in query_lower or "i don't like" in query_lower:
            parts = query_lower.replace("i hate", "i don't like").split("i don't like")
            if len(parts) > 1:
                dislike = parts[1].strip().split('.')[0].strip()
                if dislike and dislike not in self.user_profile.get("dislikes", []):
                    self.user_profile.setdefault("dislikes", []).append(dislike)
                    self.db.set_profile("dislikes", self.user_profile["dislikes"])
    
    def _execute_action(
        self, 
        action: ActionInfo, 
        query: str, 
        emotion: EmotionalState,
        vision_result: Optional[Dict] = None
    ) -> str:
        """Execute action and return context."""
        context = ""
        
        if action.type == ActionType.RAG_RETRIEVE:
            context = self.rag.search(query)
            
        elif action.type == ActionType.WEB_SEARCH:
            context = self.web_search.search(query)
            
        elif action.type == ActionType.VISION_ANALYZE:
            if vision_result:
                context = vision_result.get("description", "")
                
        elif action.type == ActionType.RECALL:
            memories = self.db.search_memories(query, limit=3)
            if memories:
                context = "\n".join(f"• {m['content']}" for m in memories)
            else:
                context = "No relevant memories found."
                
        elif action.type == ActionType.REMEMBER:
            self.db.add_memory("user_info", query, importance=0.7)
            self._extract_user_info(query)
            context = "I'll remember that."
            
        elif action.type == ActionType.MULTI_TOOL:
            rag_context = self.rag.search(query)
            web_context = self.web_search.search(query)
            context = f"Knowledge:\n{rag_context}\n\nWeb:\n{web_context}"
            
        elif action.type in [ActionType.EMPATHIZE, ActionType.COMFORT, 
                             ActionType.CELEBRATE, ActionType.ENCOURAGE]:
            context = f"User emotion: {emotion.primary.name} (intensity: {emotion.intensity:.1f})"
        
        return context
    
    def _build_prompt(
        self,
        action: ActionInfo,
        query: str,
        context: str,
        emotion: EmotionalState
    ) -> str:
        """Build prompt for LLM."""
        user_name = self.user_profile.get("name", "friend")
        
        # Base system prompt
        system = f"You are {self.config.name}, an AI companion who is {self.config.personality}. "
        system += f"You're talking to {user_name}. Give a natural, helpful response. "
        system += "Do not generate multiple conversation turns."
        
        # Action-specific prompt
        if action.type == ActionType.DIRECT_ANSWER:
            prompt = f"User: {query}\nAssistant:"
            
        elif action.type == ActionType.RAG_RETRIEVE:
            prompt = f"Knowledge:\n{context}\n\nUser: {query}\nAssistant:"
            
        elif action.type == ActionType.WEB_SEARCH:
            prompt = f"Search results:\n{context}\n\nUser: {query}\nAssistant:"
            
        elif action.type == ActionType.VISION_ANALYZE:
            prompt = f"Image analysis: {context}\n\nUser: {query}\nAssistant:"
            
        elif action.type == ActionType.THINK_STEP:
            prompt = f"User: {query}\nAssistant (thinking step by step):"
            
        elif action.type == ActionType.CLARIFY:
            prompt = f"User: {query}\nAssistant (asking clarifying question):"
            
        elif action.type == ActionType.BREAK_DOWN:
            prompt = f"User: {query}\nAssistant (breaking into steps):\n1."
            
        elif action.type == ActionType.EMPATHIZE:
            prompt = f"User (feeling {emotion.primary.name}): {query}\nAssistant (empathetically):"
            
        elif action.type == ActionType.CELEBRATE:
            prompt = f"User (happy): {query}\nAssistant (celebrating):"
            
        elif action.type == ActionType.COMFORT:
            prompt = f"User (distressed): {query}\nAssistant (comforting):"
            
        elif action.type == ActionType.ENCOURAGE:
            prompt = f"User: {query}\nAssistant (encouraging):"
            
        elif action.type == ActionType.RECALL:
            prompt = f"Memories:\n{context}\n\nUser: {query}\nAssistant:"
            
        elif action.type == ActionType.REMEMBER:
            prompt = f"User shared: {query}\nAssistant (acknowledging):"
            
        elif action.type == ActionType.MULTI_TOOL:
            prompt = f"Information:\n{context}\n\nUser: {query}\nAssistant:"
            
        else:
            prompt = f"User: {query}\nAssistant:"
        
        return f"{system}\n\n{prompt}"
    
    def _generate_fallback(self, query: str, emotion: EmotionalState) -> str:
        """Generate response without LLM."""
        query_lower = query.lower()
        name = self.user_profile.get("name")
        
        # Greetings
        if any(g in query_lower for g in ["hello", "hi", "hey"]):
            if name:
                return f"Hello {name}! Great to hear from you. How can I help today?"
            return "Hello! I'm Dheera, your AI companion. How can I help you today?"
        
        # Emotional responses
        if emotion.primary == Emotion.SADNESS:
            return "I can sense you're going through something difficult. I'm here for you. Would you like to talk about it?"
        
        if emotion.primary == Emotion.JOY:
            return "I can feel your positive energy! That's wonderful. What's making you happy?"
        
        if emotion.primary == Emotion.FEAR:
            return "It sounds like you're worried about something. You're not alone - I'm here to help."
        
        return f"I understand you're asking about: {query}. How can I help you with this?"
    
    def _compute_reward(
        self,
        response: str,
        emotion: EmotionalState,
        action: ActionInfo
    ) -> float:
        """Compute reward for training."""
        reward = 0.0
        
        # Response quality (length, not empty)
        if len(response) > 10:
            reward += 0.3
        
        # Emotional appropriateness
        if emotion.primary in [Emotion.SADNESS, Emotion.FEAR, Emotion.ANGER]:
            if action.type in [ActionType.EMPATHIZE, ActionType.COMFORT]:
                reward += 0.5
        elif emotion.primary == Emotion.JOY:
            if action.type == ActionType.CELEBRATE:
                reward += 0.5
        
        # Action completion (not deferred)
        if action.type != ActionType.DEFER:
            reward += 0.2
        
        return reward
    
    def __call__(
        self,
        query: str,
        image_path: Optional[str] = None,
        return_details: bool = False
    ) -> Union[str, Dict]:
        """Main interaction method."""
        self.interaction_count += 1
        
        # 1. Detect emotion
        emotion = self.emotion_detector.detect(query)
        
        # 2. Analyze image if provided
        vision_result = None
        if image_path:
            vision_result = self.vision.analyze(image_path)
        
        # 3. Get conversation history
        history = self.db.get_recent_conversations(limit=10)
        
        # 4. Build state
        state = self.state_builder.build(
            query, emotion, history, vision_result, self.user_profile
        )
        emotion_vec = emotion.to_vector()
        
        # 5. Select action
        action_id, q_values = self.agent.select_action(
            state, emotion_vec, query=query, training=self.config.learning_enabled
        )
        action = ACTION_REGISTRY[ActionType(action_id)]
        
        # 6. Compute curiosity
        curiosity_bonus = self.curiosity.compute_intrinsic_reward(state)
        
        # 7. Execute action
        context = self._execute_action(action, query, emotion, vision_result)
        
        # 8. Generate response
        prompt = self._build_prompt(action, query, context, emotion)
        response = self.llm.generate(prompt)
        
        # Fallback if response is bad
        if not response or len(response) < 5:
            response = self._generate_fallback(query, emotion)
        
        # 9. Store in database
        conv_id = self.db.add_conversation(
            "user", query, emotion.primary.name, action_id
        )
        self.db.add_conversation("assistant", response)
        
        # 10. Extract user info
        self._extract_user_info(query)
        
        # 11. Compute reward and store experience
        reward = self._compute_reward(response, emotion, action)
        reward += curiosity_bonus * 0.1  # Add curiosity bonus
        
        if self.last_state is not None:
            self.agent.store_transition(
                self.last_state,
                self.last_action,
                reward,
                state,
                False,
                emotion_vec
            )
            
            # Also store in database for persistence
            self.db.add_experience(
                self.last_state, self.last_action, reward,
                state, False, emotion_vec
            )
        
        # 12. Train if enabled
        if (self.config.learning_enabled and 
            self.interaction_count % self.config.train_every_n == 0):
            loss = self.agent.train_step()
            if loss:
                pass  # Could log this
        
        # Update state tracking
        self.last_state = state
        self.last_action = action_id
        self.last_conv_id = conv_id
        
        # Update user profile stats
        self.user_profile["total_messages"] = self.user_profile.get("total_messages", 0) + 1
        if not self.user_profile.get("first_interaction"):
            self.user_profile["first_interaction"] = datetime.now().isoformat()
        
        # Auto-save periodically
        if self.interaction_count % 20 == 0:
            self._save_checkpoint()
            self._save_user_profile()
        
        if return_details:
            return {
                "response": response,
                "action": {
                    "id": action_id,
                    "name": action.name,
                    "type": action.type.name
                },
                "emotion": {
                    "primary": emotion.primary.name,
                    "intensity": emotion.intensity,
                    "valence": emotion.valence
                },
                "scores": {
                    "curiosity": curiosity_bonus,
                    "reward": reward
                },
                "vision": vision_result,
                "q_values": q_values.tolist() if q_values is not None else None
            }
        
        return response
    
    def provide_feedback(self, rating: float, comment: str = ""):
        """Provide feedback for RLHF."""
        if self.last_state is None or self.last_action is None:
            return
        
        # Store feedback
        self.db.add_feedback(
            self.last_conv_id, rating, comment,
            self.last_state, self.last_action
        )
        
        # Train reward model
        loss = self.reward_model.train_on_feedback(
            self.last_state, self.last_action, rating
        )
        
        # Update experience priority based on feedback
        # High feedback = high priority for replay
        priority = abs(rating) + 0.5
        
        return {"status": "success", "reward_loss": loss}
    
    def get_stats(self) -> Dict:
        """Get system statistics."""
        db_stats = self.db.get_stats()
        
        return {
            "version": self.VERSION,
            "user": {
                "name": self.user_profile.get("name"),
                "total_messages": self.user_profile.get("total_messages", 0),
                "facts": len(self.user_profile.get("facts", {})),
                "likes": self.user_profile.get("likes", [])[:5]
            },
            "database": db_stats,
            "learning": {
                "enabled": self.config.learning_enabled,
                "train_steps": self.agent.train_steps,
                "experiences": db_stats["experiences"]
            },
            "tools": {
                "llm": self.llm.provider,
                "vision": self.vision.available,
                "web_search": self.web_search.available,
                "rag_documents": len(self.rag.documents)
            }
        }
    
    def save(self):
        """Save all state."""
        self._save_checkpoint()
        self._save_user_profile()
        print("✅ Saved successfully")
    
    def close(self):
        """Cleanup."""
        self.save()
        self.db.close()


# =============================================================================
# INTERACTIVE CHAT
# =============================================================================

def interactive_chat(dheera: DheeraV5):
    """Run interactive chat."""
    name = dheera.user_profile.get("name", "friend")
    
    print(f"""
╔═══════════════════════════════════════════════════════════════╗
║            धीर  DHEERA v5 - Super Intelligence                ║
╠═══════════════════════════════════════════════════════════════╣
║  Hello{f' {name}' if name else ''}! I'm constantly learning to understand you better.
║                                                               ║
║  Commands:                                                    ║
║    /image <path>  - Analyze image                             ║
║    /stats         - Show statistics                           ║
║    /feedback <±>  - Rate response (++/+/-/--)                 ║
║    /remember      - What I know about you                     ║
║    /train         - Trigger training step                     ║
║    /save          - Save progress                             ║
║    /quit          - Exit                                      ║
╚═══════════════════════════════════════════════════════════════╝
    """)
    
    while True:
        try:
            user_input = input(f"\n🧑 {name}: ").strip()
            
            if not user_input:
                continue
            
            # Commands
            if user_input.startswith("/"):
                parts = user_input.split(maxsplit=1)
                cmd = parts[0].lower()
                arg = parts[1] if len(parts) > 1 else ""
                
                if cmd in ("/quit", "/exit", "/q"):
                    dheera.save()
                    print(f"\n👋 Goodbye{f', {name}' if name else ''}! I'll remember our conversation.")
                    break
                
                elif cmd == "/image":
                    if arg:
                        result = dheera(arg.split()[0], image_path=arg.split()[0], return_details=True)
                        print(f"\n🤖 Dheera: {result['response']}")
                        if result.get('vision', {}).get('objects'):
                            objs = [o['name'] for o in result['vision']['objects']]
                            print(f"   📷 Detected: {', '.join(objs)}")
                    else:
                        print("   Usage: /image <path>")
                    continue
                
                elif cmd == "/stats":
                    stats = dheera.get_stats()
                    print(f"\n📊 Statistics:")
                    print(f"   User: {stats['user']['name'] or 'Unknown'}")
                    print(f"   Messages: {stats['user']['total_messages']}")
                    print(f"   LLM: {stats['tools']['llm']}")
                    print(f"   Training steps: {stats['learning']['train_steps']}")
                    print(f"   Experiences: {stats['learning']['experiences']}")
                    print(f"   Avg rating: {stats['database']['avg_rating']:.2f}")
                    continue
                
                elif cmd == "/feedback":
                    feedback_map = {"++": 1.0, "+": 0.5, "-": -0.5, "--": -1.0}
                    if arg in feedback_map:
                        dheera.provide_feedback(feedback_map[arg])
                        print("   ✓ Thanks! This helps me learn.")
                    else:
                        print("   Usage: /feedback ++|+|-|--")
                    continue
                
                elif cmd == "/remember":
                    profile = dheera.user_profile
                    print(f"\n🧠 What I know about you:")
                    if profile.get("name"):
                        print(f"   Name: {profile['name']}")
                    if profile.get("likes"):
                        print(f"   Likes: {', '.join(profile['likes'][:5])}")
                    if profile.get("dislikes"):
                        print(f"   Dislikes: {', '.join(profile['dislikes'][:5])}")
                    continue
                
                elif cmd == "/train":
                    print("   Training...")
                    for _ in range(10):
                        loss = dheera.agent.train_step()
                    print(f"   ✓ Completed training step")
                    continue
                
                elif cmd == "/save":
                    dheera.save()
                    continue
                
                else:
                    print(f"   Unknown command: {cmd}")
                    continue
            
            # Regular chat
            result = dheera(user_input, return_details=True)
            
            print(f"\n🤖 Dheera: {result['response']}")
            
            # Show emotion detection
            emotion = result['emotion']
            if emotion['intensity'] > 0.3 and emotion['primary'] != 'NEUTRAL':
                icons = {
                    'JOY': '😊', 'SADNESS': '😢', 'ANGER': '😤',
                    'FEAR': '😰', 'SURPRISE': '😮', 'TRUST': '🤝'
                }
                icon = icons.get(emotion['primary'], '')
                if icon:
                    print(f"   {icon} Detected: {emotion['primary'].lower()}")
            
            # Update name
            if dheera.user_profile.get("name") and name == "friend":
                name = dheera.user_profile["name"]
                
        except KeyboardInterrupt:
            dheera.save()
            print("\n👋 Goodbye!")
            break
        except Exception as e:
            print(f"\n❌ Error: {e}")


# =============================================================================
# MAIN
# =============================================================================

def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="Dheera v5 - Super Intelligence")
    parser.add_argument("--api", action="store_true", help="Run API server")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--llm", choices=["auto", "ollama", "transformers"], default="auto")
    parser.add_argument("--no-learn", action="store_true", help="Disable learning")
    
    args = parser.parse_args()
    
    config = DheeraConfig(
        llm_provider=args.llm,
        learning_enabled=not args.no_learn
    )
    
    dheera = DheeraV5(config)
    
    if args.api:
        from api_server import run_api_server
        run_api_server(dheera, port=args.port)
    else:
        interactive_chat(dheera)
    
    dheera.close()


if __name__ == "__main__":
    main()
