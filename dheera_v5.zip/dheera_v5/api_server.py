#!/usr/bin/env python3
"""
Dheera v5 API Server
====================

OpenAI-compatible API with additional intelligence endpoints.

Endpoints:
- POST /v1/chat/completions    - Chat (OpenAI compatible)
- POST /v1/vision/analyze      - Image analysis
- GET  /v1/models              - Model information
- GET  /v1/memory              - User memory
- POST /v1/memory              - Add to memory
- POST /v1/feedback            - RLHF feedback
- POST /v1/train               - Trigger training
- GET  /v1/stats               - Statistics
- GET  /health                 - Health check
- WS   /ws/chat                - WebSocket chat

Usage:
    python api_server.py --port 8000
"""

import os
import sys
import json
import uuid
import base64
import asyncio
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict, Any, List

# Install dependencies if needed
try:
    from fastapi import FastAPI, HTTPException, UploadFile, File, Form, WebSocket
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import JSONResponse, StreamingResponse
    from pydantic import BaseModel, Field
    import uvicorn
except ImportError:
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", 
                          "fastapi", "uvicorn", "pydantic", "python-multipart", "websockets"])
    from fastapi import FastAPI, HTTPException, UploadFile, File, Form, WebSocket
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import JSONResponse, StreamingResponse
    from pydantic import BaseModel, Field
    import uvicorn


# =============================================================================
# REQUEST/RESPONSE MODELS
# =============================================================================

class ChatMessage(BaseModel):
    role: str
    content: str
    name: Optional[str] = None


class ChatRequest(BaseModel):
    model: str = "dheera-v5"
    messages: List[ChatMessage]
    temperature: float = 0.7
    max_tokens: int = 512
    stream: bool = False
    
    # Dheera-specific
    return_emotion: bool = True
    return_action: bool = True
    return_scores: bool = False


class VisionRequest(BaseModel):
    query: str = "What do you see?"


class FeedbackRequest(BaseModel):
    rating: float = Field(..., ge=-1, le=1)
    comment: Optional[str] = ""


class MemoryRequest(BaseModel):
    content: str
    type: str = "user_info"
    importance: float = 0.5


class TrainRequest(BaseModel):
    steps: int = 10


# =============================================================================
# API APPLICATION
# =============================================================================

def create_app(dheera) -> FastAPI:
    """Create FastAPI application."""
    
    app = FastAPI(
        title="Dheera v5 API",
        description="""
# Dheera v5 - Super Intelligence API

A continuously learning AI companion with:
- **Rainbow DQN** - Advanced action selection
- **Emotional Intelligence** - Understands and responds to emotions
- **Computer Vision** - YOLO object detection
- **Long-term Memory** - Remembers across sessions
- **RLHF** - Learns from your feedback

## OpenAI Compatibility

```python
from openai import OpenAI

client = OpenAI(
    base_url="http://localhost:8000/v1",
    api_key="not-needed"
)

response = client.chat.completions.create(
    model="dheera-v5",
    messages=[{"role": "user", "content": "Hello!"}]
)
```

## Unique Features

- Emotion detection in every response
- Action transparency (what strategy Dheera chose)
- RLHF feedback endpoint for continuous learning
- Vision analysis endpoint
- Memory management
        """,
        version="5.0.0"
    )
    
    # CORS
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    # Temp directory
    temp_dir = Path("./temp")
    temp_dir.mkdir(exist_ok=True)
    
    # =========================================================================
    # BASIC ENDPOINTS
    # =========================================================================
    
    @app.get("/")
    async def root():
        return {
            "name": "Dheera v5 API",
            "version": "5.0.0",
            "description": "Super Intelligence - Continuously Learning AI",
            "status": "operational",
            "endpoints": {
                "chat": "POST /v1/chat/completions",
                "vision": "POST /v1/vision/analyze",
                "memory": "GET/POST /v1/memory",
                "feedback": "POST /v1/feedback",
                "train": "POST /v1/train",
                "stats": "GET /v1/stats",
                "models": "GET /v1/models"
            }
        }
    
    @app.get("/health")
    async def health():
        stats = dheera.get_stats()
        return {
            "status": "healthy",
            "model": "dheera-v5",
            "llm_provider": stats["tools"]["llm"],
            "vision": stats["tools"]["vision"],
            "learning_enabled": stats["learning"]["enabled"]
        }
    
    # =========================================================================
    # MODELS
    # =========================================================================
    
    @app.get("/v1/models")
    async def list_models():
        stats = dheera.get_stats()
        
        return {
            "object": "list",
            "data": [{
                "id": "dheera-v5",
                "object": "model",
                "created": int(datetime.now().timestamp()),
                "owned_by": "dheera",
                "name": "Dheera v5 - Super Intelligence",
                "capabilities": {
                    "chat": True,
                    "vision": stats["tools"]["vision"],
                    "emotional_intelligence": True,
                    "continuous_learning": stats["learning"]["enabled"],
                    "memory": True,
                    "web_search": stats["tools"]["web_search"]
                },
                "architecture": {
                    "dqn": "Rainbow (6 improvements)",
                    "state_dim": 128,
                    "action_space": 15,
                    "llm_backend": stats["tools"]["llm"]
                },
                "training_stats": {
                    "train_steps": stats["learning"]["train_steps"],
                    "experiences": stats["learning"]["experiences"]
                }
            }]
        }
    
    @app.get("/v1/models/{model_id}")
    async def get_model(model_id: str):
        if model_id != "dheera-v5":
            raise HTTPException(404, "Model not found")
        
        models = await list_models()
        return models["data"][0]
    
    # =========================================================================
    # CHAT
    # =========================================================================
    
    @app.post("/v1/chat/completions")
    async def chat_completions(request: ChatRequest):
        """Chat with Dheera (OpenAI-compatible)."""
        
        # Get user message
        user_message = ""
        for msg in reversed(request.messages):
            if msg.role == "user":
                user_message = msg.content
                break
        
        if not user_message:
            raise HTTPException(400, "No user message found")
        
        # Generate response
        result = dheera(user_message, return_details=True)
        
        # Build OpenAI-compatible response
        response = {
            "id": f"dheera-{uuid.uuid4().hex[:12]}",
            "object": "chat.completion",
            "created": int(datetime.now().timestamp()),
            "model": "dheera-v5",
            "choices": [{
                "index": 0,
                "message": {
                    "role": "assistant",
                    "content": result["response"]
                },
                "finish_reason": "stop"
            }],
            "usage": {
                "prompt_tokens": len(user_message.split()),
                "completion_tokens": len(result["response"].split()),
                "total_tokens": len(user_message.split()) + len(result["response"].split())
            }
        }
        
        # Add Dheera-specific info
        dheera_info = {}
        
        if request.return_emotion:
            dheera_info["emotion"] = result["emotion"]
        
        if request.return_action:
            dheera_info["action"] = result["action"]
        
        if request.return_scores:
            dheera_info["scores"] = result["scores"]
            if result.get("q_values"):
                dheera_info["q_values"] = result["q_values"]
        
        if dheera_info:
            response["dheera"] = dheera_info
        
        return response
    
    # =========================================================================
    # VISION
    # =========================================================================
    
    @app.post("/v1/vision/analyze")
    async def analyze_vision(
        file: Optional[UploadFile] = File(None),
        image_base64: Optional[str] = Form(None),
        query: str = Form("What do you see in this image?")
    ):
        """Analyze image with YOLO."""
        
        if not dheera.vision.available:
            raise HTTPException(503, "Vision not available. Install: pip install ultralytics")
        
        image_path = None
        
        try:
            if file:
                image_path = temp_dir / f"{uuid.uuid4().hex}.jpg"
                content = await file.read()
                with open(image_path, "wb") as f:
                    f.write(content)
                    
            elif image_base64:
                if "," in image_base64:
                    image_base64 = image_base64.split(",")[1]
                image_bytes = base64.b64decode(image_base64)
                image_path = temp_dir / f"{uuid.uuid4().hex}.jpg"
                with open(image_path, "wb") as f:
                    f.write(image_bytes)
            else:
                raise HTTPException(400, "No image provided")
            
            # Analyze
            result = dheera(query, image_path=str(image_path), return_details=True)
            
            return {
                "response": result["response"],
                "vision": result.get("vision", {}),
                "emotion": result["emotion"],
                "action": result["action"]
            }
            
        finally:
            if image_path and image_path.exists():
                try:
                    image_path.unlink()
                except:
                    pass
    
    # =========================================================================
    # MEMORY
    # =========================================================================
    
    @app.get("/v1/memory")
    async def get_memory():
        """Get user memory/profile."""
        profile = dheera.user_profile
        recent = dheera.db.get_recent_conversations(limit=5)
        
        return {
            "profile": {
                "name": profile.get("name"),
                "facts": profile.get("facts", {}),
                "likes": profile.get("likes", []),
                "dislikes": profile.get("dislikes", []),
                "total_messages": profile.get("total_messages", 0),
                "first_interaction": profile.get("first_interaction")
            },
            "recent_conversations": recent,
            "memory_count": dheera.db.get_stats()["memories"]
        }
    
    @app.post("/v1/memory")
    async def add_memory(request: MemoryRequest):
        """Add to knowledge base."""
        dheera.db.add_memory(request.type, request.content, request.importance)
        
        return {
            "status": "success",
            "message": "Memory added"
        }
    
    @app.post("/v1/memory/search")
    async def search_memory(query: str = Form(...)):
        """Search memories."""
        results = dheera.db.search_memories(query, limit=5)
        return {"results": results}
    
    # =========================================================================
    # FEEDBACK & TRAINING
    # =========================================================================
    
    @app.post("/v1/feedback")
    async def provide_feedback(request: FeedbackRequest):
        """Provide RLHF feedback."""
        result = dheera.provide_feedback(request.rating, request.comment)
        
        return {
            "status": "success",
            "message": "Thank you! Your feedback helps me learn.",
            "rating": request.rating,
            **result
        }
    
    @app.post("/v1/train")
    async def trigger_training(request: TrainRequest):
        """Manually trigger training steps."""
        losses = []
        
        for _ in range(request.steps):
            loss = dheera.agent.train_step()
            if loss:
                losses.append(loss)
        
        return {
            "status": "success",
            "steps": request.steps,
            "avg_loss": sum(losses) / len(losses) if losses else None,
            "total_train_steps": dheera.agent.train_steps
        }
    
    # =========================================================================
    # STATISTICS
    # =========================================================================
    
    @app.get("/v1/stats")
    async def get_stats():
        """Get detailed statistics."""
        return dheera.get_stats()
    
    @app.get("/v1/actions")
    async def list_actions():
        """List available actions."""
        from dheera import ACTION_REGISTRY
        
        actions = []
        for action_type, info in ACTION_REGISTRY.items():
            actions.append({
                "id": action_type.value,
                "name": info.name,
                "description": info.description,
                "emotional_valence": info.emotional_valence
            })
        
        return {"actions": actions}
    
    # =========================================================================
    # SAVE/LOAD
    # =========================================================================
    
    @app.post("/v1/save")
    async def save():
        """Save current state."""
        dheera.save()
        return {"status": "success", "message": "Saved"}
    
    # =========================================================================
    # WEBSOCKET (Real-time chat)
    # =========================================================================
    
    @app.websocket("/ws/chat")
    async def websocket_chat(websocket: WebSocket):
        """WebSocket endpoint for real-time chat."""
        await websocket.accept()
        
        try:
            while True:
                # Receive message
                data = await websocket.receive_text()
                message = json.loads(data)
                
                query = message.get("content", "")
                
                # Generate response
                result = dheera(query, return_details=True)
                
                # Send response
                await websocket.send_json({
                    "type": "response",
                    "content": result["response"],
                    "emotion": result["emotion"],
                    "action": result["action"]
                })
                
        except Exception as e:
            await websocket.close()
    
    return app


def run_api_server(dheera, host: str = "127.0.0.1", port: int = 8000):
    """Run the API server."""
    
    app = create_app(dheera)
    
    print(f"""
╔═══════════════════════════════════════════════════════════════════╗
║              धीर  DHEERA v5 API SERVER                            ║
║              Super Intelligence - Continuously Learning           ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║  Endpoints:                                                       ║
║    POST /v1/chat/completions  - Chat (OpenAI-compatible)         ║
║    POST /v1/vision/analyze    - Analyze images (YOLO)             ║
║    GET  /v1/memory            - View memory                       ║
║    POST /v1/feedback          - RLHF feedback                     ║
║    POST /v1/train             - Trigger training                  ║
║    GET  /v1/stats             - Statistics                        ║
║    WS   /ws/chat              - WebSocket real-time               ║
║                                                                   ║
║  Server: http://{host}:{port}                                       ║
║  Docs:   http://{host}:{port}/docs                                  ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
    """)
    
    uvicorn.run(app, host=host, port=port)


# =============================================================================
# MAIN
# =============================================================================

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--llm", choices=["auto", "ollama", "transformers"], default="auto")
    
    args = parser.parse_args()
    
    # Import and initialize Dheera
    from dheera import DheeraV5, DheeraConfig
    
    config = DheeraConfig(llm_provider=args.llm)
    dheera = DheeraV5(config)
    
    run_api_server(dheera, host=args.host, port=args.port)
